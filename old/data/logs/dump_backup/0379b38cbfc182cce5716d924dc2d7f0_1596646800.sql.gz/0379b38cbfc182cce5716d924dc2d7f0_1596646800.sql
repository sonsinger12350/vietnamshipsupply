-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: localhost
-- Generation Time: August 6, 2020, 09:30 AM GMT
-- Server version: 5.5.62-cll
-- PHP Version: 5.3.29

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8';
SET SESSION `character_set_results`='utf8';
SET SESSION `character_set_connection`='utf8';
SET SESSION `collation_connection`='utf8_general_ci';
SET NAMES 'utf8';
ALTER DATABASE DEFAULT CHARACTER SET `utf8` COLLATE `utf8_general_ci`;

--
-- Database: `vietnams_shipsupply`
--


-- ---------------------------------------


--
-- Table structure for table `nv4_authors`
--

DROP TABLE IF EXISTS `nv4_authors`;
CREATE TABLE `nv4_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100) DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255) DEFAULT '',
  `position` varchar(255) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text,
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors`
--

INSERT INTO `nv4_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', '5bf13c69ec4871a49db5d41f639effb4', 1594378996, '14.186.21.80', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36'), 
(2, 'ckeditor', 2, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'hoangnhan', 0, 0, 0, '', '331f39255383de11939a433971f30e1f', 1464149970, '14.169.172.216', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36'), 
(3, 'ckeditor', 2, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'admin', 0, 0, 0, '', 'e8d3e9941aa6fc4debe10ce195b8d72e', 1587521140, '1.52.163.217', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0');


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_config`
--

DROP TABLE IF EXISTS `nv4_authors_config`;
CREATE TABLE `nv4_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_authors_module`
--

DROP TABLE IF EXISTS `nv4_authors_module`;
CREATE TABLE `nv4_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `lang_key` varchar(50) NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32) DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_authors_module`
--

INSERT INTO `nv4_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '2f12e5771f7e1ee9cda34085bcb10cb2'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '4198c44aa98bd4b0140d1e1ff3ad7536'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '0b121b4c4f63188918cb9a8ec2323a14'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, '4e57e6c52c26a58c7ddbab81172a6fbf'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '941c93bcf600ef4fcd268c712a8e7d29'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, '56141fdd4b80345388a1e33cb1b74a11'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '64046b68c2973c6b74608aa74c9e49ed'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '3c419668870054da617ffe96eb52a79c'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, '3ed03fb2d0fb80165728d2f74bac40a3'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, '58502a01e6b8c24e65a0b4e46a01b506'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '79d4b952da5f8e4560eae29db34d58c4');


-- ---------------------------------------


--
-- Table structure for table `nv4_banip`
--

DROP TABLE IF EXISTS `nv4_banip`;
CREATE TABLE `nv4_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32) DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_click`
--

DROP TABLE IF EXISTS `nv4_banners_click`;
CREATE TABLE `nv4_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15) NOT NULL,
  `click_country` varchar(10) NOT NULL,
  `click_browse_key` varchar(100) NOT NULL,
  `click_browse_name` varchar(100) NOT NULL,
  `click_os_key` varchar(100) NOT NULL,
  `click_os_name` varchar(100) NOT NULL,
  `click_ref` varchar(255) NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_clients`
--

DROP TABLE IF EXISTS `nv4_banners_clients`;
CREATE TABLE `nv4_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `yim` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40) NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) NOT NULL,
  `last_agent` varchar(255) NOT NULL,
  `uploadtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_plans`
--

DROP TABLE IF EXISTS `nv4_banners_plans`;
CREATE TABLE `nv4_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2) DEFAULT '',
  `title` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `form` varchar(100) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_plans`
--

INSERT INTO `nv4_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 510, 100, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 190, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_banners_rows`
--

DROP TABLE IF EXISTS `nv4_banners_rows`;
CREATE TABLE `nv4_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255) NOT NULL,
  `file_ext` varchar(100) NOT NULL,
  `file_mime` varchar(100) NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255) DEFAULT '',
  `imageforswf` varchar(255) DEFAULT '',
  `click_url` varchar(255) DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_banners_rows`
--

INSERT INTO `nv4_banners_rows` VALUES
(1, 'Bo ngoai giao', 2, 0, 'bongoaigiao.jpg', 'jpg', 'image/jpeg', 160, 54, '', '', 'http://www.mofa.gov.vn', '_blank', 1439973638, 1439973638, 0, 0, 1, 1), 
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 190, 454, '', '', 'http://vinades.vn', '_blank', 1439973638, 1439973638, 0, 0, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh_vn.png', 'png', 'image/png', 510, 65, '', '', 'http://webnhanh.vn', '_blank', 1439973638, 1439973638, 0, 0, 1, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_config`
--

DROP TABLE IF EXISTS `nv4_config`;
CREATE TABLE `nv4_config` (
  `lang` varchar(3) NOT NULL DEFAULT 'sys',
  `module` varchar(25) NOT NULL DEFAULT 'global',
  `config_name` varchar(30) NOT NULL DEFAULT '',
  `config_value` text,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_config`
--

INSERT INTO `nv4_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'NukeViet, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '8388608'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'en'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'supplies'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '76'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.23'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'adminrelogin_max', '3'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '0'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '5'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '6'), 
('sys', 'define', 'nv_gfx_width', '120'), 
('sys', 'define', 'nv_gfx_height', '25'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('en', 'global', 'site_domain', ''), 
('en', 'global', 'site_name', 'Ship Supply'), 
('en', 'global', 'site_logo', 'uploads/vietnam-ship-supply-logo.png'), 
('en', 'global', 'site_description', 'Sharing success, connect passions'), 
('en', 'global', 'site_keywords', 'Ship Supply'), 
('en', 'global', 'site_theme', 'default'), 
('en', 'global', 'mobile_theme', ''), 
('en', 'global', 'site_home_module', 'home'), 
('en', 'global', 'switch_mobi_des', '0'), 
('en', 'global', 'upload_logo', ''), 
('en', 'global', 'autologosize1', '50'), 
('en', 'global', 'autologosize2', '40'), 
('en', 'global', 'autologosize3', '30'), 
('en', 'global', 'autologomod', ''), 
('en', 'global', 'name_show', '1'), 
('en', 'global', 'cronjobs_next_time', '1596706511'), 
('en', 'global', 'disable_site_content', 'For technical reasons Web site temporary not available. we are very sorry for that inconvenience!'), 
('en', 'global', 'ssl_https_modules', ''), 
('en', 'seotools', 'prcservice', ''), 
('en', 'about', 'view_comm', '6'), 
('en', 'about', 'auto_postcomm', '1'), 
('en', 'about', 'allowed_comm', '-1'), 
('en', 'page', 'activecomm', '0'), 
('en', 'page', 'emailcomm', '0'), 
('en', 'supplies', 'structure_upload', 'Ym'), 
('en', 'news', 'allowed_comm', '-1'), 
('en', 'news', 'auto_postcomm', '1'), 
('en', 'news', 'socialbutton', '1'), 
('en', 'news', 'alias_lower', '1'), 
('en', 'news', 'tags_alias', '0'), 
('en', 'news', 'auto_tags', '0'), 
('en', 'news', 'tags_remind', '1'), 
('en', 'news', 'structure_upload', 'Ym'), 
('en', 'news', 'imgposition', '2'), 
('en', 'news', 'allowed_rating_point', '1'), 
('en', 'news', 'facebookappid', ''), 
('en', 'news', 'show_no_image', ''), 
('en', 'news', 'blockwidth', '52'), 
('en', 'news', 'blockheight', '75'), 
('en', 'news', 'imagefull', '460'), 
('en', 'news', 'copyright', ''), 
('en', 'news', 'showtooltip', '1'), 
('en', 'news', 'tooltip_position', 'bottom'), 
('en', 'news', 'tooltip_length', '150'), 
('en', 'news', 'showhometext', '1'), 
('en', 'news', 'timecheckstatus', '0'), 
('en', 'news', 'config_source', '0'), 
('en', 'page', 'sortcomm', '0'), 
('en', 'page', 'captcha', '1'), 
('en', 'page', 'allowed_comm', '-1'), 
('en', 'page', 'view_comm', '6'), 
('en', 'page', 'setcomm', '4'), 
('en', 'siteterms', 'auto_postcomm', '1'), 
('en', 'siteterms', 'allowed_comm', '-1'), 
('en', 'siteterms', 'view_comm', '6'), 
('en', 'siteterms', 'setcomm', '4'), 
('en', 'siteterms', 'activecomm', '0'), 
('en', 'siteterms', 'emailcomm', '0'), 
('en', 'siteterms', 'adminscomm', ''), 
('en', 'siteterms', 'sortcomm', '0'), 
('en', 'siteterms', 'captcha', '1'), 
('en', 'freecontent', 'next_execute', '0'), 
('vi', 'contact', 'bodytext', 'If you have any questions or comments, please contact us below and we will get back to you as soon as possible.'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'trungnghiack@gmail.com'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'trungnghiack@gmail.com'), 
('sys', 'global', 'site_lang', 'en'), 
('sys', 'global', 'my_domains', 'vietnamshipsupply.com,www.vietnamshipsupply.com'), 
('sys', 'global', 'cookie_prefix', 'nv4c_Lnbcj'), 
('sys', 'global', 'session_prefix', 'nv4s_Soiy51'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'STsVVzsWA_csUY28JMec60k7FVc7FgP3LFGNvCTHnOs,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('en', 'supplies', 'imgposition', '2'), 
('en', 'supplies', 'tags_alias', '0'), 
('en', 'supplies', 'blockwidth', '52'), 
('en', 'supplies', 'blockheight', '75'), 
('en', 'supplies', 'imagefull', '460'), 
('en', 'news', 'view_comm', '6'), 
('en', 'news', 'setcomm', '4'), 
('en', 'news', 'activecomm', '0'), 
('en', 'news', 'emailcomm', '0'), 
('en', 'news', 'adminscomm', ''), 
('en', 'news', 'sortcomm', '0'), 
('en', 'news', 'captcha', '1'), 
('en', 'supplies', 'tags_remind', '1'), 
('en', 'supplies', 'auto_tags', '0'), 
('en', 'supplies', 'timecheckstatus', '0'), 
('en', 'supplies', 'config_source', '0'), 
('en', 'supplies', 'show_no_image', ''), 
('en', 'supplies', 'allowed_rating_point', '1'), 
('en', 'news', 'indexfile', 'viewcat_main_right'), 
('en', 'news', 'per_page', '20'), 
('en', 'news', 'st_links', '10'), 
('en', 'news', 'homewidth', '100'), 
('en', 'news', 'homeheight', '150'), 
('en', 'slider', 'indexfile', 'viewcat_page_new'), 
('en', 'slider', 'homewidth', '100'), 
('en', 'slider', 'homeheight', '150'), 
('en', 'slider', 'blockwidth', '52'), 
('en', 'slider', 'blockheight', '75'), 
('en', 'slider', 'show_no_image', ''), 
('en', 'slider', 'structure_upload', 'Ym'), 
('en', 'slider', 'timecheckstatus', '0'), 
('en', 'page', 'adminscomm', ''), 
('en', 'page', 'auto_postcomm', '1'), 
('en', 'about', 'setcomm', '4'), 
('en', 'about', 'activecomm', '0'), 
('en', 'about', 'emailcomm', '0'), 
('en', 'about', 'adminscomm', ''), 
('en', 'about', 'sortcomm', '0'), 
('en', 'about', 'captcha', '1'), 
('en', 'supplies', 'socialbutton', '1'), 
('en', 'supplies', 'alias_lower', '1'), 
('en', 'supplies', 'facebookappid', ''), 
('en', 'supplies', 'showhometext', '1'), 
('en', 'supplies', 'copyright', ''), 
('en', 'supplies', 'showtooltip', '1'), 
('en', 'supplies', 'tooltip_position', 'bottom'), 
('en', 'supplies', 'tooltip_length', '150'), 
('en', 'supplies', 'indexfile', 'viewcat_main_right'), 
('en', 'supplies', 'per_page', '20'), 
('en', 'supplies', 'st_links', '10'), 
('en', 'supplies', 'homewidth', '100'), 
('en', 'supplies', 'homeheight', '150'), 
('en', 'supplies', 'auto_postcomm', '1'), 
('en', 'supplies', 'allowed_comm', '-1'), 
('en', 'supplies', 'view_comm', '6'), 
('en', 'supplies', 'setcomm', '4'), 
('en', 'supplies', 'activecomm', '0'), 
('en', 'supplies', 'emailcomm', '0'), 
('en', 'supplies', 'adminscomm', ''), 
('en', 'supplies', 'sortcomm', '0'), 
('en', 'supplies', 'captcha', '1'), 
('en', 'port-we-serv', 'adminscomm', ''), 
('en', 'port-we-serv', 'emailcomm', '0'), 
('en', 'port-we-serv', 'auto_postcomm', '1'), 
('en', 'port-we-serv', 'allowed_comm', '-1'), 
('en', 'port-we-serv', 'view_comm', '6'), 
('en', 'port-we-serv', 'setcomm', '4'), 
('en', 'port-we-serv', 'activecomm', '0'), 
('en', 'port-we-serv', 'sortcomm', '0'), 
('en', 'port-we-serv', 'captcha', '1');


-- ---------------------------------------


--
-- Table structure for table `nv4_cookies`
--

DROP TABLE IF EXISTS `nv4_cookies`;
CREATE TABLE `nv4_cookies` (
  `name` varchar(50) NOT NULL DEFAULT '',
  `value` mediumtext NOT NULL,
  `domain` varchar(100) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_counter`
--

DROP TABLE IF EXISTS `nv4_counter`;
CREATE TABLE `nv4_counter` (
  `c_type` varchar(100) NOT NULL,
  `c_val` varchar(100) NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `en_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_counter`
--

INSERT INTO `nv4_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1596706209, 0), 
('total', 'hits', 1596706209, 147318, 147318), 
('year', '2015', 1451567914, 5989, 5989), 
('year', '2016', 1483203313, 17687, 17687), 
('year', '2017', 1514739374, 35833, 35833), 
('year', '2018', 1546275080, 32126, 32126), 
('year', '2019', 1577808072, 31898, 31898), 
('year', '2020', 1596706209, 23785, 23785), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('month', 'Jan', 1580486627, 2578, 2578), 
('month', 'Feb', 1582994466, 2776, 2776), 
('month', 'Mar', 1585669992, 3426, 3426), 
('month', 'Apr', 1588265383, 3287, 3287), 
('month', 'May', 1590943679, 3799, 3799), 
('month', 'Jun', 1593536027, 3521, 3521), 
('month', 'Jul', 1596212834, 3819, 3819), 
('month', 'Aug', 1596706209, 579, 579), 
('month', 'Sep', 1569862313, 0, 0), 
('month', 'Oct', 1572540464, 0, 0), 
('month', 'Nov', 1575133054, 0, 0), 
('month', 'Dec', 1577808072, 0, 0), 
('day', '01', 1596299748, 81, 81), 
('day', '02', 1596387088, 101, 101), 
('day', '03', 1596472993, 109, 109), 
('day', '04', 1596560297, 105, 105), 
('day', '05', 1596646402, 92, 92), 
('day', '06', 1596706209, 91, 91), 
('day', '07', 1594140149, 0, 0), 
('day', '08', 1594227533, 0, 0), 
('day', '09', 1594311339, 0, 0), 
('day', '10', 1594400284, 0, 0), 
('day', '11', 1594485404, 0, 0), 
('day', '12', 1594572229, 0, 0), 
('day', '13', 1594657380, 0, 0), 
('day', '14', 1594744885, 0, 0), 
('day', '15', 1594831881, 0, 0), 
('day', '16', 1594917346, 0, 0), 
('day', '17', 1595005108, 0, 0), 
('day', '18', 1595091396, 0, 0), 
('day', '19', 1595177803, 0, 0), 
('day', '20', 1595264066, 0, 0), 
('day', '21', 1595350233, 0, 0), 
('day', '22', 1595435574, 0, 0), 
('day', '23', 1595523591, 0, 0), 
('day', '24', 1595609064, 0, 0), 
('day', '25', 1595695543, 0, 0), 
('day', '26', 1595781097, 0, 0), 
('day', '27', 1595868407, 0, 0), 
('day', '28', 1595952513, 0, 0), 
('day', '29', 1596036866, 0, 0), 
('day', '30', 1596125425, 0, 0), 
('day', '31', 1596212834, 0, 0), 
('dayofweek', 'Sunday', 1596387088, 20848, 20848), 
('dayofweek', 'Monday', 1596472993, 21589, 21589), 
('dayofweek', 'Tuesday', 1596560297, 21517, 21517), 
('dayofweek', 'Wednesday', 1596646402, 21367, 21367), 
('dayofweek', 'Thursday', 1596706209, 21688, 21688), 
('dayofweek', 'Friday', 1596212834, 20501, 20501), 
('dayofweek', 'Saturday', 1596299748, 19808, 19808), 
('hour', '00', 1596649322, 5, 5), 
('hour', '01', 1596653671, 4, 4), 
('hour', '02', 1596657578, 7, 7), 
('hour', '03', 1596659545, 2, 2), 
('hour', '04', 1596664747, 6, 6), 
('hour', '05', 1596666866, 7, 7), 
('hour', '06', 1596671036, 4, 4), 
('hour', '07', 1596675557, 5, 5), 
('hour', '08', 1596678768, 6, 6), 
('hour', '09', 1596682077, 2, 2), 
('hour', '10', 1596686151, 22, 22), 
('hour', '11', 1596603558, 0, 0), 
('hour', '12', 1596691902, 1, 1), 
('hour', '13', 1596696366, 8, 8), 
('hour', '14', 1596699182, 2, 2), 
('hour', '15', 1596704259, 7, 7), 
('hour', '16', 1596706209, 3, 3), 
('hour', '17', 1596624636, 0, 0), 
('hour', '18', 1596628321, 0, 0), 
('hour', '19', 1596632013, 0, 0), 
('hour', '20', 1596635575, 0, 0), 
('hour', '21', 1596639272, 0, 0), 
('hour', '22', 1596643043, 0, 0), 
('hour', '23', 1596646402, 0, 0), 
('bot', 'googlebot', 1596698027, 10568, 10568), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 1596623604, 1293, 1293), 
('browser', 'operamini', 1578434623, 20, 20), 
('browser', 'webtv', 1586021002, 1, 1), 
('browser', 'explorer', 1596652278, 8136, 8136), 
('browser', 'edge', 1596211378, 206, 206), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 1572789934, 91, 91), 
('browser', 'icab', 1570305714, 1, 1), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1596696327, 6818, 6818), 
('browser', 'iceweasel', 1595719719, 1, 1), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 1596701368, 53130, 53130), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 1586021085, 2, 2), 
('browser', 'safari', 1596657313, 825, 825), 
('browser', 'iphone', 1596706209, 1329, 1329), 
('browser', 'ipod', 1558448219, 3, 3), 
('browser', 'ipad', 1593394495, 61, 61), 
('browser', 'chrome', 1596704259, 26828, 26828), 
('browser', 'android', 1582676032, 15, 15), 
('browser', 'googlebot', 1596698027, 10568, 10568), 
('browser', 'yahooslurp', 1590456785, 4396, 4396), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 1483463735, 12, 12), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 1500090234, 1, 1), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 1588259032, 425, 425), 
('browser', 'bingbot', 1596694784, 17048, 17048), 
('browser', 'netscape', 1572771370, 2, 2), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 1572789928, 1, 1), 
('browser', 'phoenix', 1572789925, 2, 2), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 1596704600, 16103, 16103), 
('browser', 'Unspecified', 0, 0, 0), 
('os', 'unknown', 1596704600, 101003, 101003), 
('os', 'win', 1596254872, 6371, 6371), 
('os', 'win10', 1596702688, 7755, 7755), 
('os', 'win8', 1596684698, 2318, 2318), 
('os', 'win7', 1596643043, 8711, 8711), 
('os', 'win2003', 1593011859, 625, 625), 
('os', 'winvista', 1596033138, 641, 641), 
('os', 'wince', 1590386355, 22, 22), 
('os', 'winxp', 1595005108, 418, 418), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 1596701894, 3057, 3057), 
('os', 'linux', 1596701368, 5605, 5605), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 1596706209, 1348, 1348), 
('os', 'ipod', 1558448219, 3, 3), 
('os', 'ipad', 1593394495, 62, 62), 
('os', 'blackberry', 1483463735, 12, 12), 
('os', 'nokia', 1500090234, 1, 1), 
('os', 'freebsd', 1575181067, 3, 3), 
('os', 'openbsd', 1542785117, 1, 1), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 1586021069, 7, 7), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 1596704259, 9353, 9353), 
('os', 'irix', 1586020978, 2, 2), 
('os', 'palm', 0, 0, 0), 
('os', 'Unspecified', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 1594735337, 89, 89), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 1455869935, 1, 1), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 1593862444, 12, 12), 
('country', 'AM', 1568470953, 2, 2), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 1538957954, 5, 5), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 1596657578, 27, 27), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 1592337300, 22, 22), 
('country', 'AU', 1596184366, 208, 208), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 1595595616, 6, 6), 
('country', 'BA', 1528891743, 3, 3), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 1595739283, 60, 60), 
('country', 'BE', 1581591772, 32, 32), 
('country', 'BF', 1551615760, 2, 2), 
('country', 'BG', 1594720843, 109, 109), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 1569783240, 6, 6), 
('country', 'BM', 1583107536, 1, 1), 
('country', 'BN', 1547565076, 7, 7), 
('country', 'BO', 1475643219, 2, 2), 
('country', 'BR', 1595707138, 233, 233), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 1479708853, 1, 1), 
('country', 'BY', 1586764434, 3, 3), 
('country', 'BZ', 1591714915, 3, 3), 
('country', 'CA', 1596443543, 1757, 1757), 
('country', 'CD', 1542647014, 1, 1), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 1580436260, 1, 1), 
('country', 'CH', 1592515329, 172, 172), 
('country', 'CI', 1566107901, 5, 5), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 1582539839, 69, 69), 
('country', 'CM', 1537393354, 3, 3), 
('country', 'CN', 1578690076, 113, 113), 
('country', 'CO', 1596556216, 18, 18), 
('country', 'CR', 1564446837, 7, 7), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 1586507346, 58, 58), 
('country', 'CZ', 1596587835, 2108, 2108), 
('country', 'DE', 1596678768, 6082, 6082), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 1594697329, 39, 39), 
('country', 'DM', 1527523344, 11, 11), 
('country', 'DO', 1577683775, 6, 6), 
('country', 'DZ', 1555351083, 14, 14), 
('country', 'EC', 1591537962, 16, 16), 
('country', 'EE', 1577711181, 23, 23), 
('country', 'EG', 1595498777, 34, 34), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 1594167651, 85, 85), 
('country', 'ET', 1562967352, 1, 1), 
('country', 'EU', 1595306056, 220, 220), 
('country', 'FI', 1592249795, 63, 63), 
('country', 'FJ', 1548733964, 1, 1), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 1596701874, 2971, 2971), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 1596693989, 2331, 2331), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 1590902981, 4, 4), 
('country', 'GF', 1459463358, 1, 1), 
('country', 'GH', 1581119310, 27, 27), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 1547392089, 1, 1), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 1594713177, 159, 159), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 1446233617, 1, 1), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 1595442089, 3, 3), 
('country', 'HK', 1595141310, 258, 258), 
('country', 'HN', 1567931977, 2, 2), 
('country', 'HR', 1586848097, 25, 25), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 1585115722, 48, 48), 
('country', 'ID', 1596643043, 220, 220), 
('country', 'IE', 1596261709, 893, 893), 
('country', 'IL', 1594274322, 21, 21), 
('country', 'IN', 1596442586, 653, 653), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 1586201305, 7, 7), 
('country', 'IR', 1595098848, 29, 29), 
('country', 'IS', 1596696327, 10, 10), 
('country', 'IT', 1595435513, 595, 595), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 1592264741, 1, 1), 
('country', 'JP', 1596164136, 372, 372), 
('country', 'KE', 1587183100, 8, 8), 
('country', 'KG', 1545389216, 4, 4), 
('country', 'KH', 1588190179, 17, 17), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 1557905205, 1, 1), 
('country', 'KN', 1481680428, 1, 1), 
('country', 'KR', 1595104300, 557, 557), 
('country', 'KW', 1591912967, 1, 1), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 1592817579, 4, 4), 
('country', 'LB', 1554775423, 3, 3), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 1596451488, 21, 21), 
('country', 'LR', 1556867702, 3, 3), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 1577833210, 30, 30), 
('country', 'LU', 1591095186, 7, 7), 
('country', 'LV', 1595435539, 123, 123), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 1591900444, 6, 6), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 1581363144, 17, 17), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 1453551652, 1, 1), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 1501768273, 1, 1), 
('country', 'MO', 1512349177, 6, 6), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 1590648312, 1, 1), 
('country', 'MU', 1591618357, 2, 2), 
('country', 'MV', 1567679257, 7, 7), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 1596576710, 37, 37), 
('country', 'MY', 1594351854, 251, 251), 
('country', 'MZ', 1490187086, 2, 2), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 1595678389, 618, 618), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 1596118125, 900, 900), 
('country', 'NO', 1581558871, 160, 160), 
('country', 'NP', 1596396356, 10, 10), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 1595390004, 24, 24), 
('country', 'OM', 1569061033, 4, 4), 
('country', 'PA', 1594237471, 49, 49), 
('country', 'PE', 1528799776, 5, 5), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 1594607952, 2, 2), 
('country', 'PH', 1596433618, 156, 156), 
('country', 'PK', 1595809273, 42, 42), 
('country', 'PL', 1591721498, 118, 118), 
('country', 'PR', 1442946483, 1, 1), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 1586848873, 54, 54), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 1504622747, 1, 1), 
('country', 'QA', 1529113568, 7, 7), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 1596701894, 352, 352), 
('country', 'RU', 1596701368, 8593, 8593), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 1596632013, 25, 25), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 1579194742, 21, 21), 
('country', 'SD', 1506700887, 3, 3), 
('country', 'SE', 1595597216, 732, 732), 
('country', 'SG', 1596468997, 219, 219), 
('country', 'SI', 1560863870, 4, 4), 
('country', 'SK', 1558696108, 25, 25), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 1588507869, 29, 29), 
('country', 'SO', 1567959115, 4, 4), 
('country', 'SR', 1584656360, 2, 2), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 1556372194, 3, 3), 
('country', 'SY', 1530079064, 4, 4), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 1596636800, 224, 224), 
('country', 'TJ', 1542113162, 5, 5), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 1496667524, 1, 1), 
('country', 'TN', 1588387067, 13, 13), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 1596393789, 211, 211), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 1595984076, 910, 910), 
('country', 'TZ', 1585738379, 2, 2), 
('country', 'UA', 1596606393, 4483, 4483), 
('country', 'UG', 1593553408, 4, 4), 
('country', 'US', 1596704600, 71960, 71960), 
('country', 'UY', 1477538962, 2, 2), 
('country', 'UZ', 1507250237, 2, 2), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 1522897849, 2, 2), 
('country', 'VE', 1590554333, 6, 6), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 1596706209, 15413, 15413), 
('country', 'VU', 1529828211, 1, 1), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 1595629652, 3, 3), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 1591409037, 314, 314), 
('country', 'ZM', 1573812359, 2, 2), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1596684698, 20078, 20078), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_cronjobs`
--

DROP TABLE IF EXISTS `nv4_cronjobs`;
CREATE TABLE `nv4_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255) NOT NULL,
  `run_func` varchar(255) NOT NULL,
  `params` varchar(255) DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `en_cron_name` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=11  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_cronjobs`
--

INSERT INTO `nv4_cronjobs` VALUES
(1, 1439973638, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1596706211, 1, 'Delete expired online status'), 
(2, 1439973638, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1596616532, 1, 'Automatic backup database'), 
(3, 1439973638, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1596701904, 1, 'Empty temporary files'), 
(4, 1439973638, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1596701904, 1, 'Delete IP log files'), 
(5, 1439973638, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1596616532, 1, 'Delete expired error_log log files'), 
(6, 1439973638, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Send error logs to admin'), 
(7, 1439973638, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1596701904, 1, 'Delete expired referer'), 
(8, 1439973638, 1440, 'siteDiagnostic_update.php', 'cron_siteDiagnostic_update', '', 0, 0, 1, 1596616532, 1, 'Update site diagnostic'), 
(9, 1439973638, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1596701904, 1, 'Check NukeViet version'), 
(10, 1439973638, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1596616532, 1, 'Delete old notification');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_about`
--

DROP TABLE IF EXISTS `nv4_en_about`;
CREATE TABLE `nv4_en_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_about`
--

INSERT INTO `nv4_en_about` VALUES
(1, 'WELCOME', 'ABOUT-US', '0001.jpg', '', 'Vietnam Ship Supply has provided supplies and maintenance services for all types of ships docking in Vietnam since 2008. Our team of 20 dedicated employees is available 24/7 to give you a hassle-free experience during your stay at any of the ports across the country. Please contact us with your list of supply and maintenance needs to obtain a quote.', '&nbsp;', 'welcome to,blue ocean,marine service,co,.ltd', 0, '4', '', 0, 1, 3, 1441004637, 1564825048, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_about_config`
--

DROP TABLE IF EXISTS `nv4_en_about_config`;
CREATE TABLE `nv4_en_about_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_about_config`
--

INSERT INTO `nv4_en_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_blocks_groups`
--

DROP TABLE IF EXISTS `nv4_en_blocks_groups`;
CREATE TABLE `nv4_en_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55) NOT NULL,
  `module` varchar(55) NOT NULL,
  `file_name` varchar(55) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `template` varchar(55) DEFAULT NULL,
  `position` varchar(55) DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10) DEFAULT '1',
  `groups_view` varchar(255) DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=51  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_blocks_groups`
--

INSERT INTO `nv4_en_blocks_groups` VALUES
(3, 'default', 'slider', 'global.block_slider_cat.php', 'Banner', '', 'no_title', '[HEADER]', 0, '1', '6', 0, 1, 'a:5:{s:5:\"catid\";a:1:{i:0;s:1:\"1\";}s:6:\"numrow\";i:7;s:11:\"showtooltip\";i:0;s:16:\"tooltip_position\";s:1:\"0\";s:14:\"tooltip_length\";s:1:\"0\";}'), 
(39, 'default', 'news', 'global.block_groups.php', 'News', '/Ship_supply/news/groups/new/', '', '[OUR_BUSINESS]', 0, '1', '6', 0, 2, 'a:5:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:4;s:11:\"showtooltip\";i:0;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(8, 'default', 'page', 'global.html.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:92:\"<div><span style=\"font-size:12px;\">Copyright © by Vietnam Ship Supply Co., Ltd</span></div>\";}'), 
(9, 'default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 2, ''), 
(31, 'default', 'about', 'global.about.php', 'Welcom', '', 'no_title', '[TOP]', 0, '1', '6', 0, 2, ''), 
(28, 'default', 'slider', 'global.block_doitac.php', 'We are the Distributor of the following brands', '', 'doi_tac', '[BOTTOM]', 0, '1', '6', 1, 1, 'a:5:{s:5:\"catid\";a:1:{i:0;s:1:\"2\";}s:6:\"numrow\";i:25;s:11:\"showtooltip\";i:0;s:16:\"tooltip_position\";s:1:\"0\";s:14:\"tooltip_length\";s:1:\"0\";}'), 
(12, 'default', 'users', 'global.user_button.php', 'Login site', '', 'no_title', '[PERSONALAREA]', 0, '1', '6', 1, 1, ''), 
(13, 'default', 'page', 'global.html.php', 'VIETNAM SHIP SUPPLY CO., LTD', '', 'simple', '[COMPANY_INFO]', 0, '1', '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:1844:\"<div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"3\" rowspan=\"1\"><strong>Head Office</strong>: 1979/35 Huynh Tan Phat St., 6 Quater , Nha Be Town,&nbsp; Nha Be Dist.,&nbsp;Ho Chi Minh City, Vietnam</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"3\" rowspan=\"1\"><strong>Workshop/Warehouse</strong>: 1979/35 Huynh Tan Phat St., 6 Quater , Nha Be Town,&nbsp; Nha Be Dist.,&nbsp;Ho Chi Minh City, Vietnam</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%;\">	<tbody>		<tr>			<td><strong>Tell</strong>: +84 903764467</td>			<td><strong>&nbsp; Fax</strong>: +84 28 66823347</td>			<td><strong>Mobile</strong>: +84 901 366 626</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td style=\"width:4%\"><strong>Email</strong></td>			<td>&nbsp;<strong>General Info:</strong> info@vietnamshipsupply.com</td>		</tr>		<tr>			<td style=\"width: 100px;\">&nbsp;</td>			<td>&nbsp;<strong>Technical Dept<em>.</em>:&nbsp;</strong>tech@vietnamshipsupply.com</td>		</tr>		<tr>			<td>&nbsp;</td>			<td>&nbsp;<strong>Supply Dept.:</strong> supply@vietnamshipsupply.com</td>		</tr>		<tr>			<td>&nbsp;</td>			<td>&nbsp;<strong>Final Dept.</strong>: acct@vietnamshipsupply.com</td>		</tr>	</tbody></table></div><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"2\" rowspan=\"1\"><strong>Website</strong>: <a href=\"http://vietnamshipsupply.com/\" target=\"_blank\">www.vietnamshipsupply.com</a></td>			<td>&nbsp;</td>		</tr>	</tbody></table>\";}'), 
(41, 'default', 'statistics', 'global.counter.php', 'Statistics', '', 'simple', '[STATIS]', 0, '1', '6', 1, 1, ''), 
(14, 'default', 'menu', 'global.site_mods.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 1, 'a:2:{s:12:\"title_length\";i:20;s:14:\"module_in_menu\";a:5:{i:0;s:5:\"about\";i:1;s:8:\"supplies\";i:2;s:12:\"port-we-serv\";i:3;s:4:\"news\";i:4;s:7:\"contact\";}}'), 
(15, 'default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[CONTACT_DEFAULT]', 0, '1', '6', 1, 1, ''), 
(16, 'default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 1, 'a:4:{s:8:\"facebook\";s:55:\"https://www.facebook.com/profile.php?id=100008254141423\";s:11:\"google_plus\";s:23:\"https://www.google.com/\";s:7:\"youtube\";s:29:\"https://www.youtube.com/user/\";s:7:\"twitter\";s:20:\"https://twitter.com/\";}'), 
(17, 'default', 'theme', 'global.menu_footer.php', 'INFORMATION', '', 'no_title', '[MENU_FOOTER]', 0, '1', '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:6:{i:0;s:4:\"home\";i:1;s:5:\"about\";i:2;s:8:\"supplies\";i:3;s:12:\"port-we-serv\";i:4;s:4:\"news\";i:5;s:7:\"contact\";}}'), 
(18, 'default', 'menu', 'global.slimmenu.php', 'Supplies', '/supplies/', 'simple', '[FEATURED_PRODUCT]', 0, '1', '6', 1, 1, 'a:2:{s:6:\"menuid\";i:3;s:12:\"title_length\";i:20;}'), 
(19, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(20, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', '6', 1, 2, ''), 
(21, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 1, ''), 
(22, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 2, ''), 
(23, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(24, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(25, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:35:\"/index.php?language=en&nv=siteterms\";}'), 
(26, 'mobile_default', 'theme', 'global.menu_footer.php', 'Categories', '', 'primary', '[MENU_FOOTER]', 0, '1', '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(27, 'mobile_default', 'theme', 'global.company_info.php', 'Company Info', '', 'primary', '[COMPANY_INFO]', 0, '1', '6', 1, 1, 'a:11:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:13:\"company_phone\";s:14:\"+84-4-85872007\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(29, 'default', 'support', 'global.support_fixed_right.php', 'Support Online', '', 'no_title', '[FIX_BANNER_RIGHT]', 0, '1', '6', 1, 1, ''), 
(38, 'default', 'supplies', 'global.block_news_cat.php', 'Supplies', '', '', '[OUR_BUSINESS]', 0, '1', '6', 0, 1, 'a:5:{s:5:\"catid\";a:4:{i:0;s:1:\"1\";i:1;s:1:\"7\";i:2;s:1:\"5\";i:3;s:1:\"6\";}s:6:\"numrow\";i:5;s:11:\"showtooltip\";i:0;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(33, 'default', 'page', 'global.html.php', 'global html', '', 'no_title', '[LEFT]', 0, '1', '6', 0, 2, 'a:1:{s:11:\"htmlcontent\";s:1866:\"<div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"3\" rowspan=\"1\"><strong>Head Office</strong>: 1979/35 Huynh Tan Phat St., 6 Quater , Nha Be Town,&nbsp; Nha Be Dist.,&nbsp;Ho Chi Minh City, Vietnam</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"3\" rowspan=\"1\"><strong>Workshop/Warehouse</strong>:&nbsp;1979/35 Huynh Tan Phat St., 6 Quater , Nha Be Town,&nbsp; Nha Be Dist.,&nbsp;Ho Chi Minh City, Vietnam</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%;\">	<tbody>		<tr>			<td><strong>Tell</strong>: +84 903764467</td>			<td><strong>&nbsp; Fax</strong>: +84 28 66823347</td>			<td><strong>Mobile</strong>: +84 901 366 626</td>		</tr>	</tbody></table></div><div style=\"margin-bottom:10px\"><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td style=\"width:5%\"><strong>Email</strong></td>			<td>&nbsp;<strong>General Info</strong>: info@vietnamshipsupply.com</td>		</tr>		<tr>			<td style=\"width: 100px;\">&nbsp;</td>			<td>&nbsp;<strong>Technical Dept<em>.</em></strong>:<strong>&nbsp;</strong>tech@vietnamshipsupply.com</td>		</tr>		<tr>			<td>&nbsp;</td>			<td>&nbsp;<strong>Supply Dept.</strong>: supply@vietnamshipsupply.com</td>		</tr>		<tr>			<td>&nbsp;</td>			<td>&nbsp;<strong>Final Dept</strong>.: acct@vietnamshipsupply.com</td>		</tr>	</tbody></table></div><table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"width: 100%;\">	<tbody>		<tr>			<td colspan=\"2\" rowspan=\"1\"><strong>Website</strong>: <a href=\"http://vietnamshipsupply.com/\" target=\"_blank\">www.vietnamshipsupply.com</a></td>			<td>&nbsp;</td>		</tr>	</tbody></table>\";}'), 
(37, 'default', 'page', 'global.html.php', 'Contact Header', '', 'no_title', '[CONTACT]', 0, '1', '6', 1, 1, 'a:1:{s:11:\"htmlcontent\";s:162:\"Hotline : <strong>+84 901 366 626 - 84 903764467</strong><br  />Email : <span style=\"color:rgb(255, 255, 255);\"><strong>info@vietnamshipsupply.com</strong></span>\";}'), 
(40, 'default', 'supplies', 'global.block_category_o.php', 'Menu Supplies', '', 'no_title', '[LEFT]', 0, '1', '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:22;}'), 
(43, 'default', 'page', 'global.html.php', 'global html', '', 'no_title', '[BAN_DO]', 0, '1', '6', 0, 1, 'a:1:{s:11:\"htmlcontent\";s:146:\"<iframe frameborder=\"0\" height=\"480\" scrolling=\"no\" src=\"https://www.google.com/maps/d/embed?mid=z6l_kjPabYRg.klKZMssyGZL0\" width=\"100%\"></iframe>\";}'), 
(44, 'default', 'page', 'global.html.php', 'Managing Director', '', 'primary', '[OUR_BUSINESS]', 0, '1', '6', 0, 3, 'a:1:{s:11:\"htmlcontent\";s:565:\"<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"max-width:400px; width:100%\">	<tbody>		<tr>			<td colspan=\"2\"><span style=\"font-size:16px;\"><span style=\"color:rgb(1, 142, 200);\"><strong>Le Thi Ngoc Trinh</strong></span></span></td>		</tr>		<tr>			<td>Tel</td>			<td>: +84 903764467</td>		</tr>		<tr>			<td>Fax</td>			<td>: +84 28 66823347</td>		</tr>		<tr>			<td>Email</td>			<td>:&nbsp;<a href=\"mailto:info@vietnamshipsupply.com\">info@vietnamshipsupply.com</a></td>		</tr>		<tr>			<td>Web</td>			<td>:www.vietnamshipsupply.com</td>		</tr>	</tbody></table>\";}'), 
(45, 'default', 'page', 'global.html.php', 'Deputy Manager', '', 'primary', '[OUR_BUSINESS]', 0, '1', '6', 0, 4, 'a:1:{s:11:\"htmlcontent\";s:625:\"<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"max-width:400px; width:100%\">	<tbody>		<tr>			<td colspan=\"2\"><span style=\"font-size:16px;\"><span style=\"color:rgb(1, 142, 200);\"><strong>Huynh Thanh The</strong></span></span></td>		</tr>		<tr>			<td>Tel</td>			<td>: +84 903764467</td>		</tr>		<tr>			<td>Fax</td>			<td>:&nbsp;+84 28 6667 9502</td>		</tr>		<tr>			<td>HP</td>			<td>: +84 901 366 626</td>		</tr>		<tr>			<td>Email</td>			<td>:&nbsp;<a href=\"mailto:info@vietnamshipsupply.com\">info@vietnamshipsupply.com</a></td>		</tr>		<tr>			<td>Web</td>			<td>:www.vietnamshipsupply.com</td>		</tr>	</tbody></table>\";}'), 
(46, 'default', 'page', 'global.html.php', 'Purchasing Manager', '', 'primary', '[OUR_BUSINESS]', 0, '1', '6', 0, 5, 'a:1:{s:11:\"htmlcontent\";s:578:\"<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"max-width:400px; width:100%\">	<tbody>		<tr>			<td colspan=\"2\"><span style=\"font-size:16px;\"><span style=\"color:rgb(1, 142, 200);\"><strong>Simone Thien Bao</strong></span></span></td>		</tr>		<tr>			<td>Tel</td>			<td>:&nbsp;+84 903764467</td>		</tr>		<tr>			<td>Fax</td>			<td>:&nbsp;+84 28 66823347</td>		</tr>		<tr>			<td>Email</td>			<td>:&nbsp;<a href=\"mailto:supply@vietnamshipsupply.com\">supply@vietnamshipsupply.com</a></td>		</tr>		<tr>			<td>Web</td>			<td>:www.vietnamshipsupply.com</td>		</tr>	</tbody></table>\";}'), 
(47, 'default', 'page', 'global.html.php', 'Technical Manager', '', 'primary', '[OUR_BUSINESS]', 0, '1', '6', 0, 6, 'a:1:{s:11:\"htmlcontent\";s:571:\"<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"max-width:400px; width:100%\">	<tbody>		<tr>			<td colspan=\"2\"><span style=\"font-size:16px;\"><span style=\"color:rgb(1, 142, 200);\"><strong>Philip Huynh</strong></span></span></td>		</tr>		<tr>			<td>Tel</td>			<td>: +84 903764467</td>		</tr>		<tr>			<td>Fax</td>			<td>:&nbsp;+84 28 66823347</td>		</tr>		<tr>			<td>Email</td>			<td>:&nbsp;<a href=\"mailto:Email.tech@vietnamshipsupply.com\">tech@vietnamshipsupply.com</a></td>		</tr>		<tr>			<td>Web</td>			<td>:www.vietnamshipsupply.com</td>		</tr>	</tbody></table>\";}'), 
(48, 'default', 'page', 'global.html.php', 'Chief Account', '', 'primary', '[OUR_BUSINESS]', 0, '1', '6', 0, 7, 'a:1:{s:11:\"htmlcontent\";s:596:\"<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" style=\"max-width:400px; width:100%\">	<tbody>		<tr>			<td colspan=\"2\"><span style=\"font-size:18px;\"><span style=\"color:rgb(1, 142, 200);\"><strong>Lucia Th. An</strong></span></span></td>		</tr>		<tr>			<td>Tel</td>			<td>:&nbsp;+84 866622272&nbsp; - HP +84 906617071</td>		</tr>		<tr>			<td>Fax</td>			<td>:&nbsp;+84 28 6667 9502</td>		</tr>		<tr>			<td>Email</td>			<td>:&nbsp;<a href=\"mailto:acct@vietnamshipsupply.com\">acct@vietnamshipsupply.com</a></td>		</tr>		<tr>			<td>Web</td>			<td>:www.vietnamshipsupply.com</td>		</tr>	</tbody></table>\";}'), 
(49, 'default', 'theme', 'global.social.php', 'linkedin', 'https://www.linkedin.com/', '', '[SOCIAL_ICONS]', 0, '1', '6', 0, 2, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_blocks_weight`
--

DROP TABLE IF EXISTS `nv4_en_blocks_weight`;
CREATE TABLE `nv4_en_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_blocks_weight`
--

INSERT INTO `nv4_en_blocks_weight` VALUES
(13, 36, 1), 
(13, 37, 1), 
(13, 38, 1), 
(13, 39, 1), 
(13, 45, 1), 
(13, 46, 1), 
(13, 47, 1), 
(13, 48, 1), 
(13, 55, 1), 
(13, 58, 1), 
(13, 4, 1), 
(13, 5, 1), 
(13, 6, 1), 
(13, 7, 1), 
(13, 8, 1), 
(13, 9, 1), 
(13, 10, 1), 
(13, 11, 1), 
(13, 12, 1), 
(13, 49, 1), 
(13, 57, 1), 
(13, 52, 1), 
(13, 53, 1), 
(13, 29, 1), 
(13, 30, 1), 
(13, 31, 1), 
(13, 32, 1), 
(13, 33, 1), 
(13, 34, 1), 
(13, 35, 1), 
(13, 18, 1), 
(13, 19, 1), 
(13, 20, 1), 
(13, 21, 1), 
(13, 22, 1), 
(13, 23, 1), 
(13, 24, 1), 
(13, 25, 1), 
(13, 26, 1), 
(13, 27, 1), 
(13, 56, 1), 
(15, 1, 1), 
(15, 36, 1), 
(15, 37, 1), 
(15, 38, 1), 
(15, 39, 1), 
(15, 45, 1), 
(15, 46, 1), 
(15, 47, 1), 
(15, 48, 1), 
(15, 55, 1), 
(15, 58, 1), 
(15, 4, 1), 
(15, 5, 1), 
(15, 6, 1), 
(15, 7, 1), 
(15, 8, 1), 
(15, 9, 1), 
(15, 10, 1), 
(15, 11, 1), 
(15, 12, 1), 
(15, 49, 1), 
(15, 57, 1), 
(15, 52, 1), 
(15, 53, 1), 
(15, 29, 1), 
(15, 30, 1), 
(15, 31, 1), 
(15, 32, 1), 
(15, 33, 1), 
(15, 34, 1), 
(15, 35, 1), 
(15, 18, 1), 
(15, 19, 1), 
(15, 20, 1), 
(15, 21, 1), 
(15, 22, 1), 
(15, 23, 1), 
(15, 24, 1), 
(15, 25, 1), 
(15, 26, 1), 
(15, 27, 1), 
(15, 56, 1), 
(18, 36, 1), 
(18, 37, 1), 
(18, 38, 1), 
(18, 39, 1), 
(18, 45, 1), 
(18, 46, 1), 
(18, 47, 1), 
(18, 48, 1), 
(18, 55, 1), 
(18, 58, 1), 
(18, 4, 1), 
(18, 5, 1), 
(18, 6, 1), 
(18, 7, 1), 
(18, 8, 1), 
(18, 9, 1), 
(18, 10, 1), 
(18, 11, 1), 
(18, 12, 1), 
(18, 49, 1), 
(18, 57, 1), 
(18, 52, 1), 
(18, 53, 1), 
(18, 29, 1), 
(18, 30, 1), 
(18, 31, 1), 
(18, 32, 1), 
(18, 33, 1), 
(18, 34, 1), 
(18, 35, 1), 
(18, 18, 1), 
(18, 19, 1), 
(18, 20, 1), 
(18, 21, 1), 
(18, 22, 1), 
(18, 23, 1), 
(18, 24, 1), 
(18, 25, 1), 
(18, 26, 1), 
(18, 27, 1), 
(18, 56, 1), 
(8, 36, 1), 
(8, 37, 1), 
(8, 38, 1), 
(8, 39, 1), 
(8, 45, 1), 
(8, 46, 1), 
(8, 47, 1), 
(8, 48, 1), 
(8, 55, 1), 
(8, 58, 1), 
(8, 4, 1), 
(8, 5, 1), 
(8, 6, 1), 
(8, 7, 1), 
(8, 8, 1), 
(8, 9, 1), 
(8, 10, 1), 
(8, 11, 1), 
(8, 12, 1), 
(8, 49, 1), 
(8, 57, 1), 
(8, 52, 1), 
(8, 53, 1), 
(8, 29, 1), 
(8, 30, 1), 
(8, 31, 1), 
(8, 32, 1), 
(8, 33, 1), 
(8, 34, 1), 
(8, 35, 1), 
(8, 18, 1), 
(8, 19, 1), 
(8, 20, 1), 
(8, 21, 1), 
(8, 22, 1), 
(8, 23, 1), 
(8, 24, 1), 
(8, 25, 1), 
(8, 26, 1), 
(8, 27, 1), 
(8, 56, 1), 
(9, 1, 2), 
(9, 36, 2), 
(9, 37, 2), 
(9, 38, 2), 
(9, 39, 2), 
(9, 45, 2), 
(9, 46, 2), 
(9, 47, 2), 
(9, 48, 2), 
(9, 55, 2), 
(9, 58, 2), 
(9, 4, 2), 
(9, 5, 2), 
(9, 6, 2), 
(9, 7, 2), 
(9, 8, 2), 
(9, 9, 2), 
(9, 10, 2), 
(9, 11, 2), 
(9, 12, 2), 
(9, 49, 2), 
(9, 57, 2), 
(9, 52, 2), 
(9, 53, 2), 
(9, 29, 2), 
(9, 30, 2), 
(9, 31, 2), 
(9, 32, 2), 
(9, 33, 2), 
(9, 34, 2), 
(9, 35, 2), 
(9, 18, 2), 
(9, 19, 2), 
(9, 20, 2), 
(9, 21, 2), 
(9, 22, 2), 
(9, 23, 2), 
(9, 24, 2), 
(9, 25, 2), 
(9, 26, 2), 
(9, 27, 2), 
(9, 56, 2), 
(23, 92, 3), 
(23, 85, 3), 
(23, 90, 3), 
(23, 96, 3), 
(23, 97, 3), 
(23, 84, 3), 
(23, 95, 3), 
(23, 87, 3), 
(23, 86, 3), 
(28, 75, 1), 
(25, 92, 1), 
(12, 92, 1), 
(12, 85, 1), 
(12, 86, 1), 
(12, 96, 1), 
(12, 97, 1), 
(12, 87, 1), 
(25, 85, 1), 
(25, 86, 1), 
(25, 96, 1), 
(25, 97, 1), 
(25, 87, 1), 
(27, 90, 1), 
(27, 95, 1), 
(27, 84, 1), 
(27, 92, 1), 
(38, 73, 1), 
(12, 90, 1), 
(12, 95, 1), 
(12, 84, 1), 
(27, 85, 1), 
(27, 86, 1), 
(27, 96, 1), 
(27, 97, 1), 
(27, 87, 1), 
(39, 73, 2), 
(17, 36, 1), 
(17, 37, 1), 
(17, 38, 1), 
(17, 39, 1), 
(17, 45, 1), 
(17, 46, 1), 
(17, 47, 1), 
(17, 48, 1), 
(17, 55, 1), 
(17, 58, 1), 
(17, 4, 1), 
(17, 5, 1), 
(17, 6, 1), 
(17, 7, 1), 
(17, 8, 1), 
(17, 9, 1), 
(17, 10, 1), 
(17, 11, 1), 
(17, 12, 1), 
(17, 49, 1), 
(17, 57, 1), 
(17, 52, 1), 
(17, 53, 1), 
(17, 29, 1), 
(17, 30, 1), 
(17, 31, 1), 
(17, 32, 1), 
(17, 33, 1), 
(17, 34, 1), 
(17, 35, 1), 
(17, 18, 1), 
(17, 19, 1), 
(17, 20, 1), 
(17, 21, 1), 
(17, 22, 1), 
(17, 23, 1), 
(17, 24, 1), 
(17, 25, 1), 
(17, 26, 1), 
(17, 27, 1), 
(17, 56, 1), 
(28, 82, 1), 
(14, 36, 1), 
(14, 37, 1), 
(14, 38, 1), 
(14, 39, 1), 
(14, 45, 1), 
(14, 46, 1), 
(14, 47, 1), 
(14, 48, 1), 
(14, 55, 1), 
(14, 58, 1), 
(14, 4, 1), 
(14, 5, 1), 
(14, 6, 1), 
(14, 7, 1), 
(14, 8, 1), 
(14, 9, 1), 
(14, 10, 1), 
(14, 11, 1), 
(14, 12, 1), 
(14, 49, 1), 
(14, 57, 1), 
(14, 52, 1), 
(14, 53, 1), 
(14, 29, 1), 
(14, 30, 1), 
(14, 31, 1), 
(14, 32, 1), 
(14, 33, 1), 
(14, 34, 1), 
(14, 35, 1), 
(14, 18, 1), 
(14, 19, 1), 
(14, 20, 1), 
(14, 21, 1), 
(14, 22, 1), 
(14, 23, 1), 
(14, 24, 1), 
(14, 25, 1), 
(14, 26, 1), 
(14, 27, 1), 
(14, 56, 1), 
(12, 1, 1), 
(12, 36, 1), 
(12, 37, 1), 
(12, 38, 1), 
(12, 39, 1), 
(12, 45, 1), 
(12, 46, 1), 
(12, 47, 1), 
(12, 48, 1), 
(12, 55, 1), 
(12, 58, 1), 
(12, 4, 1), 
(12, 5, 1), 
(12, 6, 1), 
(12, 7, 1), 
(12, 8, 1), 
(12, 9, 1), 
(12, 10, 1), 
(12, 11, 1), 
(12, 12, 1), 
(12, 49, 1), 
(12, 57, 1), 
(12, 52, 1), 
(12, 53, 1), 
(12, 29, 1), 
(12, 30, 1), 
(12, 31, 1), 
(12, 32, 1), 
(12, 33, 1), 
(12, 34, 1), 
(12, 35, 1), 
(12, 18, 1), 
(12, 19, 1), 
(12, 20, 1), 
(12, 21, 1), 
(12, 22, 1), 
(12, 23, 1), 
(12, 24, 1), 
(12, 25, 1), 
(12, 26, 1), 
(12, 27, 1), 
(12, 56, 1), 
(28, 74, 1), 
(28, 22, 1), 
(28, 21, 1), 
(28, 20, 1), 
(28, 19, 1), 
(28, 18, 1), 
(28, 55, 1), 
(28, 12, 1), 
(28, 11, 1), 
(28, 7, 1), 
(28, 4, 1), 
(28, 53, 1), 
(28, 52, 1), 
(28, 48, 1), 
(28, 47, 1), 
(28, 46, 1), 
(28, 45, 1), 
(28, 49, 1), 
(28, 58, 1), 
(28, 57, 1), 
(28, 10, 1), 
(28, 5, 1), 
(28, 9, 1), 
(28, 8, 1), 
(28, 30, 1), 
(28, 29, 1), 
(28, 27, 1), 
(28, 26, 1), 
(28, 25, 1), 
(28, 24, 1), 
(28, 23, 1), 
(28, 39, 1), 
(28, 38, 1), 
(28, 37, 1), 
(28, 36, 1), 
(28, 56, 1), 
(28, 35, 1), 
(28, 34, 1), 
(28, 33, 1), 
(28, 32, 1), 
(28, 31, 1), 
(28, 6, 1), 
(16, 36, 1), 
(16, 37, 1), 
(16, 38, 1), 
(16, 39, 1), 
(16, 45, 1), 
(16, 46, 1), 
(16, 47, 1), 
(16, 48, 1), 
(16, 55, 1), 
(16, 58, 1), 
(16, 4, 1), 
(16, 5, 1), 
(16, 6, 1), 
(16, 7, 1), 
(16, 8, 1), 
(16, 9, 1), 
(16, 10, 1), 
(16, 11, 1), 
(16, 12, 1), 
(16, 49, 1), 
(16, 57, 1), 
(16, 52, 1), 
(16, 53, 1), 
(16, 29, 1), 
(16, 30, 1), 
(16, 31, 1), 
(16, 32, 1), 
(16, 33, 1), 
(16, 34, 1), 
(16, 35, 1), 
(16, 18, 1), 
(16, 19, 1), 
(16, 20, 1), 
(16, 21, 1), 
(16, 22, 1), 
(16, 23, 1), 
(16, 24, 1), 
(16, 25, 1), 
(16, 26, 1), 
(16, 27, 1), 
(16, 56, 1), 
(27, 1, 1), 
(27, 36, 1), 
(27, 37, 1), 
(27, 38, 1), 
(27, 39, 1), 
(27, 45, 1), 
(27, 46, 1), 
(27, 47, 1), 
(27, 48, 1), 
(27, 55, 1), 
(27, 58, 1), 
(27, 4, 1), 
(27, 5, 1), 
(27, 6, 1), 
(27, 7, 1), 
(27, 8, 1), 
(27, 9, 1), 
(27, 10, 1), 
(27, 11, 1), 
(27, 12, 1), 
(27, 49, 1), 
(27, 57, 1), 
(27, 52, 1), 
(27, 53, 1), 
(27, 29, 1), 
(27, 30, 1), 
(27, 31, 1), 
(27, 32, 1), 
(27, 33, 1), 
(27, 34, 1), 
(27, 35, 1), 
(27, 18, 1), 
(27, 19, 1), 
(27, 20, 1), 
(27, 21, 1), 
(27, 22, 1), 
(27, 23, 1), 
(27, 24, 1), 
(27, 25, 1), 
(27, 26, 1), 
(27, 27, 1), 
(27, 56, 1), 
(25, 1, 1), 
(25, 36, 1), 
(25, 37, 1), 
(25, 38, 1), 
(25, 39, 1), 
(25, 45, 1), 
(25, 46, 1), 
(25, 47, 1), 
(25, 48, 1), 
(25, 55, 1), 
(25, 58, 1), 
(25, 4, 1), 
(25, 5, 1), 
(25, 6, 1), 
(25, 7, 1), 
(25, 8, 1), 
(25, 9, 1), 
(25, 10, 1), 
(25, 11, 1), 
(25, 12, 1), 
(25, 49, 1), 
(25, 57, 1), 
(25, 52, 1), 
(25, 53, 1), 
(25, 29, 1), 
(25, 30, 1), 
(25, 31, 1), 
(25, 32, 1), 
(25, 33, 1), 
(25, 34, 1), 
(25, 35, 1), 
(25, 18, 1), 
(25, 19, 1), 
(25, 20, 1), 
(25, 21, 1), 
(25, 22, 1), 
(25, 23, 1), 
(25, 24, 1), 
(25, 25, 1), 
(25, 26, 1), 
(25, 27, 1), 
(25, 56, 1), 
(26, 1, 1), 
(26, 36, 1), 
(26, 37, 1), 
(26, 38, 1), 
(26, 39, 1), 
(26, 45, 1), 
(26, 46, 1), 
(26, 47, 1), 
(26, 48, 1), 
(26, 55, 1), 
(26, 58, 1), 
(26, 4, 1), 
(26, 5, 1), 
(26, 6, 1), 
(26, 7, 1), 
(26, 8, 1), 
(26, 9, 1), 
(26, 10, 1), 
(26, 11, 1), 
(26, 12, 1), 
(26, 49, 1), 
(26, 57, 1), 
(26, 52, 1), 
(26, 53, 1), 
(26, 29, 1), 
(26, 30, 1), 
(26, 31, 1), 
(26, 32, 1), 
(26, 33, 1), 
(26, 34, 1), 
(26, 35, 1), 
(26, 18, 1), 
(26, 19, 1), 
(26, 20, 1), 
(26, 21, 1), 
(26, 22, 1), 
(26, 23, 1), 
(26, 24, 1), 
(26, 25, 1), 
(26, 26, 1), 
(26, 27, 1), 
(26, 56, 1), 
(19, 1, 1), 
(19, 36, 1), 
(19, 37, 1), 
(19, 38, 1), 
(19, 39, 1), 
(19, 45, 1), 
(19, 46, 1), 
(19, 47, 1), 
(19, 48, 1), 
(19, 55, 1), 
(19, 58, 1), 
(19, 4, 1), 
(19, 5, 1), 
(19, 6, 1), 
(19, 7, 1), 
(19, 8, 1), 
(19, 9, 1), 
(19, 10, 1), 
(19, 11, 1), 
(19, 12, 1), 
(19, 49, 1), 
(19, 57, 1), 
(19, 52, 1), 
(19, 53, 1), 
(19, 29, 1), 
(19, 30, 1), 
(19, 31, 1), 
(19, 32, 1), 
(19, 33, 1), 
(19, 34, 1), 
(19, 35, 1), 
(19, 18, 1), 
(19, 19, 1), 
(19, 20, 1), 
(19, 21, 1), 
(19, 22, 1), 
(19, 23, 1), 
(19, 24, 1), 
(19, 25, 1), 
(19, 26, 1), 
(19, 27, 1), 
(19, 56, 1), 
(20, 1, 2), 
(20, 36, 2), 
(20, 37, 2), 
(20, 38, 2), 
(20, 39, 2), 
(20, 45, 2), 
(20, 46, 2), 
(20, 47, 2), 
(20, 48, 2), 
(20, 55, 2), 
(20, 58, 2), 
(20, 4, 2), 
(20, 5, 2), 
(20, 6, 2), 
(20, 7, 2), 
(20, 8, 2), 
(20, 9, 2), 
(20, 10, 2), 
(20, 11, 2), 
(20, 12, 2), 
(20, 49, 2), 
(20, 57, 2), 
(20, 52, 2), 
(20, 53, 2), 
(20, 29, 2), 
(20, 30, 2), 
(20, 31, 2), 
(20, 32, 2), 
(20, 33, 2), 
(20, 34, 2), 
(20, 35, 2), 
(20, 18, 2), 
(20, 19, 2), 
(20, 20, 2), 
(20, 21, 2), 
(20, 22, 2), 
(20, 23, 2), 
(20, 24, 2), 
(20, 25, 2), 
(20, 26, 2), 
(20, 27, 2), 
(20, 56, 2), 
(21, 1, 1), 
(21, 36, 1), 
(21, 37, 1), 
(21, 38, 1), 
(21, 39, 1), 
(21, 45, 1), 
(21, 46, 1), 
(21, 47, 1), 
(21, 48, 1), 
(21, 55, 1), 
(21, 58, 1), 
(21, 4, 1), 
(21, 5, 1), 
(21, 6, 1), 
(21, 7, 1), 
(21, 8, 1), 
(21, 9, 1), 
(21, 10, 1), 
(21, 11, 1), 
(21, 12, 1), 
(21, 49, 1), 
(21, 57, 1), 
(21, 52, 1), 
(21, 53, 1), 
(21, 29, 1), 
(21, 30, 1), 
(21, 31, 1), 
(21, 32, 1), 
(21, 33, 1), 
(21, 34, 1), 
(21, 35, 1), 
(21, 18, 1), 
(21, 19, 1), 
(21, 20, 1), 
(21, 21, 1), 
(21, 22, 1), 
(21, 23, 1), 
(21, 24, 1), 
(21, 25, 1), 
(21, 26, 1), 
(21, 27, 1), 
(21, 56, 1), 
(22, 1, 2), 
(22, 36, 2), 
(22, 37, 2), 
(22, 38, 2), 
(22, 39, 2), 
(22, 45, 2), 
(22, 46, 2), 
(22, 47, 2), 
(22, 48, 2), 
(22, 55, 2), 
(22, 58, 2), 
(22, 4, 2), 
(22, 5, 2), 
(22, 6, 2), 
(22, 7, 2), 
(22, 8, 2), 
(22, 9, 2), 
(22, 10, 2), 
(22, 11, 2), 
(22, 12, 2), 
(22, 49, 2), 
(22, 57, 2), 
(22, 52, 2), 
(22, 53, 2), 
(22, 29, 2), 
(22, 30, 2), 
(22, 31, 2), 
(22, 32, 2), 
(22, 33, 2), 
(22, 34, 2), 
(22, 35, 2), 
(22, 18, 2), 
(22, 19, 2), 
(22, 20, 2), 
(22, 21, 2), 
(22, 22, 2), 
(22, 23, 2), 
(22, 24, 2), 
(22, 25, 2), 
(22, 26, 2), 
(22, 27, 2), 
(22, 56, 2), 
(23, 1, 3), 
(23, 36, 3), 
(23, 37, 3), 
(23, 38, 3), 
(23, 39, 3), 
(23, 45, 3), 
(23, 46, 3), 
(23, 47, 3), 
(23, 48, 3), 
(23, 55, 3), 
(23, 58, 3), 
(23, 4, 3), 
(23, 5, 3), 
(23, 6, 3), 
(23, 7, 3), 
(23, 8, 3), 
(23, 9, 3), 
(23, 10, 3), 
(23, 11, 3), 
(23, 12, 3), 
(23, 49, 3), 
(23, 57, 3), 
(23, 52, 3), 
(23, 53, 3), 
(23, 29, 3), 
(23, 30, 3), 
(23, 31, 3), 
(23, 32, 3), 
(23, 33, 3), 
(23, 34, 3), 
(23, 35, 3), 
(23, 18, 3), 
(23, 19, 3), 
(23, 20, 3), 
(23, 21, 3), 
(23, 22, 3), 
(23, 23, 3), 
(23, 24, 3), 
(23, 25, 3), 
(23, 26, 3), 
(23, 27, 3), 
(23, 56, 3), 
(24, 1, 4), 
(24, 36, 4), 
(24, 37, 4), 
(24, 38, 4), 
(24, 39, 4), 
(24, 45, 4), 
(24, 46, 4), 
(24, 47, 4), 
(24, 48, 4), 
(24, 55, 4), 
(24, 58, 4), 
(24, 4, 4), 
(24, 5, 4), 
(24, 6, 4), 
(24, 7, 4), 
(24, 8, 4), 
(24, 9, 4), 
(24, 10, 4), 
(24, 11, 4), 
(24, 12, 4), 
(24, 49, 4), 
(24, 57, 4), 
(24, 52, 4), 
(24, 53, 4), 
(24, 29, 4), 
(24, 30, 4), 
(24, 31, 4), 
(24, 32, 4), 
(24, 33, 4), 
(24, 34, 4), 
(24, 35, 4), 
(24, 18, 4), 
(24, 19, 4), 
(24, 20, 4), 
(24, 21, 4), 
(24, 22, 4), 
(24, 23, 4), 
(24, 24, 4), 
(24, 25, 4), 
(24, 26, 4), 
(24, 27, 4), 
(24, 56, 4), 
(15, 62, 1), 
(15, 72, 1), 
(15, 71, 1), 
(15, 61, 1), 
(15, 60, 1), 
(15, 67, 1), 
(15, 59, 1), 
(15, 70, 1), 
(15, 65, 1), 
(9, 62, 2), 
(9, 72, 2), 
(9, 71, 2), 
(9, 61, 2), 
(9, 60, 2), 
(9, 67, 2), 
(9, 59, 2), 
(9, 70, 2), 
(9, 65, 2), 
(12, 62, 1), 
(12, 72, 1), 
(12, 71, 1), 
(12, 61, 1), 
(12, 60, 1), 
(12, 67, 1), 
(12, 59, 1), 
(12, 70, 1), 
(12, 65, 1), 
(28, 67, 1), 
(28, 62, 1), 
(28, 72, 1), 
(28, 59, 1), 
(28, 70, 1), 
(28, 61, 1), 
(28, 65, 1), 
(28, 71, 1), 
(28, 60, 1), 
(27, 62, 1), 
(27, 72, 1), 
(27, 71, 1), 
(27, 61, 1), 
(27, 60, 1), 
(27, 67, 1), 
(27, 59, 1), 
(27, 70, 1), 
(27, 65, 1), 
(25, 62, 1), 
(25, 72, 1), 
(25, 71, 1), 
(25, 61, 1), 
(25, 60, 1), 
(25, 67, 1), 
(25, 59, 1), 
(25, 70, 1), 
(25, 65, 1), 
(26, 62, 1), 
(26, 72, 1), 
(26, 71, 1), 
(26, 61, 1), 
(26, 60, 1), 
(26, 67, 1), 
(26, 59, 1), 
(26, 70, 1), 
(26, 65, 1), 
(19, 62, 1), 
(19, 72, 1), 
(19, 71, 1), 
(19, 61, 1), 
(19, 60, 1), 
(19, 67, 1), 
(19, 59, 1), 
(19, 70, 1), 
(19, 65, 1), 
(20, 62, 2), 
(20, 72, 2), 
(20, 71, 2), 
(20, 61, 2), 
(20, 60, 2), 
(20, 67, 2), 
(20, 59, 2), 
(20, 70, 2), 
(20, 65, 2), 
(21, 62, 1), 
(21, 72, 1), 
(21, 71, 1), 
(21, 61, 1), 
(21, 60, 1), 
(21, 67, 1), 
(21, 59, 1), 
(21, 70, 1), 
(21, 65, 1), 
(22, 62, 2), 
(22, 72, 2), 
(22, 71, 2), 
(22, 61, 2), 
(22, 60, 2), 
(22, 67, 2), 
(22, 59, 2), 
(22, 70, 2), 
(22, 65, 2), 
(23, 62, 3), 
(23, 72, 3), 
(23, 71, 3), 
(23, 61, 3), 
(23, 60, 3), 
(23, 67, 3), 
(23, 59, 3), 
(23, 70, 3), 
(23, 65, 3), 
(24, 62, 4), 
(24, 72, 4), 
(24, 71, 4), 
(24, 61, 4), 
(24, 60, 4), 
(24, 67, 4), 
(24, 59, 4), 
(24, 70, 4), 
(24, 65, 4), 
(13, 73, 1), 
(15, 73, 1), 
(18, 73, 1), 
(8, 73, 1), 
(9, 73, 2), 
(17, 73, 1), 
(14, 73, 1), 
(12, 73, 1), 
(28, 78, 1), 
(29, 73, 1), 
(9, 86, 2), 
(16, 73, 1), 
(27, 73, 1), 
(25, 73, 1), 
(26, 73, 1), 
(19, 73, 1), 
(20, 73, 2), 
(21, 73, 1), 
(22, 73, 2), 
(23, 73, 3), 
(24, 73, 4), 
(13, 74, 1), 
(13, 75, 1), 
(15, 74, 1), 
(15, 75, 1), 
(18, 74, 1), 
(18, 75, 1), 
(8, 74, 1), 
(8, 75, 1), 
(9, 74, 2), 
(9, 75, 2), 
(9, 90, 2), 
(9, 95, 2), 
(17, 74, 1), 
(17, 75, 1), 
(14, 74, 1), 
(14, 75, 1), 
(12, 74, 1), 
(12, 75, 1), 
(28, 1, 1), 
(28, 73, 1), 
(16, 74, 1), 
(16, 75, 1), 
(27, 74, 1), 
(27, 75, 1), 
(25, 74, 1), 
(25, 75, 1), 
(26, 74, 1), 
(26, 75, 1), 
(19, 74, 1), 
(19, 75, 1), 
(20, 74, 2), 
(20, 75, 2), 
(21, 74, 1), 
(21, 75, 1), 
(22, 74, 2), 
(22, 75, 2), 
(23, 74, 3), 
(23, 75, 3), 
(24, 74, 4), 
(24, 75, 4), 
(3, 73, 1), 
(24, 87, 4), 
(19, 87, 1), 
(26, 85, 1), 
(26, 92, 1), 
(19, 97, 1), 
(19, 96, 1), 
(26, 95, 1), 
(19, 86, 1), 
(26, 84, 1), 
(26, 90, 1), 
(19, 95, 1), 
(22, 90, 2), 
(22, 95, 2), 
(22, 84, 2), 
(22, 92, 2), 
(22, 85, 2), 
(22, 86, 2), 
(22, 96, 2), 
(22, 97, 2), 
(22, 87, 2), 
(21, 90, 1), 
(21, 95, 1), 
(21, 84, 1), 
(21, 92, 1), 
(21, 85, 1), 
(21, 86, 1), 
(21, 96, 1), 
(21, 97, 1), 
(19, 84, 1), 
(21, 87, 1), 
(20, 90, 2), 
(20, 95, 2), 
(20, 84, 2), 
(19, 92, 1), 
(19, 85, 1), 
(20, 97, 2), 
(20, 92, 2), 
(20, 85, 2), 
(20, 86, 2), 
(20, 96, 2), 
(20, 87, 2), 
(19, 90, 1), 
(26, 86, 1), 
(26, 96, 1), 
(28, 77, 1), 
(13, 77, 1), 
(15, 77, 1), 
(18, 77, 1), 
(8, 77, 1), 
(9, 77, 2), 
(26, 97, 1), 
(17, 77, 1), 
(14, 77, 1), 
(12, 77, 1), 
(16, 77, 1), 
(9, 84, 2), 
(27, 77, 1), 
(25, 77, 1), 
(26, 77, 1), 
(19, 77, 1), 
(20, 77, 2), 
(21, 77, 1), 
(22, 77, 2), 
(23, 77, 3), 
(24, 77, 4), 
(29, 1, 1), 
(29, 62, 1), 
(29, 72, 1), 
(29, 71, 1), 
(29, 61, 1), 
(29, 60, 1), 
(29, 67, 1), 
(29, 59, 1), 
(29, 70, 1), 
(29, 65, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 55, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 29, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 56, 1), 
(29, 36, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 57, 1), 
(29, 58, 1), 
(29, 49, 1), 
(29, 45, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 52, 1), 
(29, 53, 1), 
(29, 74, 1), 
(29, 75, 1), 
(29, 77, 1), 
(9, 96, 2), 
(9, 97, 2), 
(9, 87, 2), 
(28, 79, 1), 
(15, 78, 1), 
(15, 79, 1), 
(29, 78, 1), 
(29, 79, 1), 
(9, 78, 2), 
(9, 79, 2), 
(26, 87, 1), 
(25, 90, 1), 
(28, 81, 1), 
(14, 51, 1), 
(12, 78, 1), 
(12, 79, 1), 
(9, 92, 2), 
(9, 85, 2), 
(27, 78, 1), 
(27, 79, 1), 
(25, 78, 1), 
(25, 79, 1), 
(26, 78, 1), 
(26, 79, 1), 
(19, 78, 1), 
(19, 79, 1), 
(20, 78, 2), 
(20, 79, 2), 
(21, 78, 1), 
(21, 79, 1), 
(22, 78, 2), 
(22, 79, 2), 
(23, 78, 3), 
(23, 79, 3), 
(24, 78, 4), 
(24, 79, 4), 
(13, 81, 1), 
(13, 82, 1), 
(15, 81, 1), 
(15, 82, 1), 
(18, 81, 1), 
(18, 82, 1), 
(29, 81, 1), 
(29, 82, 1), 
(8, 81, 1), 
(8, 82, 1), 
(9, 81, 2), 
(9, 82, 2), 
(25, 95, 1), 
(25, 84, 1), 
(17, 81, 1), 
(17, 82, 1), 
(14, 81, 1), 
(14, 82, 1), 
(12, 81, 1), 
(12, 82, 1), 
(16, 81, 1), 
(16, 82, 1), 
(33, 55, 1), 
(27, 81, 1), 
(27, 82, 1), 
(25, 81, 1), 
(25, 82, 1), 
(26, 81, 1), 
(26, 82, 1), 
(19, 81, 1), 
(19, 82, 1), 
(20, 81, 2), 
(20, 82, 2), 
(21, 81, 1), 
(21, 82, 1), 
(22, 81, 2), 
(22, 82, 2), 
(23, 81, 3), 
(23, 82, 3), 
(24, 81, 4), 
(24, 82, 4), 
(31, 73, 2), 
(29, 90, 1), 
(29, 95, 1), 
(29, 84, 1), 
(29, 92, 1), 
(29, 85, 1), 
(29, 86, 1), 
(29, 96, 1), 
(29, 97, 1), 
(29, 87, 1), 
(15, 90, 1), 
(15, 95, 1), 
(15, 84, 1), 
(15, 92, 1), 
(15, 85, 1), 
(15, 86, 1), 
(15, 96, 1), 
(15, 97, 1), 
(15, 87, 1), 
(41, 111, 1), 
(41, 82, 1), 
(41, 106, 1), 
(41, 101, 1), 
(41, 99, 1), 
(41, 100, 1), 
(41, 81, 1), 
(41, 73, 1), 
(41, 110, 1), 
(28, 90, 1), 
(28, 95, 1), 
(28, 84, 1), 
(28, 92, 1), 
(28, 85, 1), 
(28, 86, 1), 
(28, 96, 1), 
(28, 97, 1), 
(28, 87, 1), 
(24, 97, 4), 
(24, 96, 4), 
(24, 86, 4), 
(24, 85, 4), 
(24, 92, 4), 
(24, 84, 4), 
(24, 95, 4), 
(24, 90, 4), 
(8, 100, 1), 
(8, 110, 1), 
(8, 111, 1), 
(8, 101, 1), 
(29, 104, 1), 
(29, 109, 1), 
(29, 98, 1), 
(29, 106, 1), 
(29, 99, 1), 
(29, 100, 1), 
(29, 110, 1), 
(29, 111, 1), 
(29, 101, 1), 
(18, 104, 1), 
(18, 109, 1), 
(18, 98, 1), 
(18, 106, 1), 
(18, 99, 1), 
(18, 100, 1), 
(18, 110, 1), 
(18, 111, 1), 
(18, 101, 1), 
(15, 104, 1), 
(15, 109, 1), 
(15, 98, 1), 
(15, 106, 1), 
(15, 99, 1), 
(15, 100, 1), 
(15, 110, 1), 
(15, 111, 1), 
(15, 101, 1), 
(37, 104, 1), 
(37, 109, 1), 
(37, 98, 1), 
(37, 106, 1), 
(37, 99, 1), 
(37, 100, 1), 
(37, 110, 1), 
(37, 111, 1), 
(37, 101, 1), 
(13, 104, 1), 
(13, 109, 1), 
(13, 98, 1), 
(13, 106, 1), 
(13, 99, 1), 
(13, 100, 1), 
(13, 110, 1), 
(13, 111, 1), 
(13, 101, 1), 
(28, 104, 1), 
(28, 109, 1), 
(28, 98, 1), 
(28, 106, 1), 
(28, 99, 1), 
(28, 100, 1), 
(28, 110, 1), 
(28, 111, 1), 
(28, 101, 1), 
(8, 51, 1), 
(9, 51, 2), 
(28, 51, 1), 
(12, 51, 1), 
(13, 51, 1), 
(15, 51, 1), 
(16, 51, 1), 
(17, 51, 1), 
(18, 51, 1), 
(29, 51, 1), 
(37, 73, 1), 
(37, 81, 1), 
(37, 82, 1), 
(37, 4, 1), 
(37, 5, 1), 
(37, 6, 1), 
(37, 12, 1), 
(37, 8, 1), 
(37, 11, 1), 
(37, 7, 1), 
(37, 9, 1), 
(37, 10, 1), 
(37, 55, 1), 
(37, 18, 1), 
(37, 19, 1), 
(37, 20, 1), 
(37, 21, 1), 
(37, 22, 1), 
(37, 23, 1), 
(37, 24, 1), 
(37, 25, 1), 
(37, 26, 1), 
(37, 27, 1), 
(37, 29, 1), 
(37, 30, 1), 
(37, 31, 1), 
(37, 32, 1), 
(37, 33, 1), 
(37, 34, 1), 
(37, 35, 1), 
(37, 56, 1), 
(37, 36, 1), 
(37, 37, 1), 
(37, 38, 1), 
(37, 39, 1), 
(37, 57, 1), 
(37, 58, 1), 
(37, 49, 1), 
(37, 51, 1), 
(37, 45, 1), 
(37, 46, 1), 
(37, 47, 1), 
(37, 48, 1), 
(37, 52, 1), 
(37, 53, 1), 
(37, 74, 1), 
(37, 75, 1), 
(37, 77, 1), 
(8, 99, 1), 
(8, 106, 1), 
(8, 98, 1), 
(8, 109, 1), 
(8, 104, 1), 
(9, 101, 2), 
(9, 111, 2), 
(9, 110, 2), 
(9, 100, 2), 
(9, 99, 2), 
(9, 106, 2), 
(9, 98, 2), 
(9, 109, 2), 
(9, 104, 2), 
(17, 101, 1), 
(17, 111, 1), 
(17, 110, 1), 
(17, 100, 1), 
(17, 99, 1), 
(17, 106, 1), 
(17, 98, 1), 
(17, 109, 1), 
(17, 104, 1), 
(14, 101, 1), 
(14, 111, 1), 
(14, 110, 1), 
(14, 100, 1), 
(14, 99, 1), 
(14, 106, 1), 
(14, 98, 1), 
(14, 109, 1), 
(14, 104, 1), 
(12, 101, 1), 
(12, 111, 1), 
(12, 110, 1), 
(12, 100, 1), 
(12, 99, 1), 
(12, 106, 1), 
(12, 98, 1), 
(12, 109, 1), 
(12, 104, 1), 
(16, 101, 1), 
(16, 111, 1), 
(16, 110, 1), 
(16, 100, 1), 
(16, 99, 1), 
(16, 106, 1), 
(16, 98, 1), 
(16, 109, 1), 
(16, 104, 1), 
(27, 101, 1), 
(27, 111, 1), 
(27, 110, 1), 
(27, 100, 1), 
(27, 99, 1), 
(27, 106, 1), 
(27, 98, 1), 
(27, 109, 1), 
(27, 104, 1), 
(25, 101, 1), 
(25, 111, 1), 
(25, 110, 1), 
(25, 100, 1), 
(25, 99, 1), 
(25, 106, 1), 
(25, 98, 1), 
(25, 109, 1), 
(25, 104, 1), 
(26, 101, 1), 
(26, 111, 1), 
(26, 110, 1), 
(26, 100, 1), 
(26, 99, 1), 
(26, 106, 1), 
(26, 98, 1), 
(26, 109, 1), 
(26, 104, 1), 
(19, 101, 1), 
(19, 111, 1), 
(19, 110, 1), 
(19, 100, 1), 
(19, 99, 1), 
(19, 106, 1), 
(19, 98, 1), 
(19, 109, 1), 
(19, 104, 1), 
(20, 101, 2), 
(20, 111, 2), 
(20, 110, 2), 
(20, 100, 2), 
(20, 99, 2), 
(20, 106, 2), 
(20, 98, 2), 
(20, 109, 2), 
(20, 104, 2), 
(21, 101, 1), 
(21, 111, 1), 
(21, 110, 1), 
(21, 100, 1), 
(21, 99, 1), 
(21, 106, 1), 
(21, 98, 1), 
(21, 109, 1), 
(21, 104, 1), 
(22, 101, 2), 
(22, 111, 2), 
(22, 110, 2), 
(22, 100, 2), 
(22, 99, 2), 
(22, 106, 2), 
(22, 98, 2), 
(22, 109, 2), 
(22, 104, 2), 
(23, 101, 3), 
(23, 111, 3), 
(23, 110, 3), 
(23, 100, 3), 
(23, 99, 3), 
(23, 106, 3), 
(23, 98, 3), 
(23, 109, 3), 
(23, 104, 3), 
(24, 101, 4), 
(24, 111, 4), 
(24, 110, 4), 
(24, 100, 4), 
(24, 99, 4), 
(24, 106, 4), 
(24, 98, 4), 
(24, 109, 4), 
(24, 104, 4), 
(40, 101, 1), 
(40, 111, 1), 
(40, 110, 1), 
(40, 100, 1), 
(40, 99, 1), 
(40, 106, 1), 
(40, 98, 1), 
(40, 109, 1), 
(40, 104, 1), 
(41, 98, 1), 
(41, 109, 1), 
(41, 104, 1), 
(41, 4, 1), 
(41, 5, 1), 
(41, 6, 1), 
(41, 12, 1), 
(41, 8, 1), 
(41, 11, 1), 
(41, 7, 1), 
(41, 9, 1), 
(41, 10, 1), 
(41, 55, 1), 
(41, 18, 1), 
(41, 19, 1), 
(41, 20, 1), 
(41, 21, 1), 
(41, 22, 1), 
(41, 23, 1), 
(41, 24, 1), 
(41, 25, 1), 
(41, 26, 1), 
(41, 27, 1), 
(41, 29, 1), 
(41, 30, 1), 
(41, 31, 1), 
(41, 32, 1), 
(41, 33, 1), 
(41, 34, 1), 
(41, 35, 1), 
(41, 56, 1), 
(41, 36, 1), 
(41, 37, 1), 
(41, 38, 1), 
(41, 39, 1), 
(41, 57, 1), 
(41, 58, 1), 
(41, 49, 1), 
(41, 51, 1), 
(41, 45, 1), 
(41, 46, 1), 
(41, 47, 1), 
(41, 48, 1), 
(41, 52, 1), 
(41, 53, 1), 
(41, 74, 1), 
(41, 75, 1), 
(41, 77, 1), 
(28, 112, 1), 
(28, 113, 1), 
(15, 112, 1), 
(15, 113, 1), 
(29, 112, 1), 
(29, 113, 1), 
(9, 112, 2), 
(9, 113, 2), 
(12, 112, 1), 
(12, 113, 1), 
(41, 112, 1), 
(41, 113, 1), 
(27, 112, 1), 
(27, 113, 1), 
(25, 112, 1), 
(25, 113, 1), 
(26, 112, 1), 
(26, 113, 1), 
(19, 112, 1), 
(19, 113, 1), 
(20, 112, 2), 
(20, 113, 2), 
(21, 112, 1), 
(21, 113, 1), 
(22, 112, 2), 
(22, 113, 2), 
(23, 112, 3), 
(23, 113, 3), 
(24, 112, 4), 
(24, 113, 4), 
(28, 115, 1), 
(28, 116, 1), 
(13, 115, 1), 
(13, 116, 1), 
(37, 115, 1), 
(37, 116, 1), 
(15, 115, 1), 
(15, 116, 1), 
(18, 115, 1), 
(18, 116, 1), 
(29, 115, 1), 
(29, 116, 1), 
(8, 115, 1), 
(8, 116, 1), 
(9, 115, 2), 
(9, 116, 2), 
(17, 115, 1), 
(17, 116, 1), 
(14, 115, 1), 
(14, 116, 1), 
(12, 115, 1), 
(12, 116, 1), 
(16, 115, 1), 
(16, 116, 1), 
(41, 115, 1), 
(41, 116, 1), 
(27, 115, 1), 
(27, 116, 1), 
(25, 115, 1), 
(25, 116, 1), 
(26, 115, 1), 
(26, 116, 1), 
(19, 115, 1), 
(19, 116, 1), 
(20, 115, 2), 
(20, 116, 2), 
(21, 115, 1), 
(21, 116, 1), 
(22, 115, 2), 
(22, 116, 2), 
(23, 115, 3), 
(23, 116, 3), 
(24, 115, 4), 
(24, 116, 4), 
(43, 55, 1), 
(44, 55, 1), 
(45, 55, 2), 
(46, 55, 3), 
(47, 55, 4), 
(48, 55, 5), 
(49, 47, 2);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_comment`
--

DROP TABLE IF EXISTS `nv4_en_comment`;
CREATE TABLE `nv4_en_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55) NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100) NOT NULL,
  `post_email` varchar(100) NOT NULL,
  `post_ip` varchar(15) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_department`
--

DROP TABLE IF EXISTS `nv4_en_contact_department`;
CREATE TABLE `nv4_en_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `others` text NOT NULL,
  `cats` text NOT NULL,
  `admins` text NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_contact_department`
--

INSERT INTO `nv4_en_contact_department` VALUES
(1, 'Consumer Care Division', 'Consumer-Care', '&#40;08&#41; 38.000.000&#91;+84838000000&#93;', '08 38.000.001', 'customer@mysite.com', 'Receive requests, suggestions, comments relating', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\",\"Full Name\":\"L\\u00ea Trung Ngh\\u0129a\"}', 'Consulting|Complaints|Cooperation', '1/1/1/0', 1, 1, 1), 
(2, 'Technical Department', 'Technical', '&#40;08&#41; 38.000.002&#91;+84838000002&#93;', '08 38.000.003', 'technical@mysite.com', 'Resolve technical issues', '{\"viber\":\"myViber2\",\"skype\":\"mySkype2\",\"yahoo\":\"myYahoo2\",\"Full Name\":\"Nguy\\u1ec5n H\\u1ed3ng \\u0110o\\u00e0n\"}', 'Bug Reports|Recommendations to improve', '1/1/1/0', 1, 2, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_reply`
--

DROP TABLE IF EXISTS `nv4_en_contact_reply`;
CREATE TABLE `nv4_en_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_contact_send`
--

DROP TABLE IF EXISTS `nv4_en_contact_send`;
CREATE TABLE `nv4_en_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100) NOT NULL,
  `sender_email` varchar(100) NOT NULL,
  `sender_phone` varchar(20) DEFAULT '',
  `sender_ip` varchar(15) NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=212  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_contact_send`
--

INSERT INTO `nv4_en_contact_send` VALUES
(1, 1, 'Consulting', 'chào bạn', 'tôi muốn hỏi bạn vài vấn đề', 1439974210, 1, 'admin', 'trungnghiack@gmail.com', '0988491256', '::1', 1, 0), 
(2, 1, 'Consulting', 'trung nghia', 'hello', 1441370810, 1, 'admin', 'trungnghiack@gmail.com', '0933085076', '::1', 1, 0), 
(3, 1, 'Consulting', 'General Information', 'Dear Sirs,<br /><br />We are Sir Meccanica Italy producers of Multifunction Portable Machine Tools. <br /><br />We invite you to view our website, click the link below: <br /><br />Website: http://www.sirmeccanica.com/PL/index.php  <br /><br />WE ARE SEARCHING FOR NEW DEALERS FOR FREE AREAS <br /> <br />Thank you for your attention.', 1460642160, 0, 'Andrea Misitano', 'andrea.m@sirmeccanica.com', '+390961769696', '195.120.76.30', 1, 0), 
(4, 1, 'Consulting', 'Halimbawa ng uri ng tulang patnigan', 'http://stemmeries.xyz <a href=\"http://stemmeries.xyz\">norsk kasino</a> http://stemmeries.xyz - norsk kasino', 1491633322, 0, 'Philipvam', 'jackyapril@gmail.com', '84182249531', '46.161.9.40', 0, 0), 
(5, 1, 'Consulting', 'Vice president student council slogans', 'http://stemmeries.xyz <a href=\"http://stemmeries.xyz\">norsk kasino</a> http://stemmeries.xyz - norsk kasino', 1491661823, 0, 'Philipvam', 'jackyapril@gmail.com', '86572417513', '46.161.9.40', 0, 0), 
(6, 1, 'Consulting', '+917983246213', 'I want tie-up with u regarding for crew Manning. M from Madhuvan ship management Pvt Ltd', 1509439418, 0, 'Sanjay', 'sanjaysaini9927@gmail.com', '+917983246213', '106.202.208.241', 0, 0), 
(7, 1, 'Consulting', 'история футболки', 'интернет магазин клубной одежды заказать! <br />Наши товары: одежда, футболки, майки, толстовки, свитшоты, верхняя одежда, шорты, спортивные брюки, одежда для беременных,<a href=\"http://mayki-ok.ru/product/pad/990448_pad?color=white\">Популярные майки / Каталог / Chevrolet Chevelle SS</a>  и многое другое! <br />*&$*', 1517941837, 0, 'Traceek', 'innokentij.agrippa.92@mail.ru', '83791142469', '46.161.9.39', 0, 0), 
(8, 1, 'Consulting', 'I want to help you', 'Do you want something new? Look at this site. Only here the choice of girls for every taste and completely free! They are obedient slaves, they will do everything you say! <br />http://vik.shortcm.li/trust#1', 1520539848, 0, 'Davidwep', 'alex.m2s@mail.ru', '88535863472', '128.68.30.28', 0, 0), 
(9, 1, 'Consulting', 'Приветствие', 'Вас приветствует сайт рассылки http://r-z-r.ru <br />.', 1520567732, 0, 'r-z-r.ru_lboirl', 'skorpion2310@bigmir.net', '87472299478', '188.165.4.128', 0, 0), 
(10, 1, 'Consulting', 'I want to help you', 'Do you want something new? Look at this site. Only here the choice of girls for every taste and completely free! They are obedient slaves, they will do everything you say! <br />http://vik.shortcm.li/trust#5o', 1520615612, 0, 'Davidwep', 'alex.m2s@mail.ru', '82679596468', '128.68.30.28', 0, 0), 
(11, 1, 'Consulting', 'Looking to purchase materials', 'Hello, my company Enercon GmbH is looking to purchase some safety and other materials for some upcoming wind power projects in Vietnam. Are you available to meet on the 26th or 28th of March? I would like to see what materials are availabe and discuss payment options.', 1521165647, 0, 'Galynn Brackett', 'galynn.brackett@enercon.de', '+84 167 8708596', '172.16.120.145', 0, 0), 
(12, 1, 'Consulting', 'supplier of chemical and dyes', 'Hello sir/mam<br /><br />Our company offering the different inorganic chemicals and dye use in industry. We will provide you  chemicals and dye as per your specification. <br /><br />Please find in attached our Product catalogue.<br /><br />We will give you this product in best price and quality with your specification.<br /><br />if you interested purchase of it so please Kindly inform us your decision as earliest. <br /><br />we are waiting to hear from you.<br /><br />Thanks,<br /><br />Warm Regards,<br />Medfoun pharma & chemicals<br />Chintan Patel (CEO)<br />FF15, Raghukul shopping center, near BRTS road<br />simada naka, surat-395006, Gujarat<br />Mob No.-08460265408<br />Email ID - medfounpharma@gmail.com<br />                  export1.medfounpharma@gmail.com<br />                  purchase.medfounpharma@gmail.com<br />Website - www.medfounpharma.com', 1521434581, 0, 'Chintan Patel', 'medfounpharma@gmail.com', '08460265408', '113.193.196.112', 0, 0), 
(13, 1, 'Consulting', 'Engine spares', 'Hello, do you deal in Polar Nohab / British Polar engine spares? if you do British Polar can supply all the spares your customers may need, we are an OEM manufacturer and lloyds registered ensuring the highest quality of spares as we currently know of several Vietnamese vessels with polar engines, I hope this is of interest and we can discuss further how we can support you.', 1526306758, 0, 'colin murray', 'colin.murray@britishpolarengines.co.uk', '+441414452455', '88.215.17.190', 0, 0), 
(14, 1, 'Consulting', 'engine spares', 'Hello, <br /><br />do you deal in Polar Nohab / British Polar engine spares? if you do British Polar can supply all the spares your customers may need, we are an OEM manufacturer and lloyds registered ensuring the highest quality of spares as we currently know of several Vietnamese vessels with polar engines, I hope this is of interest and we can discuss further how we can support you.', 1526308166, 0, 'Colin Murray', 'colin.murray@britishpolarengines.co.uk', '+441414452455', '88.215.17.190', 0, 0), 
(15, 1, 'Consulting', 'Behold is  offering', 'Ciao! Here is  an important offers for you. http://bit.ly/2rBc2no', 1526818941, 0, 'Geoteuthis', 'pferreira@gmail.com', '14239938881', '95.211.213.234', 0, 0), 
(16, 1, 'Consulting', 'pilot ladder material &amp; Mooring rope', 'OSS Maritime is a leading ship supply co over 30 years  in Australia, we intend order Pilot ladder material & mooring rope & shipment to Melbourne/B Rgds/Alan Hu', 1527471747, 0, 'Alan Hu', 'alanhu@maritimegroup.com.au', '+61 0412219548', '58.179.143.45', 0, 0), 
(17, 1, 'Consulting', 'Looking for the job', 'I m want to looking for job. Rank AB/Riggers', 1528013346, 0, 'Suatno', 'suwatno.1982@gmail.com', '+6281277090041.', '223.255.224.116', 0, 0), 
(18, 1, 'Consulting', 'Important question', 'If you want something new? Look at this page. Only here the choice of hot girls for every unique guy and completely free! They are responsible slaves, they will do everything you command  ! <br />http://gov.shortcm.li/kings#X59', 1529095497, 0, 'Govewep', 'a.s.novikau@gmail.com', '+74996854313', '95.25.47.215', 0, 0), 
(19, 1, 'Consulting', 'Guest Post Enquiry', 'Hello there,<br />     My name is Aly and I would like to know if you would have any interest to promote your website here at vietnamshipsupply.com  on our blog alychidesigns.com ? <br /><br />I am looking for people/businesses that would like to contribute promotional or helpful articles to our blog.<br /><br />If you are willing to post on our site, we would post an promotional link within the article as well as an (optional) author link.<br /> <br />If you may be interested please let me know.<br /><br />Thanks,<br />Aly', 1529395271, 0, 'Aly', 'aly1@alychidesigns.com', '2034559964', '165.231.234.6', 0, 0), 
(20, 1, 'Consulting', 'Ship Supplies in Vietnam.', 'Hello we have our clients who&#039;s ships visit Vietnam ports and we  are looking for a partner in Vietnam who can supply on our behalf. We have local presence in India USA Indonesia and China will be soon. Will you be interested in a meeting next week to discuss this further. I will be visiting HMC soon.<br /><br />Thank you<br /><br />Best regards<br />Saurabh Srivastava MD<br />Www.econavship.com', 1530012573, 0, 'Saurabh Srivastava', 'saurabh@econavship.com', '+919717211010', '150.129.237.140', 0, 0), 
(21, 1, 'Consulting', 'Продвижение сайта', 'Вас приветствует сайт рассылки http://r-z-r.ru <br /> <br />.', 1530564477, 0, 'r-z-r.ru', 'adurupt@wanadoo.fr', '86698799691', '188.165.229.75', 0, 0), 
(22, 1, 'Consulting', 'Important question', 'Do you want something super new? Look at this link. Only there the choice of women for every will and completely free! They are good slaves, they will and want do everything you command ! <br />http://gov.shortcm.li/kings#C37', 1530997735, 0, 'Dovewep', 'ctpahhuk-88@mail.ru', '+74996854313', '95.25.244.147', 0, 0), 
(23, 1, 'Consulting', 'Important question', 'Now you! like something extremely new? Take a look at this page. Only here the choice of horny for every will and completely free! They are wettest slaves, they will and want implement anything you command ! <br />http://gov.shortcm.li/kings1#W34', 1535434283, 0, 'Clieewep', 'duyloc1984@yahoo.com', '+74996854313', '95.25.30.141', 0, 0), 
(24, 1, 'Consulting', 'SBA Capital to Grow Your Business', 'Hi, letting you know that http://FindBusinessFunding-247.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://FindBusinessFunding-247.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these programs now as there is limited availability:', 1536583522, 0, 'FindBusinessFunding247', 'noreply@findbusinessfunding-247.com', '', '193.169.252.17', 0, 0), 
(25, 1, 'Consulting', 'Meet your new sunglasses', 'Hi<br /><br />Buy Oakley Sunglasses 19.95 dollars only today at  https://rbanshop.online<br /><br />All the best,<br /><br /><br />Contact http://vietnamshipsupply.com', 1536973077, 0, 'Freddie', 'gorgen.nilsson@scandidos.com', '916-244-7104', '107.175.6.98', 0, 0), 
(26, 1, 'Consulting', 'Resource Link Enquiry', 'Hello there,<br /><br />My name is Aly and I would like to know if you would have any interest to have your website here at vietnamshipsupply.com promoted as a resource on our blog alychidesigns.com ? <br /><br />We are in the midst of updating our broken link resources to include current and up to date resources for our readers. Our resource links are manually approved allowing us to mark a link as a do-follow link as well<br />.<br />If you may be interested please in being included as a resource on our blog, please let me know.<br /><br />Thanks,<br />Aly', 1536992358, 0, 'Aly', 'aly1@alychidesigns.com', '021 205 54 20', '96.86.62.253', 0, 0), 
(27, 1, 'Consulting', 'Concerning vietnamshipsupply.com', 'Hi,<br /><br />My name is Randy and I was looking at a few different sites online and came across your site vietnamshipsupply.com.  I must say - your website is very impressive.  I found your website on the first page of the Search Engine. <br /><br />Have you noticed that 70 percent of visitors who leave your website will never return?  In most cases, this means that 95 percent to 98 percent of your marketing efforts are going to waste, not to mention that you are losing more money in customer acquisition costs than you need to.<br /> <br />As a business person, the time and money you put into your marketing efforts is extremely valuable.  So why let it go to waste?  Our users have seen staggering improvements in conversions with insane growths of 150 percent going upwards of 785 percent. Are you ready to unlock the highest conversion revenue from each of your website visitors?  <br /><br />TalkWithLead is a widget which captures a website visitor’s Name, Email address and Phone Number and then calls you immediately, so that you can talk to the Lead exactly when they are live on your website — while they&#039;re hot! Best feature of all, we offer FREE International Long Distance Calling!<br />  <br />Try the TalkWithLead Live Demo now to see exactly how it works.  Visit: https://www.talkwithlead.com/Contents/LiveDemo.aspx<br /><br />When targeting leads, speed is essential - there is a 100x decrease in Leads when a Lead is contacted within 30 minutes vs being contacted within 5 minutes.<br /><br />If you would like to talk to me about this service, please give me a call.  We do offer a 14 days free trial.  <br /><br />Thanks and Best Regards,<br />Randy', 1537012832, 0, 'Randy', 'Randy@TalkWithLead.com', '416-385-3200', '107.175.224.209', 0, 0), 
(28, 1, 'Consulting', 'list to by', 'Good afternoon, I would like to make an order. Here is a list of what I would like to buy. <br />http://bit.ly/2PLGntG', 1537448828, 0, 'MichaelTrind', 'gcrcompane@yandex.ru', '258461476', '178.175.132.161', 0, 0), 
(29, 1, 'Consulting', 'Good day&#33;', 'Hi! <br />That is <br />a fine <br />offers for you. <br /> <br />http://bit.ly/2RYSkhw', 1540113962, 0, 'Gregoryboasy', 'mirza_3x3@mail.ru', '325325638', '185.156.174.247', 0, 0), 
(30, 1, 'Consulting', 'Good man&#33;', 'Good man! Here is  a good offers for you. <br /> <br />http://bit.ly/2ET4KW7', 1540443245, 0, 'DanielPex', 'zaitseva_kseniya@mail.ru', '161776558', '185.212.171.101', 0, 0), 
(31, 1, 'Consulting', 'There is offer', 'Hi! Behold is  an important present - Fantastic bonus offers that will double or even triple your deposits if you register casino account in the next 24 hours.  Just click on the link below to qualify. http://bit.ly/2J8P4Mx', 1540638487, 0, 'Hexanchidae', 'playa888_888@hotmail.com', '12288319363', '194.34.132.117', 0, 0), 
(32, 1, 'Consulting', 'Hi&#33;', 'Hi! There is an interesting offer for you. <br /> <br />http://bit.ly/2EK6Wit', 1540849342, 0, 'Davidkat', 'markelova_galina@mail.ru', '286462786', '185.253.96.169', 0, 0), 
(33, 1, 'Consulting', 'Hello&#33;', 'Hi! <br />There is <br />an interesting <br />offering for you. <br />http://bit.ly/2Pxas3K', 1540971265, 0, 'Charlespyday', 'master.vduy@mail.ru', '175176627', '185.163.111.236', 0, 0), 
(34, 1, 'Consulting', 'Please note offers', 'Hi! Look at nice offers for you. <br />http://digig.datedreamon.com/?utm_source=5bcdf3f8d2f30 <br />http://bit.ly/2qmcMMR', 1541262439, 0, 'DavidFit', 'mxxinfo@dalaflyget.se', '262656858', '89.238.186.73', 0, 0), 
(35, 1, 'Consulting', 'Look at an fascinatingforfeit aside bring into play an individual&#039;s nut of you.', 'Hi Look what we accept as one&#039;s own looking inasmuch as you! an foremostoffering <br /> Allowed click <br /> <br /> <br />http://facebook.topratinglist.com?19351', 1541691243, 0, 'BarryCet', 'brandstadgard@sjobo.nu', '132578787', '93.190.139.37', 0, 0), 
(36, 1, 'Consulting', 'That is warm-heartedoffers sign to brainpower of you.', 'Hy there,  What we contemplate here is , mannerlyoffer <br /> Non-partisan click <br /> <br /> <br />https://drive.google.com/file/d/1PlMCwrgY7ajB3_HmpNn1-j-j63ZXk71X/preview', 1542288049, 0, 'BarryCet', 'harsake12@gmail.com', '132578787', '85.206.165.11', 0, 0), 
(37, 1, 'Consulting', 'That is agreeablyregister alongside talk over with of you.', 'Hi What we cause here is , an captivatingsuffer up apropos to the incident that sale <br /> Are you in?  <br /> <br /> <br />https://drive.google.com/file/d/1U8Hk6aMi33DkfdryCfGMRBcUCrfDQk5h/preview', 1542501746, 0, 'Dariustek', 'contact.id@balluff.com.sg', '221432135', '95.174.64.92', 0, 0), 
(38, 1, 'Consulting', 'Here is  a in at the back ofoffers as regards you.', 'Hy there,  Glad admonition ! precisejust now <br /> Moral click on the link controlled by to content  <br /> <br /> <br />https://drive.google.com/file/d/1oxooMPUo7XZ4qRpbv4nF6s8GLqU7HPYs/preview', 1542721475, 0, 'Stephenlon', 'roger.sandberg@newwave.se', '128247664', '185.128.27.168', 0, 0), 
(39, 1, 'Consulting', 'There is a comprehensibleput on the spot b annoy on the sell as regards you.', 'Hi Impartiality a possessions hearsay ! precisesuffer up correct to the fact that available <br /> Unambiguous click on the blood relative inferior to to train  <br /> <br /> <br />https://drive.google.com/file/d/1l4SPye-ja3SoWfxGtMsuUetYhN2nRpnO/preview', 1542957411, 0, 'Oscartet', 'info@klinikestetik.se', '247115523', '194.99.105.44', 0, 0), 
(40, 1, 'Consulting', 'Behold is  a finepremium pay for win.', 'Good man! Behold is  an interesting bonus offers for you.  Just click on the link below to qualify. http://bit.ly/2J9MrdJ', 1543089128, 0, 'Armageddon', 'amitz27@hotmail.com', '16053888406', '89.238.186.72', 0, 0), 
(41, 1, 'Consulting', 'Important question', 'So you need something startup new? Open and look at this link. Only there the choice of horny for every desire and completely free! They are obedient slaves, they will and want do anything you say ! <br />https://rebrand.ly/governy#Q5', 1543277225, 0, 'Clieewep', 'hiroaki@hcm.fpt.vn', '+79169295582', '89.178.89.221', 0, 0), 
(42, 1, 'Consulting', 'No time to post safety blogs for vietnamshipsupply.com?', 'Hello!<br /><br />Great safety content on the website! You know, websites generate organic traffic from their blog, and we feel that you could use a little help, since you are not blogging every day yet.<br /><br />Writing takes a lot of time and energy, and we have just the team from USA/Canada to come up with awesome content you are looking for.<br /><br />You can have your new article to post on your website starting at $10 in as little as 5 business days!<br /><br />Check out our work and reviews from satisfied clients here: http://bit.ly/seowriters<br /><br />Thank you for your time,<br /><br />Have a great day.<br />Tracy<br /><br />Questions? Send a message to our support site or check out the FAQ.<br /><br /><br /><br /><br /><br /><br /><br /><br />You are receiving this email because the contact form at vietnamshipsupply.com is open to the public.', 1543293051, 0, 'Tracy', 'tracy.prettyman47@yahoo.com', '403-782-8219', '77.45.72.7', 0, 0), 
(43, 1, 'Consulting', 'Weekly safety blogger to boost traffic for vietnamshipsupply.com', 'Hi!<br /><br />Great safety content on your website! You know, businesses get free traffic from their blogs, and we feel that you could use a little help, since you are not blogging daily yet.<br /><br />Writing takes a lot of time and energy, and we have just the team from USA/Canada to come up with great writing you are looking for.<br /><br />You can have your new article to post on your website starting at $10 in as little as 5 business days!<br /><br />Check out our work and reviews  here: http://bit.ly/seowriters<br /><br />Thanks for your time,<br /><br />Have a great day.<br />Cindy<br /><br />Questions? Send a message to our support site or check out the FAQ.<br /><br /><br /><br /><br /><br /><br /><br /><br />You are receiving this email because the contact form at vietnamshipsupply.com is open to the public.', 1544338091, 0, 'Cindy', 'hulett.cindy@msn.com', '', '172.218.47.232', 0, 0), 
(44, 1, 'Consulting', 'There is a goodpromotion for your team.', 'Hello! There is nice offers offer for you.   http://bit.ly/2yqyFzd', 1544516139, 0, 'gillig', 'wincall14@hotmail.com', '19086270084', '185.210.217.54', 0, 0), 
(45, 1, 'Consulting', 'Please note a goodoffering for you.', 'Look what we have for you! an interestingoffer <br /> Are you in?  <br /> <br />http://bit.ly/2UzZgD5', 1545136131, 0, 'Thomaseurot', 'jorgen@sbhf.se', '287858337', '46.183.220.180', 0, 0), 
(46, 1, 'Consulting', 'секреты продвижение сайта раскрутка', 'Заказать seo поисковую оптимизацию сайта, Заказать услуги по продвижению сайта По всем возникшим вопросам Вы можете обратиться в скайп логин pokras7777 http://seoprofisional.ru/index.php?route=product/category&path=75 - Аренда выдел', 1545170783, 0, 'JamesdyclE', 'sdrttyu56@mail.ru', '82515631416', '94.181.164.36', 0, 0), 
(47, 1, 'Consulting', 'Подкладочные ковры ANDEREP – эффективное решение для скатной крыши', 'Строительный сезон еще в разгаре, но объекты уже понемногу готовят к зиме. Многие начатые этим летом стройки частных домов возобновятся следующей весной. Читайте об этом подробнее на сайте <a href=\"http://omontazhe.ru\">omontazhe.ru</a>', 1545308640, 0, 'JosephThoni', 'gkarina82@mail.ru', '82282416898', '62.122.88.121', 0, 0), 
(48, 1, 'Consulting', 'vietnamshipsupply.com blog', 'Hi, it&#039;s Gail!<br /><br />Pretty much everyone is using voice search with their Siri/Google/Alexa to ask for services and products now, and next year, it&#039;ll be EVERYONE of your potential clients. Imagine what  you are missing out on.<br /><br />Just now, I can only find vietnamshipsupply.com on text search after going through a few pages (that&#039;s BAD), businesses on top are earning all the traffic and $$$$!<br /><br />Fulfill all your clients&#039; questions on your website and win their business! Learn how simple it is : https://goo.gl/6h8hfW<br /><br />Get your VSO voice search optimized content: https://goo.gl/tQh8J7<br />Starts at $20, regular SEO content starts at $10<br /><br />Cheers,<br />Gail', 1545341720, 0, 'Gail', 'gail.meeson@gmail.com', '08121 50 47 87', '177.135.73.42', 0, 0), 
(49, 1, 'Consulting', 'Behold is  a fineoffer for you.', 'Hy there,  Look what we have for you! an interestingoffers <br /> Just click on the link below to qualify  <br /> <br />http://bit.ly/2rNcteF', 1545581513, 0, 'Shaneteque', 'brightandbeautytherapies@gmail.com', '325556417', '185.206.225.235', 0, 0), 
(50, 1, 'Consulting', 'раскрутка и продвижение сайта', 'Заказать seo поисковую оптимизацию сайта, Заказать услуги по продвижению сайта По всем возникшим вопросам Вы можете обратиться в скайп логин pokras7777 http://seoprofisional.ru/index.php?route=product/category&path=75 - Аренда выдел', 1545712451, 0, 'JamesdyclE', 'pavel_gulkin@mail.ru', '84254195267', '95.152.44.66', 0, 0), 
(51, 1, 'Consulting', 'Behold is  an interestingpromotion for win.', 'Good man! Look at a good news - more than 400 incredible games & 300 top online slots waiting for you.  Try and be our next winner. http://bit.ly/2Jckimk', 1546010327, 0, 'Gomarian', '195319601@qq.com', '16074455303', '95.174.64.71', 0, 0), 
(52, 1, 'Consulting', 'Please note niceoffer for you.', 'Hi Good news ! a goodoffering <br /> Are you in?  <br /> <br />http://bit.ly/2ETRpuL', 1546204528, 0, 'Dannyspeam', 'cmc.caldironi@gmail.com', '241727438', '185.93.180.196', 0, 0), 
(53, 1, 'Consulting', 'vietnamshipsupply.com suggestion', 'Hi, it&#039;s Israel!<br /><br />Almost everyone is using voice search with their Siri/Google/Alexa to ask for services and products  in 2018, and in 2019, it&#039;ll be EVERYONE of your potential customers. Imagine what  you are missing out on.<br /><br />Just now, I can only find vietnamshipsupply.com on text search after going through a few pages (that&#039;s NOT good), competitors above are winning all the traffic and $$$$!<br /><br />Fulfill all your clients&#039; questions on your website and win their trust! Learn how simple it is : https://goo.gl/6h8hfW<br /><br />Get your VSO voice search optimized content: https://goo.gl/tQh8J7<br />Starts at $20, regular SEO content starts at $10<br /><br />Best,<br />Israel', 1546679946, 0, 'Israel', 'rennie.israel@gmail.com', '02174 37 66 69', '197.210.141.22', 0, 0), 
(54, 1, 'Consulting', 'There is a all getoffers as regards you.', 'Look what we bear looking in the course of you! a amicableoblation <br /> Are you in?  <br /> <br /> <br />https://drive.google.com/file/d/1zGcBA11woXfoIussZCRg-MiJcSZ6YuHC/preview', 1546927061, 0, 'Kennethinnot', 'annabelle-rose@gmail.com', '287811143', '92.38.162.11', 0, 0), 
(55, 1, 'Consulting', 'Unlimited Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://UltimateLeadgenerationPack.co is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://UltimateLeadgenerationPack.co <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://UltimateLeadgenerationPack.co <br /> <br />Have a Great Da', 1547454886, 0, 'Unlimited', 'noreply@ultimateleadgenerationpack.co', '', '185.234.219.246', 0, 0), 
(56, 1, 'Consulting', 'Unlimited Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://UltimateLeadgenerationPack.co is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://UltimateLeadgenerationPack.co <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://UltimateLeadgenerationPack.co <br /> <br />Have a Great Da', 1547518883, 0, 'Unlimited', 'noreply@ultimateleadgenerationpack.co', '', '185.234.219.246', 0, 0), 
(57, 1, 'Consulting', 'Unlimited Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://UltimateLeadgenerationPack.co is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://UltimateLeadgenerationPack.co <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://UltimateLeadgenerationPack.co <br /> <br />Have a Great Da', 1547839002, 0, 'Unlimited', 'noreply@ultimateleadgenerationpack.co', '', '185.234.219.246', 0, 0), 
(58, 1, 'Consulting', 'Unlimited Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1549180750, 0, 'Unlimited', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(59, 1, 'Consulting', 'Hy there,  a goodpresent  Are you in?', 'What we have here is , an signaloffer <br /> Are you in?  <br />http://bit.ly/2S6n03o', 1549320538, 0, 'JosephTof', 'nationalreceptionistsday@gmail.com', '355333586', '185.245.85.230', 0, 0), 
(60, 1, 'Consulting', 'We want to have meeting to introduce company through visit', 'First of all, if we introduce our company (Shinwoo E&T), this is official agent of NK group in Korea and NK group is the biggest manufacturer for FF system, BWTS and supplying spare parts.<br />We are interested with new market a lot in Vietnam and we have various experience, good memory through HMD in Vinashin ship building yard such as test commissioning, supplying parts.<br />When we want to search new market, we could found your company on internet and could contacted you.  <br />We plan to visit to Vietnam around the end of February due to other business and then we hope to visit your company.<br />If you have any question, don&#039;t hesitate to contact me as email or phone call.', 1549528082, 0, 'Seo, Ki-won &#40;SHINWOO E&amp;T&#41;', 'kw-seo@swnkcf.com', '+82 10 4784 4312', '59.20.114.186', 0, 0), 
(61, 1, 'Consulting', 'prime korea', 'I’m david lee, I’m in charge of purchasing manager at Prime Korea.<br />Prime Korea (Priko) is a newly established for ship supplies company in Korea.<br />I am considering to visit Vietnam exhibition from March 27 to 29 this year.<br />We are looking for an affiliate or partnership in Vietnam.<br />It was very interesting to see the SHIPSUPPLY  website. So I contacted you.<br />And If you invite us to your company, I am please to go there to see your company and have a meeting with you will it be possible?<br />looking forward your response.<br />Thank you.', 1549940469, 0, 'lee seungjae&#40;david lee&#41;', 'sale3@priko.co.kr', '&#40;+82&#41;1093703', '119.198.226.96', 0, 0), 
(62, 1, 'Consulting', 'Look what we organize with a view you&#33; an dazzlingoffers  To be eligible click on the tie-up in this world', 'Look what we have for you! an fabulousdonation <br /> Are you in?  <br /> <br />http://CI1YW.TK', 1550040688, 0, 'Zacharyneulk', 'colletonbeef@gmail.com', '371423556', '185.93.180.235', 0, 0), 
(63, 1, 'Consulting', 'vietnamshipsupply.com blog', 'Hey, it&#039;s Soon!<br /><br />Almost everyone is using voice search with their Siri/Google/Alexa to ask for services and products  in 2018, and in 2019, it&#039;ll be EVERYONE of your potential clients. Imagine what  you are missing out on.<br /><br />Just now, I can only find vietnamshipsupply.com on text search after digging a few pages (that&#039;s NOT good), businesses above are earning all the traffic and $$$$!<br /><br />Answer all your buyers&#039; questions on your site and earn their business! Find out how simple it is : https://goo.gl/6h8hfW<br /><br />Get your voice search optimized content: https://goo.gl/tQh8J7<br />Starts at $20, regular SEO content starts at $10<br /><br />Best,<br />Soon', 1550100485, 0, 'Soon', 'newquist.soon@gmail.com', '078 3282 5813', '177.55.128.138', 0, 0), 
(64, 1, 'Consulting', 'Sales Offer For Marine Engine and Spare Parts.', 'Dear Sir/ Madam,<br /><br />I would like to introduce our company Master Marine Services.<br /><br />We would like to offer Marine Spare parts to your company.<br /><br /> <br /><br />We introduce ourselves that we are reliable trader / supplier & stockiest of all type / model of Marine / Ship’s Machinery, Spares, Navigation & Electronics Equipment ( New/Second hand/Used in good condition/Re-condition).<br /><br />1.     Main Engine Spares.<br /><br />2.     Complete Gen. Set ( YANMAR, DAIHATSU, SULZER, MAK, WARTSILA, MAN B & W, CAT )<br /><br />3.     Complete Engine and Engine Spares (YANMAR, DAIHATSU, SULZER, MAK, WARTSILA, MAN B & W, CAT )<br /><br />4.     Oil Separator ( ALFA LAVEL, MITSUBISHI, WESTFALIA)<br /><br />5.     Air / Cold Compressors ( HAMWARTHY, HAT LAPA, TANABE, SABROE, SPERRE, DAIKIN, CARRIER )<br /><br />6.     Sea Water Pump.<br /><br />7.     Hydraulic Pump and Motor: (FUKUSHIMA, MITSUBISHI, BRATVAAG, IHI, LINDE, UCHIDA, BOSCH REXROTH, PARKER, DENISON, VICKERS, SAUER DANFOS, KAWASAKI, STAFFA KAWASAKI, NORWICH, LIEBHERR, HAGGLUNDS ETC.<br /><br />8.     Governor (M / E & GENERATOR', 1550203051, 0, 'Md.', 'sales@mastermarinebd.net', '1626706202', '103.99.251.125', 0, 0), 
(65, 1, 'Consulting', 'How to get bitcoin being at work?', 'Hello! <br /> <br />We spend third part of our lives at work. How to spend this time with benefit? <br /> <br />You can grow bitcoins by 10% spending 5 minutes a day! <br />Quicker than a cup of coffee <br /> <br />http://dcbtc.info increases bitcoins by 10% in 48 hours. <br />You will automatically make a profit on your bitcoin wallet. <br /> <br />Start participating and make a profit! <br />Guaranteed by the blockchain technology!', 1550247226, 0, 'JosephWag', 'ghinilambor700@yahoo.com', '357522284', '109.248.149.43', 0, 0), 
(66, 1, 'Consulting', 'Test, just a test', 'Hello. And Bye.', 1550903829, 0, 'JamarShoff', 'yourmail@gmail.com', '86163877161', '185.17.149.135', 0, 0), 
(67, 1, 'Consulting', 'Sexy girls for the night in your town', 'Sexy girls for the night in your town: https://arill.us/getsexinyourcity30544', 1551028549, 0, 'Williamunowl', 'jkettler69@hotmail.com', '87239449346', '185.17.149.135', 0, 0), 
(68, 1, 'Consulting', 'The best women for sex in your town', 'The best girls for sex in your town: http://to.ht/getsexinyourcity66909', 1551130832, 0, 'Williamunowl', 'spain59@hotmail.com', '86436323134', '185.104.184.122', 0, 0), 
(69, 1, 'Consulting', 'Hi What we take here is , a entertainingpresent  Straight click', 'Look what we possess for you! an excitingoffers <br /> Fair-minded click <br /> <br />http://servicerubin.ru', 1551212294, 0, 'PhilipScals', 'tumejorcitaes@gmail.com', '326555735', '185.128.27.124', 0, 0), 
(70, 1, 'Consulting', 'Hy there,  Look what we arrange with a view you&#33; a all rightgift  Are you in?', 'Hey What we accept here is , fineoffer <br /> Are you in?  <br /> <br />https://notifymepush.info/rs/309?count=10&declCount=3', 1551295469, 0, 'Georgenense', 'leanne.scaletta@gmail.com', '121276144', '85.206.165.11', 0, 0), 
(71, 1, 'Consulting', 'The newest Anti-Theft System', 'Hello! I just want to communicate with you about the newest anti-theft systems and RFID inventory.<br />price $ 490  https://fresh222.us/UserFiles/File/USA_Anti-Theft_Retail.pdf', 1551425188, 0, 'Larry', 'info@fresh222.com', '1.312.312.96.08', '179.96.16.101', 0, 0), 
(72, 1, 'Consulting', 'Case Study&#x3A; The Online System That Generated $1.5m in 5 Months', '~~&gt;&gt; http://bit.ly/2SQeAtm  -- On this video we revealed a $1.5M formula (generated online in the last 5 months... without a product!) and broke it all down step by step.', 1552204357, 0, 'HOBERT', 'replay@web-experts.net', '13618209210', '108.62.3.46', 0, 0), 
(73, 1, 'Consulting', 'Turning $10,000 into $1 Million in Forex | DailyForex', 'Forex Trader predicts and makes $10,000 less than 3 hours: http://rih.co/bestinvestcryptobitcoin94145', 1552293471, 0, 'Santospab', 'mmclainabs@yahoo.com', '87684479472', '85.10.56.251', 0, 0), 
(74, 1, 'Consulting', 'How would you use $30,000 to make more money', 'How would you use $30,000 to make more money: http://www.vkvi.net/milliondollars33109', 1552385310, 0, 'Danielsok', 'jshymes@yahoo.com', '82972639964', '185.253.99.156', 0, 0), 
(75, 1, 'Consulting', 'What is the best way to get high quality traffic without seo', 'How to Get More Traffic | Quality Traffic: http://rih.co/getmoretraffic97772', 1552417391, 0, 'Santospab', 'hydrokb00@yahoo.com', '83766237499', '31.7.57.254', 0, 0), 
(76, 1, 'Consulting', 'SEnuke TNG - Rank &#x23;1 With Todays Top Ranking Factors', 'SEnuke TNG 2019 Version Reviewed: DISCOUNT & HUGE BONUS: http://webhop.se/bestseotools88627', 1552575715, 0, 'Kevindem', 'crgarrido@hotmail.com', '84142611113', '161.129.66.106', 0, 0), 
(77, 1, 'Consulting', 'Sexy Girls fur die Nacht in deiner Stadt', 'Treffen Sie sexy Madchen in Ihrer Stadt: https://aaa.moda/bestsexygirlsadultdating95119', 1552652164, 0, 'MiguelBible', 'ckemp33@hotmail.com', '83291235498', '185.130.184.214', 0, 0), 
(78, 1, 'Consulting', '$10000 per day Bitcoin binary options trading platform', '$10000 per day Bitcoin Trading Guide with Broker Reviews and Tutorial - Binary Options: http://to.ht/15000investbinarycrypto81920', 1552966615, 0, 'MiguelBible', 'bullknight@hotmail.com', '87487334567', '185.189.113.41', 0, 0), 
(79, 1, 'Consulting', 'The best girls for sex in your town', 'The best girls for sex in your town: http://www.lookweb.it/adultdating57744', 1553150037, 0, 'Santospab', 'judysofer@hotmail.com', '86814527118', '185.104.184.114', 0, 0), 
(80, 1, 'Consulting', 'The best women for sex in your town', 'The best girls for sex in your town: http://perkele.ovh/adultdating97303', 1553223923, 0, 'Danielsok', 'bejadoo@aol.com', '85573935881', '207.189.0.88', 0, 0), 
(81, 1, 'Consulting', 'The newest Anti-Theft System', 'Hello! I just want to communicate with you about Fast Inventory System.<br />Learn more about our fast RFID inventory system https://fresh222.us/rfid_registration.php <br />Please contact us by info@fresh222.us', 1553505645, 0, 'Larry', 'info@fresh222.com', '1.312.312.96.08', '202.79.34.219', 0, 0), 
(82, 1, 'Consulting', 'Trouvez-vous une fille pour la nuit dans votre ville', 'Trouvez-vous une fille pour la nuit dans votre ville: http://to.ht/bestadultdating79724', 1553580122, 0, 'Kevindem', 'dweezart@yahoo.com', '88515913163', '46.166.143.108', 0, 0), 
(83, 1, 'Consulting', 'Find yourself a girl for the night in your city', 'The best women for sex in your town: http://www.vkvi.net/bestadultdating86076', 1553988514, 0, 'MiguelBible', 'euphoria7402@yahoo.com', '87766137243', '82.102.18.154', 0, 0), 
(84, 1, 'Consulting', 'Sexy girls for the night in your town', 'Beautiful girls for sex in your city: http://to.ht/bestadultdating59869', 1554126495, 0, 'Santospab', 'samyasairy@yahoo.com', '86134876323', '82.102.18.148', 0, 0), 
(85, 1, 'Consulting', 'Invest $ 5,000 in cryptocurrency once and get $ 7,000 passive income per month', 'How to invest in bitcoins $ 5000 - get a return of up to 2000%: http://webhop.se/investcrypto81234', 1554262077, 0, 'Santospab', 'dleed@aol.com', '84445342461', '185.130.184.209', 0, 0), 
(86, 1, 'Consulting', 'Investieren Sie einmalig in den Abbau von Kryptowahrung 5.000 USD und erzielen Sie ein passives Einkommen von 7.000 USD pro Monat', 'Investieren Sie einmalig 5.000 USD in Kryptowahrung und erhalten Sie ein passives Einkommen von 7.000 USD pro Monat: https://lil.ink/investcrypto48557', 1554290879, 0, 'MiguelBible', 'cerise12@hotmail.com', '83882552153', '82.102.18.143', 0, 0), 
(87, 1, 'Consulting', 'TutuApp iOS Download', 'Today anyone has an Android or iOS tablet. This has lead to developing a tons of applications that provide servises such as games, development, entertainment playgrounds and others. To download any of these apps a user must get an account at either Google Play or Apple Store. But not all apps are available there as they don&#039;t meet the official rules. To avoid this a new app was developed called TutuApp. This helper works both on Android and iOS run phones and it has the biggest market of games and apps. We name a few: Spotify, Pokemon, Clash of Clans and many others. They come with zero ads and locked content! Whant to know more? Visit <a href=\"https://tutuapp-app.com\">https://tutuapp-app.com</a> to download TutuApp for free on your Android or iOS phone. Installation instructions for TutuApp are available there.', 1554520943, 0, 'TutuOl', 'sfofdnar@yandex.com', '83419156534', '31.184.238.190', 0, 0), 
(88, 1, 'Consulting', 'Sexy girls for the night in your town', 'The best women for sex in your town: http://goto.iamaws.com/adultdatingincity74723', 1554811257, 0, 'MarcusDic', 'schlitz73@aol.com', '88957225348', '82.102.18.132', 0, 0), 
(89, 1, 'Consulting', 'Beautiful women for sex in your town', 'The best women for sex in your town: http://www.lookweb.it/adultdatingincity23001', 1554818724, 0, 'JeffreyCak', 'haciendalacasona@gmail.com', '81596866662', '185.17.149.180', 0, 0), 
(90, 1, 'Consulting', 'Find yourself a girl for the night in your city', 'Meet sexy girls in your city: http://corta.co/adultdatingincity12001', 1554822283, 0, 'ClintonLex', 'saimaautif@hotmail.com', '87828216662', '185.130.184.204', 0, 0), 
(91, 1, 'Consulting', 'The best girls for sex in your town', 'Find yourself a girl for the night in your city: http://valeriemace.co.uk/adultdatingincity14200', 1554960975, 0, 'MiguelBible', 'jill_valentine_re1-3@hotmail.com', '82477164387', '185.130.184.251', 0, 0), 
(92, 1, 'Consulting', 'Download Xender apk for Android', 'In this age people share videos so many times a day they need a decent and 100% safe application to do this task. Xender app is one of them. With this app you can transfer your photo everywhere you want, from your iOS to computer and vice versa. You may download Xender app from <a href=\"https://xender-download.com\">https://xender-download.com</a> for free!', 1555836648, 0, 'XenEcoff', '4e7dfdg@yandex.com', '85877583528', '31.184.238.190', 0, 0), 
(93, 1, 'Consulting', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million: https://www.governorsclubnc.com/default.aspx?p=TrackHyperlink&url=https://vk.cc/9iSaPJ', 1555929214, 0, 'Santospab', 'complete_jonathan@hotmail.com', '88667525697', '185.104.184.116', 0, 0), 
(94, 1, 'Consulting', 'Cryptocurrency Trading &amp; Investing Strategy for 2019. Receive passive income of $ 7,000 per month', 'How to invest in bitcoins $ 5000 - get a return of up to 2000%: http://www.kamiawase-navi.com/cgi/search/rank.cgi?mode=link&id=1019&url=https://vk.cc/9iSaPJ', 1556069625, 0, 'WalterBug', 'alicia273@hotmail.com', '88595741892', '185.104.184.116', 0, 0), 
(95, 1, 'Consulting', 'Vidmate Download', 'Today almost everyone uses YT or any other video hosting provider to upload and watch videos, free movies and other stuff. But sometimes you want to download a movie or a video and the hosting doesn&#039;t allow you to do it. That&#039;s where Vidmate App is coming to help you out. It helps you to get a movie from may services, including YT, Facebook, Facebook and many other hosting services. To do this you just need to find a video and click &quot;download&quot;. Plus, the application is free of charge and easy in use with your Android phone! Download <a href=\"https://vidmateapp.pro/apk/\">Vidmate APK</a> now and start downloading very entertaining movies to share them with your family and friends!', 1556670382, 0, 'VidmOl', 'ewrdfrgew32f@yandex.com', '88519179144', '31.184.238.190', 0, 0), 
(96, 1, 'Consulting', 'iPhone XS Giveaway Contest - Enter to Win an iPhone XS Free', 'iPhone XS Giveaway Contest - Enter to Win an iPhone XS Free: http://goto.iamaws.com/winiphone69112', 1556710351, 0, 'MiguelBible', 'laketmisif@gmail.com', '88116991683', '207.189.0.85', 0, 0), 
(97, 1, 'Consulting', 'iPhone XS Giveaway Contest - Enter to Win an iPhone XS Free', 'iPhone X Giveaway 2019 - Participate to Win an iPhone X: http://ttree.co/winiphone39076', 1556719171, 0, 'Keithshurn', 'bfcatel@gmail.com', '87586136829', '185.189.113.44', 0, 0), 
(98, 1, 'Consulting', 'Продвижение и создание и  сайта в Google дешево цена в Москве', 'Мы  клиентам  запросов производим раскрутку современные веб-сайты с индивидуальным дизайном ради каждого устройства с соответствующей системой управления и высокими продажами фраз. Мы  Одноклассники  используем множество инструментов поисковой оптимизации (SEO), контентную рекламу, социальные козни и дополнительные ресурсы чтобы продвижения сценариев для продвижения страниц веб людям  в ведущих поисковых системах. Художественное пламя, незабываемый слоган и стильная визитка словосочетаний наверняка расскажут о ваших руках во период переговоров  Вконтакте . Мы обеспечим  клиентам  работу фиксированного сайта и временную оплату, размещение и своевременное обновление сайта. Мы работаем каждый число, для максимизировать эффективность внутренних процессов  Instagram фраз. Работая над любым проектом, мы понимаем, что его главная цель - увеличить прибавление компании  людям <br /><a href=\"https://prodvizhenie-caitov-moskva.ru/\">Продвижение Сайта</a> <br />Если вы запрашиваете сайтов, вы получаете беспл', 1556801858, 0, 'SAITOVkn', 'dimaplu8333@gmail.com', '84735574711', '94.180.240.82', 0, 0), 
(99, 1, 'Consulting', 'The best women for sex in your town', 'Sexy girls for the night in your town: https://aaa.moda/bestadultdating76473', 1557147049, 0, 'ClintonLex', 'annemarie.stramacchia@sothebysrealty.com', '87337632826', '207.189.0.94', 0, 0), 
(100, 1, 'Consulting', 'UPDATE&#x3A; Cryptocurrency Investing Strategy - Q2 2019. Receive passive income of $ 7,000 per month', 'Invest in mining cryptocurrency $ 5000 once and get passive income of $ 7000 per month: https://aaa.moda/investmining36254', 1557251810, 0, 'WalterBug', 'antonnymp@bellsoth.net', '85695655123', '207.189.0.80', 0, 0), 
(101, 1, 'Consulting', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million: http://ttree.co/investmining53770', 1557466485, 0, 'Kevindem', 'annarubbini@yahoo.it', '88126182261', '185.130.184.214', 0, 0), 
(102, 1, 'Consulting', 'How to invest in bitcoins $ 5000 - get a return of up to 2000&#x25;', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million: http://goto.iamaws.com/investmining70035', 1557611857, 0, 'JeffreyCak', 'nance.jacobs@yahoo.com', '83332897471', '207.189.0.86', 0, 0), 
(103, 1, 'Consulting', 'Chris Stapleton Concert Dates', 'Chris Stapleton is my favourite country singer. His strong voice takes me away from all problems of this world so I can enjoy my life and listen songs created by his. Now the singer is on a All-American Road Show Tour started in May of 2019. The concerts scheduled for the whole 2019, up to the second of November. Ticket prices are moderate and available for all men and women with different income. If you love contry music, then you must visit at least one of his concert. All tour dates are available at the <a href=\"https://christapletontour.com\">Chris Stapleton tour Washington</a>. Visit the website and make yourself familiar with all powerful Chris Stapleton concerts in 2019!', 1557815159, 0, 'ChrisOl', 'chrissf@yandex.com', '84381396433', '31.184.238.190', 0, 0), 
(104, 1, 'Consulting', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million', 'How to invest in bitcoins in 2019 and receive passive income of $ 7,000 per month: http://ttree.co/investmining34163', 1557899238, 0, 'JeffreyCak', 'cowdots@yahoo.com', '88997521922', '207.189.0.74', 0, 0), 
(105, 1, 'Consulting', 'Нюансы в ремонте мобильных телефонов Samsung.', 'Смартфоны Samsung представлены на рынке большим ассортиментом в разных ценовых сегментах. Поэтому ремонт мобильных телефонов Самсунг очень актуален востребован на сегодняшний день, подробнее на <a href=\"http://no-lamer.ru\">http://no-lamer.ru</a>', 1558019096, 0, 'Laurasof', 'artemlykov88@mail.ru', '82571687168', '62.122.95.164', 0, 0), 
(106, 1, 'Consulting', 'Profitable base of email addresses - $ 13,000 for 15 days', 'Hey. I will sell a profitable database of email addresses (19 000 000 emails) only to 3 people. <br />As seen on the screenshot below, from May 1 to May 16, I earned $ 13,000 on just one affiliate program. <br />This is a very good result. You will be able to promote your proposals on this database and be in a huge plus. <br />I do not provide email distribution services, I send only my offers. <br />I sell the base because it is a good way to earn extra money + my earnings in affiliate programs, the relevance of the base will not suffer from this. <br />GEO base as you see mainly the United States and other developed solvent countries. <br />I collected the base myself + bought from private sellers which you will not find anywhere else. <br /> <br />Base format: <br />mail1@gmail.com <br />mail@mail.com <br />Mail3@hotmail.com <br />That is, only email addresses in a column. <br />The base price is $ 15,000 only in bitcoins at the current rate. <br />If you know why you need this database, you know how to make mass email mailings and are r', 1558057843, 0, 'Raymondkef', 'rouklove@charter.net', '81428411638', '185.130.184.246', 0, 0), 
(107, 1, 'Consulting', 'Beautiful women for sex in your town UK', 'Beautiful girls for sex in your city: http://webhop.se/bestadultdating87820', 1558410995, 0, 'MarcusDic', 'reecee88@yahoo.com', '85579367699', '185.189.113.44', 0, 0), 
(108, 1, 'Consulting', 'Invest $ 5,000 in cryptocurrency once and get $ 7,000 passive income per month', 'If you invested $1,000 in bitcoin in 2011, now you have $4 million: https://clc.am/zBvD2', 1559783419, 0, 'Cryptocurrency Trading &amp; Investing Strategy for 2019. Receive passive income of $ 7,000 per mont', 'rulphotostudio@gmail.com', '84972177712', '185.130.184.229', 0, 0), 
(109, 1, 'Consulting', 'How To Make $100,000 Per Month With Forex Signals', 'Forex trader makes $10,000 in minutes: http://v.ht/5xGHUe', 1559783493, 0, 'Turning $10,000 into $1 Million in Forex | DailyForex http&#x3A;&#x002F;&#x002F;soo.gd&#x002F;IzpnB', 'kathym@cbwin.com', '88894286498', '82.102.21.117', 0, 0), 
(110, 1, 'Consulting', 'Rencontre des filles sexy dans ta ville USA', 'Sites de rencontre gratuits pour adultes Г  East London: http://tinyurl.com/yxgngebp', 1560183895, 0, 'RobertFup', 'us.easi@yahoo.com', '84137891164', '185.130.184.206', 0, 0), 
(111, 1, 'Consulting', 'Investoi kannabista Kaliforniassa', 'Investoi kannabista Kaliforniassa: https://chogoon.com/srt/d15ro', 1561645592, 0, 'IsmaelCom', 'cdwiles@aol.com', '89964426269', '185.130.184.222', 0, 0), 
(112, 1, 'Consulting', 'Sexy girls in your city are looking for dating', 'Beautiful women are looking for sex in your city: https://chogoon.com/srt/sptgf', 1561962261, 0, 'RobertFup', 'tigercamaroz28@yahoo.com', '85242689835', '134.90.149.146', 0, 0), 
(113, 1, 'Consulting', 'Capital to Grow Your Business', 'Hi, letting you know that http://Business-Capital-Advisors.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://Business-Capital-Advisors.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these programs now as there is limited availabilit', 1562093179, 0, 'BusinessCapitalAdvisors', 'noreply@business-capital-advisors.com', '', '185.234.219.246', 0, 0), 
(114, 1, 'Consulting', 'The best women for sex in your town', 'Beautiful girls for sex in your city: https://hec.su/ju3L', 1562163283, 0, 'RobertFup', 'rodin29@yahoo.com', '88137276563', '134.90.149.150', 0, 0), 
(115, 1, 'Consulting', 'The best women for sex in your town', 'Young girls are looking for sex in your city: https://chogoon.com/srt/aem7x', 1562203538, 0, 'JosephUphor', 'snehal7001@yahoo.ca', '86437461144', '213.159.15.92', 0, 0), 
(116, 1, 'Consulting', 'Women are looking for sex in your city', 'Meet a beautiful girl for sex right now: https://chogoon.com/srt/cxr5a', 1562431192, 0, 'Keithshurn', 'jwerk10@gmail.com', '88222371928', '89.36.224.10', 0, 0), 
(117, 1, 'Consulting', 'Treffen Sie lokale Frauen, die heute Abend Sex auf XPress suchen', 'Die besten Frauen fГјr Sex in Ihrer Stadt: https://hideuri.com/K0k6oY?&rutjm=tVtmHgf', 1562929412, 0, 'IsmaelCom', 'davenicolai@kw.com', '81733277791', '185.17.149.136', 0, 0), 
(118, 1, 'Consulting', 'SchГ¶ne MГ¤dchen fГјr Sex in deiner Stadt', 'SchГ¶ne Frauen suchen Sex in Ihrer Stadt: https://hideuri.com/KAP1y0?ZFVg0', 1563174251, 0, 'IsmaelCom', 'gonzalezgrisselle@g-mail.com', '86844673535', '185.17.149.171', 0, 0), 
(119, 1, 'Consulting', 'How to Get More Leads', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1563249923, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.17', 0, 0), 
(120, 1, 'Consulting', 'Capital for Your Business', 'Hi, letting you know that http://ProFunding247.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://ProFunding247.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these programs now as there is limited availability: <br /> <br />http://ProFundin', 1563468905, 0, 'ProFunding247', 'noreply@profunding247.com', '', '140.227.170.176', 0, 0), 
(121, 1, 'Consulting', 'Ортопедическая обувь продажа низкая цена', 'Массажеры медицинская упаковка чтобы стерилизации. массажеры Используются доставка не всего в кабинетах врача, однако и в санаториях и массажных кабинетах бассейна. Медицинские банки от 2 прежде. Это хорошая мочь превратить большое цифра из них в сезон медицинские изделия. Незамысловатый дизайн головы купить, ног и ступней может водиться восстановлен после наушники и функциональные модели. У пациентов могут быть разные позиции на скамейке. Использование медицинской мебели также важно ортопедическая обувь купить. Самым надежным металлическим каркасом доставка является коррозия. Ложе может попадаться изготовлена из картона иначе картона, наполненного пеной, полиэстером alias другими материалами ортопедическая обувь продажа <br /><a href=\"https://medortomir.ru/catalog/ortopedicheskaya-obuv/detskaya-ortopedicheskaya-obuv/\">ортопедическая обувь каталог</a> <br />Пригодность пациентов заказать и поставщиков медицинских услуг зависит от качества кушеток. Когда вам нужен сподручный ложе на долгое время.', 1563889295, 0, 'Medicinakn', 'dimaplu8333@gmail.com', '88327579843', '94.180.219.229', 0, 0), 
(122, 1, 'Consulting', 'Продвижение и создание и  сайта в поисковых системах дешево цена в Казани', 'Глубокомысленный, функциональный и незатейный в использовании веб порталов интернет-магазин  чтобы тех, кто хочет заработать на электронной коммерции. У ритейлеров есть мочь воспитывать принадлежащий бизнес заказчики и привлекать новых клиентов сайтов . Достоинство создания улучшения сайта зависит через сложности и масштаба бизнеса. Неужто это не уникальная занятие CMS для запуска сайтов ? Мы поможем вам сделать ваш сайт в КАЗАНИ вывода с модными идеями и необычными методами магазинов . Обсудите и положите магазинов  особенный мобильный телефон веб порталов мужских товаров  в форму клиенты ниже раскрутки. Внешняя конверт бренда, такая якобы бренд, логотип и фирменный стиль, должна соответствовать бренду компании, какой бесспорно может создать могучий бренд. В настоящее эра обновление сайта является законным страниц , незаконным, больно эффективным и может пребывать неэффективным сайтов раскрутки <br /><a href=\"https://seo-saitov.ru\">Продвижение сайта казань</a>  <br />Не дорого и бесплатно улучш', 1563952975, 0, 'CAITOVkn', 'dimaplu8333@gmail.com', '84952379116', '94.180.215.181', 0, 0), 
(123, 1, 'Consulting', 'vietnamshipsupply, Many thanks&#33; Ya voted us…&#x3A; The BEST resource to get', 'vietnamshipsupply,<br /><br />Don&#039;t you wish you were Instagram famous?<br /><br />If you are like me, you have scrolled through Instagram, thinking &quot;how do these friggin people on Instagram get so famous&quot;?<br /><br />Imagine: it is Friday morning and you told yourself you’d hit the gym today.<br /> <br />You spring up to check your cell. <br /><br />Make your way to your page. <br /><br />Whoaaa, you think, Over 800 likes on one picture.<br /> <br />You put your super-duper soft slippers on and head to the kitchen for some tea. After putting on the kettle, you pull out your phone again.<br /><br />Presto! Another 63 likes. <br />  <br />Buzz—a message pops into your inbox from a follower. They are asking you for advice on how you manage your food, and are congratulating you on your third month of hitting the gym.<br /><br />The kettle blows and you pour your tea. When you flip out your phone, there is another message--this time from a young girl--thanking you for posting. She follows you religiously and your&#039;e an inspiration.<br /> <br />Within minutes, your cell buzzes AGAIN.<br /><br />It&#039;s another message coming in. You glance up at the clock--almost time for the gym. You&#039;ll have to hit them up later.<br />Let&#039;s stop the simulation there. Most people have a hard time getting what they want in life. People can hardly get themselves to eat a good breakfast.<br /><br />I’m going to show you how to take the reigns of your Instagram.<br /><br />Imagine if you increased your popularity by 100%, or 1000%?<br /> <br />It is not complicated to do, although almost no one does. Just visit our website. There, you will learn how to garner Instagram likes and followers like mad...easily.<br /><br />Automagically see tons of likes on your images just minutes after posting.<br /><br />The &quot;Top Post&quot; section, all of a sudden, doesn&#039;t seem that far away.<br /><br />This is all great, but you have really got to put in the work to make it happen. Actually, it&#039;s not real work.<br />1. Visit https://tomm.pw<br />2. Enter in your Instagram username.<br />3. 10 - 15 likes are going to be sent to your 3 most recent pictures. Just like that.<br /><br />Being a regular on that page will accelerate your growth 10x, easy.  But if you want the fame, you’ve got to reach for it. Are you ready?<br /><br />Happy image-uploading.', 1564063970, 0, 'Joanne', 'joanne.sauer@yahoo.com', '936-824-3517', '145.239.106.107', 0, 0), 
(124, 1, 'Consulting', 'Marine spare parts', '27 JULY 2019<br /><br />Dear sir/ Mohsen Moghadam<br /><br />Good day<br /><br />We want To sale Below Turbo charger &Oil separator.liner. Hydraulic pump  In Ready Our Stock .<br /><br /><br />       TURBO CHARHER<br /><br /> 01.VTR  714-32     Quantity  3 Pcs<br /><br /> 02.VTR  564D-32     Quantity  1 Pcs<br /><br /> 03.VTR  454-32     Quantity  2 Pcs<br /><br /> 04.VTR  304-11     Quantity  2 Pcs  <br />05.VTR 214-11 Quantity  2 Pcs  <br /><br />06.VTR  254-11    Quantity  1 Pcs<br /><br /> 07.VTR  354 P11   Quantity 2 pcs<br /><br /> 08.N-110 J-2         Quantity  1 Pcs<br /><br />           MITSUBISHI MAN<br /><br />01. NA  57 TD 706 Quantity 2 Pcs<br /><br />02. NA  70 TD 724 Quantity 2 Pcs<br /><br />03. NA 70 TD 4035T Quantity 2 Pcs<br /><br />04. NA 57 Quantity  2 Pcs<br /><br />05. MET 53 SD  Quantity 3 Pcs<br /><br />06. MET 53 SB  Quantity 2 Pcs<br /><br />07.MET 83 SE   Quantity 2  pcs<br /><br />          SEPARATAR<br /><br />01. TYPE- FOPX 613 TFD-24-60 Quantity 2 Pcs<br /><br />02. TYPE- FOPX 609 TFD-24-60  Quantity 3 Pcs<br /><br />03. TYPE- OTA 20-0136-66 Quantity 3 Pcs<br /><br />04. TYPE- SJ 16T Quantity 1 Pcs<br /><br />05. TYPE- SJ 25T Quantity 1 Pcs<br /><br />06. TYPE- SJ 3000 Quantity 2 Pcs<br /><br />07  TYPE- SJ 80 EH Quantity 1 Pcs', 1564207812, 0, 'Alauddin patwary', 'alauddinpatwary414@gmail.com', '+8801624871228', '45.124.13.80', 1, 0), 
(125, 1, 'Consulting', 'Marine spare parts', '27 JULY 2019<br /><br /><br />Dear Sir/Madam<br /><br />Good Day<br /><br /> <br /><br />We are Amarine International From Bangladesh, Supplier of All types of Ship Equipment’s in All over World.<br /><br />We have Totally Solutions for needed items which use in Ship. if new or service, as per need.<br /><br />We also provide On board Service in Bangladesh at Chittagong and Mongla Port to our honourable customer .<br /><br />We believe in Quality of Goods, Important of Timing, Door to Door Delivery & Satisfaction of Users.<br /><br />We have large Experience of Supply Goods, On board Services & Goods Services.<br /><br />At present our supplied goods are well performing in the fleets functioning in the world.<br /><br /> <br /><br />Our Mainly Service in…<br /><br />•       Main Engine & Spares<br /><br />•       Aux Engine & Spares<br /><br />•       Hydraulic motor & pump<br /><br />•       Deck items<br /><br />•       Electrical & Electronics equipment<br /><br />•       Radar’s<br /><br />•       Safety Equipment’s <br /><br />•       Oil Purifiers<br /><br />•       Heat Exchangers<br /><br />•       AC-DC Drive<br /><br />•       Breathing Compressor<br /><br />•       Main Air Compressor etc.<br /><br /> .    Turbo ch', 1564208440, 0, 'Alauddin patwary', 'alauddinpatwary414@gmail.com', '+8801624871228', '45.124.13.80', 0, 0), 
(126, 1, 'Consulting', 'SBA Loans for Your Business', 'Quicker and Easier than the SBA, http://Business-Capital-Advisors.com can get your business a loan for $2K-350,000 With low-credit and without collateral. <br /> <br />Use our 1 minute form to Find Out exactly how much you can get, No-Cost: <br /> <br />http://Business-Capital-Advisors.com <br /> <br />If you&#039;ve been established for at least 1 year you are already pre-qualified. Our Quick service means funding can be finished within 48 hours. Terms are specific for each business so I suggest applying to find out exactly how much you can get. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. Funds are also Non-Restrictive, allowing you to use the whole amount in any way including bills, taxes, hiring, marketing, expansion, or Absolutely Any Other expense. <br /> <br />There are limited SBA and private funds available so please apply now if interested, <br /> <br />Click Here: http://Business-Capital-Advisors.com <br /> <br />Have a great day, <br />The Business Capi', 1564391048, 0, 'BusinessCapitalAdvisors', 'noreply@business-capital-advisors.com', '85353241944', '185.234.219.246', 0, 0), 
(127, 1, 'Consulting', 'Автоматизация технологических процессов', 'Доброе утро. <br />Оказываем услуги: <br />модернизация промышленного оборудования, ремонт устройств плавного пуска, ремонт силовой электроники, наладка промышленной автоматики, ремонт промышленной электроники, автоматизация технологических процессов, ремонт частотных преобразователей: <br />EI-7011-400H, EI-9011-020H, CIMRG7C40900B, ATV71HC13N4, CIMR-F7Z41600B, CIMRG7C40P71B, FR-Z240-2.2K-UL, CIMRF7Z41101B, CIMR-F7A41850, VFD185VL43A, ATV58HD12N4ZU, ATV212HU15N4, EMX3-0650C-411, M700-03200080A, EQ5-4300-C, CIMR-E7Z40300A, ATV71HD37N4S337, M600-03400062A, FR-A220-0.4K-UL, FR-S520-0.4K, EMX3-0100B-411, SJ700-220LFUF2, SJ700-4000HFU2, ATV71HC31N4D, VZA20P7BAA-S5030, FR-F520-15K, CIMR-F7C20900, FR-E720-050, ATV71EXC5C25N4, ATV61EXS5C40N4, M800-05200250A, ATV61HD11N4, P3-E540-0.75K, ATV61QC63N4, ATV61E5U40N4, FR-D740-012, CIMRV7TC24P07, E3-8100-003H, CFW700E211T4DBN1C3, CIMRJ7AZ20P10, CIMRV7CU40P74, ATV212WD11N4C, WJ200-002SF, FR-F740-01800, ATV71EXC2C25Y, ATS22D88S6, P3-E540-7.5K, MA7200-4001-N1, M10', 1564866380, 0, 'ChecheninRW', 'djen3white@yandex.com', '85119255414', '85.209.90.108', 0, 0), 
(128, 1, 'Consulting', 'кредитные карты без справок', 'В мегаполисах и малых городах России Совкомбанк известен как надежный и выгодный финансовый партнер. Полный пакет лицензий и сертификатов позволяет Совкомбанку оказывать широкий спектр финансовых услуг. <br /> <br />Миссия Банка - предоставлять каждому клиенту максимально возможный набор банковских услуг высокого качества и надежности, следуя мировым стандартам и принципам корпоративной этики. Наш Банк - это современный высокотехнологичный банк, сочетающий в себе новейшие технологии оказания услуг и лучшие традиции банковского сообщества и российского предпринимательства. <br /> <br />Взять кредит по этой ссылке ===&gt; http://v.ht/X3Qnq', 1564990244, 0, 'Wilburnpault', 'a.l.la.k.o.belev.a@bk.ru', '83945657757', '96.44.147.122', 0, 0), 
(129, 1, 'Consulting', 'Upgrade your content game with professional article &amp; blog post services', 'Do you need articles, blog post or any other content for your website? Upgrade your content game with professional article & blog post services. Price starts at 5$. Professional sellers. Unbeatable value.<br /><br />Find out more: http://bit.ly/article-blog-writing-service', 1566851795, 0, 'Tania', 'tania.mchale@msn.com', '04531 31 13 79', '5.157.24.66', 0, 0), 
(130, 1, 'Consulting', 'vietnamshipsupply.com - get high quality backlinks now', 'Hi, I just visited vietnamshipsupply.com and thought I would reach out to you. <br /><br />I wanted to encourage you to buy backlinks that will boost ranks and SEO metrics. We offer the best quality backlinks at great prices. Take a look at our website - http://bit.ly/orderbacklinks - you&#039;ll find all the information there. I assure you that it is worth it.<br /><br />Boost to your website rankings! Buy high quality backlinks.<br /><br />http://bit.ly/orderbacklinks<br /><br />Best regards<br />Mike', 1566916248, 0, 'Order', 'orderbacklinks.net@gmail.com', '01.51.93.05.98', '50.3.197.164', 0, 0), 
(131, 1, 'Consulting', 'Mailing via the feedback form.', 'Good day!  vietnamshipsupply.com <br /> <br />We make offer for you <br /> <br />Sending your business proposition through the Contact us form which can be found on the sites in the Communication section. Contact form are filled in by our application and the captcha is solved. The profit of this method is that messages sent through feedback forms are whitelisted. This method raise the chances that your message will be read. <br /> <br />Our database contains more than 25 million sites around the world to which we can send your message. <br /> <br />The cost of one million messages 49 USD <br /> <br />FREE TEST mailing of 50,000 messages to any country of your choice. <br /> <br /> <br />This message is automatically generated to use our contacts for communication. <br /> <br /> <br /> <br />Contact us. <br />Telegram - @FeedbackFormEU <br />Skype  FeedbackForm2019 <br />Email - FeedbackForm@make-success.com', 1567002399, 0, 'DavidTrist', 'raphaePabutle@gmail.com', '85783292512', '108.62.96.59', 0, 0), 
(132, 1, 'Consulting', 'It’s all about Perfect Timing', 'Hello vietnamshipsupply.com,<br /><br />People ask, “why does TalkWithCustomer work so well?”<br /><br />It’s simple.<br /><br />TalkWithCustomer enables you to connect with a prospective customer at EXACTLY the Perfect Time.<br /><br />- NOT one week, two weeks, three weeks after they’ve checked out your website vietnamshipsupply.com.<br />- NOT with a form letter style email that looks like it was written by a bot.<br />- NOT with a robocall that could come at any time out of the blue.<br /><br />TalkWithCustomer connects you to that person within seconds of THEM asking to hear from YOU.<br /><br />They kick off the conversation.<br /><br />They take that first step.<br /><br />They ask to hear from you regarding what you have to offer and how it can make their life better. <br /><br />And it happens almost immediately. In real time. While they’re still looking over your website vietnamshipsupply.com, trying to make up their mind whether you are right for them.<br /><br />When you connect with them at that very moment it’s the ultimate in Perfect Timing – as one famous marketer put it, “you’re entering the conversation already going on in their mind.”<br /><br />You can’t find a better opportunity than that.<br /><br />And you can’t find an easier way to seize that chance than TalkWithCustomer. <br /><br />CLICK HERE http://www.talkwithcustomer.com now to take a free, 14-day test drive and see what a difference “Perfect Timing” can make to your business.<br /><br />Sincerely,<br />Eric<br /><br />PS:  If you’re wondering whether NOW is the perfect time to try TalkWithCustomer, ask yourself this:<br />“Will doing what I’m already doing now produce up to 100X more leads?”<br />Because those are the kinds of results we know TalkWithCustomer can deliver.  <br />It shouldn’t even be a question, especially since it will cost you ZERO to give it a try. <br />CLICK HERE http://www.talkwithcustomer.com to start your free 14-day test drive today.<br /><br />If you&#039;d like to unsubscribe click here http://liveserveronline.com/talkwithcustomer.aspx?d=vietnamshipsupply.com', 1567337573, 0, 'Eric', 'eric@talkwithcustomer.com', '416-385-3200', '45.61.171.156', 0, 0), 
(133, 1, 'Consulting', 'YOU ARE A WINNER&#33;', 'We would like to inform that you liked a comment ID:35915743 in a social network , January 9, 2019 at 19:48 <br />This like has been randomly selected to win the seasonal «Like Of The Year» 2019 award! <br />http://facebook.comпјЏemailпјЏ@0X4E18DCC7/7xzKn', 1568507213, 0, 'DorothyRer', 'thomas.hauke@ammersin.at', '87813523127', '84.17.47.135', 0, 0), 
(134, 1, 'Consulting', 'YOU ARE A WINNER&#33;', 'We would like to inform that you liked a comment ID:35915743 in a social network , January 9, 2019 at 19:48 <br />This like has been randomly selected to win the seasonal «Like Of The Year» 2019 award! <br />http://facebook.comпјЏemailпјЏ@0X4E18DCC7/2RSeL', 1568569307, 0, 'CherylDug', 'contact@falsarella-decoration.ch', '83346925453', '37.120.143.59', 0, 0), 
(135, 1, 'Consulting', 'Capital For Your Business', 'Hi, letting you know that http://Business-Funding-247.com?url=vietnamshipsupply.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://Business-Funding-247.com?url=vietnamshipsupply.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these pr', 1569267052, 0, 'BusinessFunding247', 'noreply@business-funding-247.com', '', '95.179.168.249', 0, 0), 
(136, 1, 'Consulting', 'SUPPLY FLAG OF TAIWAN at Port of Da Nang', 'Hi. We are Fukuno International from Tokyo, Japan.<br />Our client vessel call Port of Da Nang on Oct 8th.<br />Would you please estimate following Flag of Taiwan and loading cost until vessel?<br /><br />FLAG of TAIWAN (4ft x 6ft) x 1PC<br /><br />I look forward to your reply.<br /><br />Best Regards,<br /><br />Fukuno International<br />Yasuhiro Imai', 1570155547, 0, 'YASUHIRO IMAI', 'marine@fukuno.co.jp', '81-3-5492-7297', '165.100.139.49', 0, 0), 
(137, 1, 'Consulting', 'SBA Capital for Your Business', 'Faster and Easier than the SBA, http://Business-Funding-365.com?url=vietnamshipsupply.com can get your business a loan for $2K-350,000 With low-credit and without collateral. <br /> <br />Use our 1 minute form to See exactly how much you can get, No-Cost: <br /> <br />http://Business-Funding-365.com?url=vietnamshipsupply.com <br /> <br />If you&#039;ve been in business for at least 1 year you are already pre-qualified. Our Quick service means funding can be completed within 48hrs. Terms are specific for each business so I suggest applying to find out exactly how much you can get. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. Funds are also Non-Restrictive, allowing you to use the full amount in any way including bills, taxes, hiring, marketing, expansion, or Absolutely Any Other expense. <br /> <br />There are limited SBA and private funds available so please apply now if interested, <br /> <br />Click Here: http://Business-Funding-365.com?url=vietnamshi', 1570443721, 0, 'BusinessFunding365', 'noreply@business-funding-365.com', '', '18.130.127.173', 0, 0), 
(138, 1, 'Consulting', 'YOU ARE A WINNER&#33;&#33;&#33;', 'We would like to inform that you liked a comment ID:35915743 in a social network , January 9, 2019 at 19:48 <br />This like has been randomly selected to win the seasonal «Like Of The Year» 2019 award! <br />http://facebook.comпјЏemailпјЏ@0X4E18DCC7/VR59k', 1570811466, 0, 'Dorothyrhymn', 'elisabeth@heiligefamilie.eu', '86246494134', '37.120.142.147', 0, 0), 
(139, 1, 'Consulting', 'YOU ARE A WINNER&#33;', 'We would like to inform that you liked a comment ID:35915743 in a social network , January 9, 2019 at 19:48 <br />This like has been randomly selected to win the seasonal «Like Of The Year» 2019 award! <br />http://facebook.com+mail+@1310252231/6Kuy1', 1570925259, 0, 'CrystalOpemo', 'consulting-lehner@baukg.at', '85875853958', '37.120.142.147', 0, 0), 
(140, 1, 'Consulting', 'unique domains backlinks package', 'When you order 1000 backlinks with this service you get 1000 unique domains, Only receive 1 backlinks from each domain. All domains come with DA above 15-20 and with actual page high PA values. Simple yet very effective service to improve your linkbase and SEO metrics. <br /> <br />Order this great service from here today: <br />https://monkeydigital.co/product/unique-domains-backlinks/ <br /> <br />Multiple offers available <br /> <br />thanks and regards <br />Mike <br />support@monkeydigital.co', 1571129567, 0, 'MikeBreet', 'rodgerJap@outlook.com', '86136415642', '84.17.58.70', 0, 0), 
(141, 1, 'Consulting', 'Get on google&#039;s 1st page with this wordpress plugin', 'Hi vietnamshipsupply.com admin, <br /> <br />Getting your site to rank high for popular searches on Google can transform your business and your life. <br />Considering that nowadays the most important factor in search engines ranking is original content, you will get on google’s first page in just weeks, using this new plugin: <br /> <br />https://wpnewsranker.customerreviews.biz <br /> <br />WP News Ranker is an AUTOMATED WordPress Plugin that will create original content for your site every day that is on-trend, in the news, unique, and answers what people are actively searching for right now. <br /> <br />Learn more about WP News Ranker here: https://wpnewsranker.customerreviews.biz <br /> <br />Best regards', 1571159222, 0, 'HarryDOR', 'seowpnr@cyber-wizard.com', '83557357543', '84.17.62.143', 0, 0), 
(142, 1, 'Consulting', 'Ultimate Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1571683524, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '165.227.28.223', 0, 0), 
(143, 1, 'Consulting', '85&#x25; off your favorites', 'Good day <br /> <br />We are a manufacturer. We wholesale LV bags at a wholesale price.  Please check our albums and send me your order list.  I will send you the price details ASAP. <br /> <br />Our albums：https://shorta.ml/2u8 <br /> <br />Also please send me what you want if the products are not listed on our albums. <br /> <br />Email Us: onlinesalevip@gmail.com <br /> <br />Cheers, <br /> <br />Contact - vietnamshipsupply.com', 1572247952, 0, 'Michaelbleta', 'hjyrirna@sharklasers.com', '85766138574', '199.187.211.105', 0, 0), 
(144, 1, 'Consulting', 'Capital For Your Business', 'Hi, letting you know that http://BusinessLoansFundedNow.com?url=vietnamshipsupply.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://BusinessLoansFundedNow.com?url=vietnamshipsupply.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at thes', 1572550726, 0, 'BusinessLoansFundedNow', 'noreply@businessloansfundednow.com', '', '51.15.112.24', 0, 0), 
(145, 1, 'Consulting', 'Newsletters of Your messages via contact forms to the sites of firms via any countries and domain zones of the world in all languages.', 'Dear Madame, Dear Sirs! <br /> <br />We offer sending newsletters of Your messages via contact forms to the sites ofbusiness organizations via any domain zones of the world.  <br /> <br />http://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />Your letter is sent to email address of organization 100 percent will get to inbox! <br /> <br />Test: <br />ten thousand messages on foreign zones to your email address - 20 dollars. <br />We need from You only email address, title and text of the letter. <br /> <br />In our price list there are more 800 databases for all countries of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of sites - 1100$ <br />All European Union 28 countries 56752547 of sites- 1000$ <br />All Asia 48 countries 14662004 of domain names - 300$ <br />All Africa 50 countries 1594390 of sites - 200$ <br />All North and Central America in 35 countries 7441637 of sites - 300$ <br />All South America 14 countries 5826884 of domain names - 200$ <br />Companies of the Russian Federation - 300$ <br />Ukraine 605745 of domains - 100$ <br />All', 1573070362, 0, 'contactoyswhe', 'amyas_kreiman15@rambler.ru', '123456789', '94.29.58.159', 0, 0), 
(146, 1, 'Consulting', 'Ultimate Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1573121924, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '54.39.183.151', 0, 0), 
(147, 1, 'Consulting', 'SBA Capital for Your Business', 'Faster and Simpler than the SBA, http://FindBusinessFunding-247.com?url=vietnamshipsupply.com can get your business a loan for $2K-350,000 With low-credit and no collateral. <br /> <br />Use our fast form to See exactly how much you can get, No-Cost: <br /> <br />http://FindBusinessFunding-247.com?url=vietnamshipsupply.com <br /> <br />If you&#039;ve been in business for at least 12 months you are already pre-qualified. Our Quick service means funding can be completed within 48 hours. Terms are specific for each business so I suggest applying to find out exactly how much you can get. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. Funds are also Non-Restrictive, allowing you to use the whole amount in any way including bills, taxes, hiring, marketing, expansion, or Absolutely Any Other expense. <br /> <br />There are limited SBA and private funds available so please apply now if interested, <br /> <br />Click Here: http://FindBusinessFunding-247.com?url=vi', 1573152447, 0, 'FindBusinessFunding247', 'noreply@findbusinessfunding-247.com', '', '198.211.110.224', 0, 0), 
(148, 1, 'Consulting', 'A new method of email distribution.', 'Hi!  vietnamshipsupply.com <br /> <br />Have you ever heard of sending messages via feedback forms? <br /> <br />Think of that your offer will be readread by hundreds of thousands of your potential future userscustomers. <br />Your message will not go to the spam folder because people will send the message to themselves. As an example, we have sent you our suggestion  in the same way. <br /> <br />We have a database of more than 35 million sites to which we can send your letter. Sites are sorted by country. Unfortunately, you can only select a country when sending a offer. <br /> <br />The price of one million messages 49 USD. <br />There is a discount program when you purchase  more than two million message packages. <br /> <br /> <br />Free test mailing of 50,000 messages to any country of your selection. <br /> <br /> <br />This letter is created automatically. Please use the contact details below to contact us. <br /> <br /> <br /> <br />Contact us. <br />Telegram - @FeedbackFormEU <br />Skype  FeedbackForm2019 <br />Email - feedbackform@make-success.com', 1573302457, 0, 'AveryKet', 'raphaeSciepernen@gmail.com', '83932492186', '37.120.156.23', 0, 0), 
(149, 1, 'Consulting', 'Take part in the survey from TELEGRAM and get money from sponsors', 'Take part in the survey from TELEGRAM and get money from sponsors <br />https://online2019.com/', 1574031340, 0, 'SamuelCes', 'busterpoirm@gmail.com', '87473491637', '37.120.217.90', 0, 0), 
(150, 1, 'Consulting', 'Bạn có thể giới thiệu thẻ ghi nợ tiền điện tử trên trang web của bạn?', 'Chào. Đây là Chris từ Revollet Marketing International, người phụ trách tiếp thị cho Revollet. <br /> <br />Revollet là một thẻ ghi nợ có thể được sử dụng bằng cách tính phí tiền điện tử như BTC, ETH và XRP. <br /> <br />Bằng cách sử dụng thẻ ghi nợ, bạn có thể rút tiền của mình bằng máy ATM trên toàn thế giới và thanh toán tại các nhà hàng và cửa hàng. <br /> <br />Tôi đã xem trang web của bạn và muốn bạn giới thiệu Revollet trên trang web của bạn. <br /> <br />Tất nhiên, tôi đã chuẩn bị một phần thưởng liên kết, chỉ dành cho bạn.', 1574253995, 0, 'Frankodody', 'revollet.marketing@gmail.com', '86325857938', '45.117.79.125', 0, 0), 
(151, 1, 'Consulting', 'Re&#x3A; Lead For vietnamshipsupply.com', 'Hello there <br /> <br />Buy all styles of Gucci Belts only 9.99 dollars.  If interested, please visit our site: topbuy.online <br /> <br /> <br />Thank You, <br /> <br />Contact - vietnamshipsupply.com', 1575348453, 0, 'LanceDip', 'admin@vietnamshipsupply.com', '84575856968', '172.83.43.139', 0, 0), 
(152, 1, 'Consulting', 'Behold is  offer  http&#x3A;&#x002F;&#x002F;bit.ly&#x002F;2pUMvsp', 'Hello <br />I invite you to my team, I work with the administrators of the company directly. <br />- GUARANTEED high interest on Deposit rates <br />- instant automatic payments <br />- multi-level affiliate program <br />If you want to be a successful person write: <br />Telegram: @Tom_proinvest <br />Skype: live:.cid.18b402177db5105c             Thomas Anderson <br /> <br />http://bit.ly/35K6MjT', 1575496574, 0, 'ThomasAnderson', 'anthonyjus@gmail.com', '88611315848', '84.17.61.163', 0, 0), 
(153, 1, 'Consulting', 'Can We Publish Your Industry Link?', 'Hi there, My name is James and I would like to know if you would have any interest to have your website vietnamshipsupply.com listed as an industry link on our fast growing blog bigwidewebpro.com ? <br /><br /><br />We would like to add your website as an current industry link in a blog post and promote to readers. This in turn helps your search engine ranks.<br /><br />Our blog is fast growing and will include a wide range of topics and categories.<br /><br />Just let us know by going to submit your industry link directly here www.bigwidewebpro.com <br /><br />Thank you<br />James<br />www.bigwidewebpro.com', 1575736537, 0, 'James', 'jharrison1@bigwidewebpro.com', '071 260 41 70', '88.225.243.43', 0, 0), 
(154, 1, 'Consulting', 'Capital For Your Business', 'Hi, letting you know that http://Business-Funds-365.com?url=vietnamshipsupply.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://Business-Funds-365.com?url=vietnamshipsupply.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these progra', 1575757032, 0, 'BusinessFundsFast', 'noreply@business-funds-365.com', '', '185.234.219.246', 0, 0), 
(155, 1, 'Consulting', 'SBA Capital for Your Business', 'Quicker and Simpler than the SBA, http://BusinessFundsFast.info?url=vietnamshipsupply.com can get your business a loan for $2K-350,000 With low-credit and no collateral. <br /> <br />Use our 1 minute form to Find Out exactly how much you can get, No-Cost: <br /> <br />http://BusinessFundsFast.info?url=vietnamshipsupply.com <br /> <br />If you&#039;ve been in business for at least 12 months you are already pre-qualified. Our Fast service means funding can be finished within 48hrs. Terms are specific for each business so I suggest applying to find out exactly how much you can get. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. Funds are also Non-Restrictive, allowing you to use the whole amount in any way including bills, taxes, hiring, marketing, expansion, or Absolutely Any Other expense. <br /> <br />There are limited SBA and private funds available so please apply now if interested, <br /> <br />Click Here: http://BusinessFundsFast.info?url=vietnamships', 1576286663, 0, 'BusinessFunds365', 'noreply@business-funds-365.com', '', '93.91.173.109', 0, 0), 
(156, 1, 'Consulting', 'You deserve more clients… and it’s THIS easy…', 'Hello,<br /><br />You know it’s true…<br /><br />Your competition just can’t hold a candle to the way you DELIVER real solutions to your customers on your website vietnamshipsupply.com.<br /><br />But it’s a shame when good people who need what you have to offer wind up settling for second best or even worse.<br /><br />Not only do they deserve better, you deserve to be at the top of their list.<br /> <br />TalkWithCustomer can reliably turn your website vietnamshipsupply.com into a serious, lead generating machine.<br /><br />With TalkWithCustomer installed on your site, visitors can either call you immediately or schedule a call for you in the future.<br /> <br />And the difference to your business can be staggering – up to 100X more leads could be yours, just by giving TalkWithCustomer a FREE 14 Day Test Drive.<br /> <br />There’s absolutely NO risk to you, so CLICK HERE http://www.talkwithcustomer.com to sign up for this free test drive now.  <br /><br />Tons more leads? You deserve it.<br /><br />Sincerely,<br />Eric<br />PS:  Odds are, you won’t have long to wait before seeing results:<br />This service makes an immediate difference in getting people on the phone right away before they have a chance to turn around and surf off to a competitor&#039;s website. D Traylor, Traylor Law  <br />Why wait any longer?  <br />CLICK HERE http://www.talkwithcustomer.com to take the FREE 14-Day Test Drive and start converting up to 100X more leads today!<br /><br />If you&#039;d like to unsubscribe click here http://liveserveronline.com/talkwithcustomer.aspx?d=vietnamshipsupply.com', 1576442883, 0, 'Eric', 'eric@talkwithcustomer.com', '416-385-3200', '206.41.186.17', 0, 0), 
(157, 1, 'Consulting', 'Capital to Grow Your Business', 'Hi, letting you know that http://SmallBusinessLoans365.com?url=vietnamshipsupply.com can find your business a SBA or private loan for $2,000 - $350K Without high credit or collateral. <br /> <br />Find Out how much you qualify for by clicking here: <br /> <br />http://SmallBusinessLoans365.com?url=vietnamshipsupply.com <br /> <br />Minimum requirements include your company being established for at least a year and with current gross revenue of at least 120K. Eligibility and funding can be completed in as fast as 48hrs. Terms are personalized for each business so I suggest applying to find out exactly how much you can get on various terms. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. These funds are Non-Restrictive, allowing you to spend the full amount in any way you require including business debt consolidation, hiring, marketing, or Absolutely Any Other expense. <br /> <br />If you need fast and easy business funding take a look at these', 1576681332, 0, 'BusinessesLoansFunded', 'noreply@smallbusinessloans365.com', '', '185.234.219.246', 0, 0), 
(158, 1, 'Consulting', 'Do you accept bitcoin?', 'Hello! <br /> <br />Do you know how to spend working hours with benefit? <br /> <br />You can grow bitcoins by 1.1% per day! <br />It takes 1 minute to start, quicker than a cup of coffee <br /> <br />Try http://satoshi2020.site <br /> <br />Powered by Blockchain.', 1577591236, 0, 'RobertDop', 'jackob.james@yandex.ru', '82666159131', '185.59.221.233', 0, 0), 
(159, 1, 'Consulting', 'Ultimate Lead Generation Software', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1577655325, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(160, 1, 'Consulting', 'Want more customers for your business?', 'Hello!  vietnamshipsupply.com <br /> <br />Did you know that it is possible to send business proposal absolutely legitimate way? <br />We offering a new method of sending request through feedback forms. Such forms are located on many sites. <br />When such commercial offers are sent, no personal data is used, and messages are sent to forms specifically designed to receive messages and appeals. <br />Also, messages sent through communication Forms do not get into spam because such messages are considered important. <br />We offer you to test our service for free. We will send up to 50,000 messages for you. <br />The cost of sending one million messages is 49 USD. <br /> <br />This message is created automatically. Please use the contact details below to contact us. <br /> <br />Contact us. <br />Telegram - @FeedbackFormEU <br />Skype  FeedbackForm2019 <br />Email - feedbackform@make-success.com', 1577932437, 0, 'Kennethhoups', 'raphaePabutle@gmail.com', '83157999899', '195.181.172.77', 0, 0), 
(161, 1, 'Consulting', 'Re&#x3A; Lead For vietnamshipsupply.com', 'Hi there <br /> <br />Buy the best protective phone cases to protect your smartphone only 8.99 dollars.  50% OFF Today.   If interested, please visit our site: giftsales.us <br /> <br />Sincerely, <br /> <br />Contact - vietnamshipsupply.com', 1578545247, 0, 'DavidSpure', 'info@vietnamshipsupply.com', '81782611283', '172.83.43.139', 0, 0), 
(162, 1, 'Consulting', 'keywords based Google targeted website traffic', 'hi there <br />would you want to receive more targeted traffic to vietnamshipsupply.com ? <br />Get keywords based and Google targeted traffic with us today <br /> <br />visit our website for more details <br />https://www.hyperlabs.co/product/organic-traffic/ <br /> <br />thanks and regards <br />Hyper Labs Team', 1579602079, 0, 'Hypertat', 'no-reply@hyperlabs.co', '89896649361', '84.17.51.75', 0, 0), 
(163, 1, 'Consulting', 'SBA Capital for Your Business', 'Quicker and Simpler than the SBA, http://MySmallBusinessFundingNow.com?url=vietnamshipsupply.com can get your business a loan for $2K-350,000 With low-credit and without collateral. <br /> <br />Use our fast form to See exactly how much you can get, No-Cost: <br /> <br />http://MySmallBusinessFundingNow.com?url=vietnamshipsupply.com <br /> <br />If you&#039;ve been in business for at least a year you are already pre-qualified. Our Quick service means funding can be completed within 48hrs. Terms are specific for each business so I suggest applying to find out exactly how much you can get. <br /> <br />This is a free service from a qualified lender and the approval will be based on the annual revenue of your business. Funds have no Restrictions, allowing you to use the whole amount in any way including bills, taxes, hiring, marketing, expansion, or Absolutely Any Other expense. <br /> <br />There are limited SBA and private funds available so please apply now if interested, <br /> <br />Click Here: http://MySmallBusinessFundingNow.com?url=', 1579658700, 0, 'MySmallBusinessFundingNow', 'noreply@mysmallbusinessfundingnow.com', '', '185.234.219.246', 0, 0), 
(164, 1, 'Consulting', 'I introduce you Umo Finance', 'Hello, <br />i&#039;m Alberto Simoni from Italy, a proud father of two kids and an happy husband. <br />I work online full time from my home and i like earning also in a passive way thanks my investments. <br />Do you know Umo Finance, the company and its online platform that offers us the best investment solutions ? <br />I don&#039;t refer to scam offers, but to a real cool company with its main headquarters in Dubai, another office in United Kingdom <br />We can invest starting from only 50 dollars to big amount as well (  starting from only 16 days contracts time ) and invest also in <br />bitcoin and ethereum. <br />Actually i have two different deposits opened with them and i receive profits each day and i can withdraw all the time i need. <br />There is also a nice affiliation plan and for this reason i want to give you the chance to earn big money as well with your personal investment. <br />I created a simple but sharp online guide to let you understanding everything where you find also a video proof about the company and', 1579742510, 0, 'AlbertoFipsy', 'monetizzareoggi2019@gmail.com', '82571136193', '109.248.149.19', 0, 0), 
(165, 1, 'Consulting', 'Trustworthiness', 'We will be most delighted in partnering with you, and we intend to maintain a Silent/Financial Position on our Business with your Company as we look forward to a prospective confidential financial business relationship with you. I&#039;m Wife of former Sudanese president Al-Bashir&#039;s nephew, I sent this message to you from your website. Looking forward to hearing from you shortly on:  mudbashr@gmail.com <br />Warm regards, <br />Mrs. Suhayba Ammar', 1579775282, 0, 'AmmarFab', 'dramatexy@gmail.com', '83472572171', '37.120.133.136', 0, 0), 
(166, 1, 'Consulting', 'Создаю копии сайтов от 500 рублей за лендинг', 'Здесь вы можете заказать копию любого сайта под ключ, недорого и качественно, при этом не тратя свое время на различные программы и фриланс-сервисы. <br /> <br />Клонированию подлежат сайты как на конструкторах, так и на движках: <br />- Tilda (Тильда) <br />- Wix (Викс) <br />- Joomla (Джумла) <br />- Wordpress (Вордпресс) <br />- Bitrix (Битрикс) <br />и т.д. <br />телефон 8-996-725-20-75  звоните пишите  viber watsapp <br />Копируются не только одностраничные сайты на подобии Landing Page, но и многостраничные. Создается полная копия сайта и настраиваются формы для отправки заявок и сообщений. Кроме того, подключается админка (админ панель), позволяющая редактировать код сайта, изменять текст, загружать изображения и документы. <br /> <br />Здесь вы получите весь комплекс услуг по копированию, разработке и продвижению сайта в Яндексе и Google. <br /> <br />Хотите узнать сколько стоит сделать копию сайта? <br />напишите нам <br />8-996-725-20-75  звоните пишите  viber watsapp <br /> <br />Here you can order a copy of any site turnkey, inexpensive and hig', 1580116668, 0, 'Neoosox', 'tetakhiling2015@mail.ru', '82853777936', '109.169.205.169', 0, 0), 
(167, 1, 'Consulting', 'Steal the SEO of your toughest competitors', 'Grab the SEO of your competitors with our Competition SEO Plan. Use what works for them in your favor. <br /> <br />More details here <br />https://www.arteseo.co/product/competition-seo-plan/ <br /> <br />Thank you <br />Mike', 1580486310, 0, 'Mikertat', 'no-replyspons@gmail.com', '85328161282', '84.17.48.99', 0, 0), 
(168, 1, 'Consulting', 'Bạn có thể giới thiệu MasterCard trên trang web của bạn?', 'Xin chào, tôi là Chris, giám đốc tiếp thị cho một thẻ ghi nợ tiền điện tử có tên Hcard. <br /> <br />Lần này tôi đã liên lạc với bạn để giới thiệu Hcard trên trang web của bạn. <br /> <br />Hcard là một phù thủy thẻ ghi nợ thương hiệu MasterCard rất dễ sử dụng. <br /> <br />Sử dụng Hcard yêu cầu ứng dụng Fiatbit và Hcard. <br /> <br />Ứng dụng Fiatbit có chức năng liên kết và bạn có thể nhận được các phần thưởng sau khi nhà phát hành thẻ đi ra từ liên kết giới thiệu của bạn. <br /> <br />&gt;&gt; Phần thưởng phát hành thẻ <br />1 đô', 1582058949, 0, 'DarrellLab', 'hcard.marketing@gmail.com', '87481295573', '84.17.48.201', 0, 0), 
(169, 1, 'Consulting', 'We will send Your offers via follow-up forms to the sites of firms via all countries and domain zones of the world.', 'Dear sir! <br /> <br />We offer sending newsletters of Your commercial offers via contact configurations to the sites ofbusiness organizations via any domain zones of the world.  <br /> <br />http://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />Your letter is sent to E-mail of firm 100% will get to inbox folder! <br /> <br />Test: <br />10000 messages on foreign zones to your E-mail - 20 dollars. <br />We need from You only electronic box, title and text of the letter. <br /> <br />In our price list there are more 800 databases for all domains of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of domain names - 1100$ <br />All European Union 28 countries 56752547 of sites- 1000$ <br />All Asia 48 countries 14662004 of domains - 300$ <br />All Africa 50 countries 1594390 of domains - 200$ <br />All North and Central America in 35 countries 7441637 of domains - 300$ <br />All South America 14 countries 5826884 of domain names - 200$ <br />Companies and Enterprises of RF - 300$ <br />Ukraine 605745 of sites - 100$ <br />All Russian-speaking countries', 1582270371, 0, 'contactyvnnxj', 'flannery_vandell83@rambler.ru', '123456789', '79.139.226.124', 0, 0), 
(170, 1, 'Consulting', 'Cool website&#33;', 'Cool website!<br /><br />My name’s Eric, and I just found your site - vietnamshipsupply.com - while surfing the net. You showed up at the top of the search results, so I checked you out. Looks like what you’re doing is pretty cool.<br /> <br />But if you don’t mind me asking – after someone like me stumbles across vietnamshipsupply.com, what usually happens?<br /><br />Is your site generating leads for your business? <br /> <br />I’m guessing some, but I also bet you’d like more… studies show that 7 out 10 who land on a site wind up leaving without a trace.<br /><br />Not good.<br /><br />Here’s a thought – what if there was an easy way for every visitor to “raise their hand” to get a phone call from you INSTANTLY… the second they hit your site and said, “call me now.”<br /><br />You can –<br />  <br />Talk With Web Visitor is a software widget that’s works on your site, ready to capture any visitor’s Name, Email address and Phone Number.  It lets you know IMMEDIATELY – so that you can talk to that lead while they’re literally looking over your site.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.<br /><br />Time is money when it comes to connecting with leads – the difference between contacting someone within 5 minutes versus 30 minutes later can be huge – like 100 times better!<br /><br />That’s why we built out our new SMS Text With Lead feature… because once you’ve captured the visitor’s phone number, you can automatically start a text message (SMS) conversation.<br />  <br />Think about the possibilities – even if you don’t close a deal then and there, you can follow up with text messages for new offers, content links, even just “how you doing?” notes to build a relationship.<br /><br />Wouldn’t that be cool?<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to discover what Talk With Web Visitor can do for your business.<br /><br />You could be converting up to 100X more leads today!<br />Eric<br /><br />PS: Talk With Web Visitor offers a FREE 14 days trial – and it even includes International Long Distance Calling. <br />You have customers waiting to talk with you right now… don’t keep them waiting. <br />CLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1582529717, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '209.58.157.2', 0, 0), 
(171, 1, 'Consulting', 'Hi', 'Hi,<br />Sorry if we bother you with emails. We want you to experience our premium quality posture corrector. Buying quality posture corrector that will last and ultimately deliver what you want may sometimes be challenging. <br />Visit our online store at Shoulderposture.com at any time and any day for quality and lasting posture corrector. With our Posture Corrector, you can be sure of never be disappointed due to its quality, design, and affordability. <br />With us, you worry-free as we got the passion for offering our customers nothing but the best solution to poor posture.<br />Order Premium Quality Posture Corrector Here: Shoulderposture.com <br />The price is competitive. <br /><br />Thank you, <br />Shoulderposture.com Team', 1582539841, 0, 'Clarissa', 'haskell.clarissa@yahoo.com', '04.09.47.48.67', '191.101.117.136', 0, 0), 
(172, 1, 'Consulting', 'A quick trip to a tomorrow of your dreams…', 'Hi,<br /><br />Let’s take a quick trip to Tomorrow-land.<br /><br />I’m not talking about a theme park, I’m talking about your business’s future…<br /><br />Don’t worry, we won’t even need a crystal ball.  <br /><br />Just imagine… <br /><br />… a future where the money you invest in driving traffic to your site vietnamshipsupply.com pays off with tons of calls from qualified leads.<br /> <br />And the difference between what you experienced in the past is staggering – you’re seeing 10X, 20X, 50X, even up to a 100X more leads coming from your website vietnamshipsupply.com.  Leads that are already engaged with what you have to offer and are ready to learn more and even open their wallets.<br /><br />Seeing all this taking place in your business, you think back: What did I do only a short time ago that made such a huge difference?<br /><br />And then it hits you: You took advantage of a free 14 day Test Drive of TalkWithCustomer.<br /><br />You installed TalkWithCustomer on vietnamshipsupply.com – it was a snap.<br /><br />And practically overnight customers started engaging more regularly and calling your business. Like this: EMA has been looking for ways to reach out to an audience. TalkWithCustomer so far is the most direct call of action. It has produced above average closing ratios and we are thrilled. Thank you for providing a real and effective tool to generate REAL leads.  - Patrick Montes<br /><br />Since you installed TalkWithCustomer it’s been great.<br /><br />It’s fun to dream, but this isn’t just a dream. It could be your very real tomorrow.<br /> <br />All you have to do is CLICK HERE http://www.talkwithcustomer.com to sign up to try TalkWithCustomer today.<br /><br />Not tomorrow. Today.<br /><br />Because there’s no better time than now to make your business work the way you’ve always wanted.<br /> <br />Sincerely,<br />Eric<br />PS: Remember, there’s absolutely NO risk to you – if you’re 100% satisfied after the 14 days pass, there’s no obligation.  And even ONE more lead-turned-into-customer could be worth hundreds, even thousands to you over their lifetime. <br /><br />Don’t let the moment pass you by.  CLICK HERE http://www.talkwithcustomer.com to sign up for this free test drive now.  <br /><br />If you&#039;d like to unsubscribe click here http://liveserveronline.com/talkwithcustomer.aspx?d=vietnamshipsupply.com', 1582664162, 0, 'Eric', 'eric@talkwithcustomer.com', '416-385-3200', '198.46.177.43', 0, 0), 
(173, 1, 'Consulting', 'cheap monthly SEO plans', 'hi there <br />I have just checked vietnamshipsupply.com for the ranking keywords and seen that your SEO metrics could use a boost. <br /> <br />We will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. <br /> <br />Please check our pricelist here, we offer SEO at cheap rates. <br />https://www.hilkom-digital.de/cheap-seo-packages/ <br /> <br />Start increasing your sales and leads with us, today! <br /> <br />regards <br />Hilkom Digital Team <br />support@hilkom-digital.de', 1582897281, 0, 'DavidGok', 'no-reply@hilkom-digital.de', '87215724551', '37.120.143.173', 0, 0), 
(174, 1, 'Consulting', 'Sending newsletters via  forms of Your commercial offers into the &quot;Contact us&quot; section to the sites of companies via all domain zones of the world.', 'Dear sir! <br /> <br />We are sending via follow-up forms to the sites of business organizations via any countries and domain zones of the world in any languages.  <br /> <br />http://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />Your message is sent to email of business organization hundred % will get to inside of the inbox folder! <br /> <br />Test: <br />10000 messages on foreign zones to your E-mail - 20 $. <br />We need from You only email address, title and text of the letter. <br /> <br />In our price there are more 800 databases for all domains of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of domains - 1100$ <br />All European Union 28 countries 56752547 of domains- 1000$ <br />All Asia 48 countries 14662004 of domain names - 300$ <br />All Africa 50 countries 1594390 of domain names - 200$ <br />All North and Central America in 35 countries 7441637 of sites - 300$ <br />All South America 14 countries 5826884 of sites - 200$ <br />Companies and Enterprises of Russia - 300$ <br />Ukraine 605745 of domains - 100$ <br />All Russian-speak', 1584303533, 0, 'contactskhcag', 'tula_knaus72@rambler.ru', '123456789', '91.79.50.51', 0, 0), 
(175, 1, 'Consulting', 'Do you sell generic pills or brand medicines?', 'Generic are the identical clones of branded medications. The only difference in the two being the patent and the price at which it is sold. It contains the same active ingredients and match the branded drug in terms of both pharmacokinetic and <a href=\"http://onlinepharmacystore24.com/buy-chloroquine\">chloroquine</a>  pharmacodynamic properties. Be it dosage, strength, route of administration, safety, efficiancy, or use, genetics match their counterparts in all aspects. <br /><a href=\"http://buychloroquineonline.com/\">chloroquine</a> <br /><a href=\"http://buychloroquineonline.com/\">buy chloroquine</a>', 1585040482, 0, 'gruppi', 'gmaroshkina@mail.ru', '87649242724', '95.152.46.241', 0, 0), 
(176, 1, 'Consulting', 'cheap monthly SEO plans', 'hi there <br />I have just checked vietnamshipsupply.com for the ranking keywords and seen that your SEO metrics could use a boost. <br /> <br />We will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. <br /> <br />Please check our pricelist here, we offer SEO at cheap rates. <br />https://www.hilkom-digital.de/cheap-seo-packages/ <br /> <br />Start increasing your sales and leads with us, today! <br /> <br />regards <br />Hilkom Digital Team <br />support@hilkom-digital.de', 1585200420, 0, 'MartinCup', 'no-reply@hilkom-digital.de', '81351532435', '84.17.48.16', 0, 0), 
(177, 1, 'Consulting', 'Pandemic politics – hardest hit the youngest&#33;', 'COVID-19 outbreak: airplanes grounded, borders closed, businesses shut, citizens quarantined, political power seized, democracy undermined. <br />All this, if it is not stopped shortly, can lead to chaos and unrests. <br />Currently http://ST-lF.NET focus on raising awareness of the social impact that radically politicized approach to handling CoronaVirus Pandemic will have on the younger generations. <br />Your support is needed to reduce the destructive impact the lock-down brings to bear on the younger generation. <br />Every 1$ makes a difference. <br />Please, take a moment to watch our presentation video and review our campaigns http://ST-lF.NET', 1586677575, 0, 'Jamestriva', 'coronavaccine@hotmail.com', '82661213787', '84.17.48.185', 0, 0), 
(178, 1, 'Consulting', 'Strike when the iron’s hot', 'Hey there, I just found your site, quick question…<br /><br />My name’s Eric, I found vietnamshipsupply.com after doing a quick search – you showed up near the top of the rankings, so whatever you’re doing for SEO, looks like it’s working well.<br /><br />So here’s my question – what happens AFTER someone lands on your site?  Anything?<br /><br />Research tells us at least 70% of the people who find your site, after a quick once-over, they disappear… forever.<br /><br />That means that all the work and effort you put into getting them to show up, goes down the tubes.<br /><br />Why would you want all that good work – and the great site you’ve built – go to waste?<br /><br />Because the odds are they’ll just skip over calling or even grabbing their phone, leaving you high and dry.<br /><br />But here’s a thought… what if you could make it super-simple for someone to raise their hand, say, “okay, let’s talk” without requiring them to even pull their cell phone from their pocket?<br />  <br />You can – thanks to revolutionary new software that can literally make that first call happen NOW.<br /><br />Talk With Web Visitor is a software widget that sits on your site, ready and waiting to capture any visitor’s Name, Email address and Phone Number.  It lets you know IMMEDIATELY – so that you can talk to that lead while they’re still there at your site.<br />  <br />You know, strike when the iron’s hot!<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.<br /><br />When targeting leads, you HAVE to act fast – the difference between contacting someone within 5 minutes versus 30 minutes later is huge – like 100 times better!<br /><br />That’s why you should check out our new SMS Text With Lead feature as well… once you’ve captured the phone number of the website visitor, you can automatically kick off a text message (SMS) conversation with them. <br /> <br />Imagine how powerful this could be – even if they don’t take you up on your offer immediately, you can stay in touch with them using text messages to make new offers, provide links to great content, and build your credibility.<br /><br />Just this alone could be a game changer to make your website even more effective.<br /><br />Strike when  the iron’s hot!<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to learn more about everything Talk With Web Visitor can do for your business – you’ll be amazed.<br /><br />Thanks and keep up the great work!<br /><br />Eric<br />PS: Talk With Web Visitor offers a FREE 14 days trial – you could be converting up to 100x more leads immediately!   <br />It even includes International Long Distance Calling. <br />Stop wasting money chasing eyeballs that don’t turn into paying customers. <br />CLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1587161881, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '206.41.178.36', 0, 0), 
(179, 1, 'Consulting', 'We offer sending newsletters of Your offers via contact forms to the sites of firms via all domain zones of the world in all languages.', 'Dear sir! <br /> <br />We offer sending newsletters of Your messages via contact forms  to the sites of companies via any countries of the world in all languages.  <br /> <br />https://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />Your message is sent to E-mail address <br /> of business organization 100% will get to incoming! <br /> <br />Test: <br />10000 messages on foreign zones to your electronic box - twenty $. <br />We need from You only E-mail, title and text of the letter. <br /> <br />In our price list there are more 800 databases for all domains of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of sites - 1100$ <br />All European Union 28 countries 56752547 of domains- 1000$ <br />All Asia 48 countries 14662004 of domains - 300$ <br />All Africa 50 countries 1594390 of domain names - 200$ <br />All North and Central America in 35 countries 7441637 of sites - 300$ <br />All South America 14 countries 5826884 of domain names - 200$ <br />Companies of RF - 300$ <br />Ukraine 605745 of domain names - 100$ <br />All Russian-speaking countries m', 1587202993, 0, 'contactfprcpx', 'malisa_chang59@rambler.ru', '9876543210', '91.79.44.238', 0, 0), 
(180, 1, 'Consulting', 'Who needs eyeballs, you need BUSINESS', 'My name’s Eric and I just came across your website - vietnamshipsupply.com - in the search results.<br /><br />Here’s what that means to me…<br /><br />Your SEO’s working.<br /><br />You’re getting eyeballs – mine at least.<br /><br />Your content’s pretty good, wouldn’t change a thing.<br /><br />BUT…<br /><br />Eyeballs don’t pay the bills.<br /><br />CUSTOMERS do.<br /><br />And studies show that 7 out of 10 visitors to a site like vietnamshipsupply.com will drop by, take a gander, and then head for the hills without doing anything else.<br /><br />It’s like they never were even there.<br /><br />You can fix this.<br /><br />You can make it super-simple for them to raise their hand, say, “okay, let’s talk” without requiring them to even pull their cell phone from their pocket… thanks to Talk With Web Visitor.<br /><br />Talk With Web Visitor is a software widget that sits on your site, ready and waiting to capture any visitor’s Name, Email address and Phone Number.  It lets you know immediately – so you can talk to that lead immediately… without delay… BEFORE they head for those hills.<br />  <br />CLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.<br /><br />Now it’s also true that when reaching out to hot leads, you MUST act fast – the difference between contacting someone within 5 minutes versus 30 minutes later is huge – like 100 times better!<br /><br />That’s what makes our new SMS Text With Lead feature so powerful… you’ve got their phone number, so now you can start a text message (SMS) conversation with them… so even if they don’t take you up on your offer right away, you continue to text them new offers, new content, and new reasons to do business with you.<br /><br />This could change everything for you and your business.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to learn more about everything Talk With Web Visitor can do and start turing eyeballs into money.<br /><br />Eric<br />PS: Talk With Web Visitor offers a FREE 14 days trial – you could be converting up to 100x more leads immediately!   <br />It even includes International Long Distance Calling. <br />Paying customers are out there waiting. <br />Starting connecting today by CLICKING HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1587419173, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '192.3.144.60', 0, 0), 
(181, 1, 'Consulting', 'Human body thermal camera high accuracy', 'Dear Sir/mdm, <br /> <br />How are you? <br /> <br />We supply medical products: <br /> <br />Medical masks <br />3M, 3ply, KN95, KN99, N95 masks <br />Protective masks <br />Eye mask <br />Protective cap <br />Disinfectant <br />Hand sanitiser <br />Medical alcohol <br />Eye protection <br />Disposable latex gloves <br />Protective suit <br />IR non-contact thermometers <br /> <br />and Thermal cameras for Body Temperature Measurement up to accuracy of ±0.1?C <br />Advantages of thermal imaging detection: <br /> <br />1. Intuitive, efficient and convenient, making users directly &quot;see&quot; the temperature variation. <br />2. Thermal condition of different locations for comprehensive analysis, providing more information for judgment <br />3. Avoiding judgment errors, reducing labor costs, and discovering poor heat dissipation and hidden trouble points <br />4. PC software for data analysis and report output <br /> <br />Whatsapp: +65 87695655 <br />Telegram: cctv_hub <br />Skype: cctvhub <br />Email: sales@thecctvhub.com <br />W: http://www.thecctvhub.com/ <br /> <br />If you do not wish to receive email from us again,', 1587581202, 0, 'Raymond 	Brown', 'info@thecctvhub.com', '88588372957', '84.17.51.35', 0, 0), 
(182, 1, 'Consulting', 'Get More Business Leads', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1587754958, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(183, 1, 'Consulting', 'продвижение раскрутка сайтов', 'Bestellen Sie SEO-Suchmaschinenoptimierung der Website, Bestellen Sie Website-Promotion-Services Bei allen Fragen wenden Sie sich an den Benutzernamen Skype pokras7777 <br />Wir sammeln auch Basen', 1587958180, 0, 'maniiyao', 'gorlm17@mail.ru', '81413696876', '93.124.40.43', 0, 0), 
(184, 1, 'Consulting', 'Sending newsletters via  contact forms to the sites ofbusiness organizations via any countries of the world.', 'Dear Madame, Dear Sirs! <br /> <br />We are sending via contact forms  to the sites of firms via any domain zones of the world.  <br /> <br />https://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />Your offer is sent to E-mail of business organization 100 percent will get to inbox! <br /> <br />Test: <br />10000 messages on foreign zones to your email address - 20 $. <br />We need from You only email address, title and text of the letter. <br /> <br />In our price list there are more 800 databases for all domain zones of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of domains - 1100$ <br />All European Union 28 countries 56752547 of domain names- 1000$ <br />All Asia 48 countries 14662004 of sites - 300$ <br />All Africa 50 countries 1594390 of sites - 200$ <br />All North and Central America in 35 countries 7441637 of domains - 300$ <br />All South America 14 countries 5826884 of domains - 200$ <br />Companies of Russia - 300$ <br />Ukraine 605745 of sites - 100$ <br />All Russian-speaking countries minus Russian Federation are 14 countries and', 1588567613, 0, 'contactmfdeuz', 'malisa_chang59@rambler.ru', '9876543210', '94.29.60.203', 0, 0), 
(185, 1, 'Consulting', 'Your site – more leads?', 'Hey, this is Eric and I ran across vietnamshipsupply.com a few minutes ago.<br /><br />Looks great… but now what?<br /><br />By that I mean, when someone like me finds your website – either through Search or just bouncing around – what happens next?  Do you get a lot of leads from your site, or at least enough to make you happy?<br /><br />Honestly, most business websites fall a bit short when it comes to generating paying customers. Studies show that 70% of a site’s visitors disappear and are gone forever after just a moment.<br /><br />Here’s an idea…<br /> <br />How about making it really EASY for every visitor who shows up to get a personal phone call you as soon as they hit your site…<br /> <br />You can –<br />  <br />Talk With Web Visitor is a software widget that’s works on your site, ready to capture any visitor’s Name, Email address and Phone Number.  It signals you the moment they let you know they’re interested – so that you can talk to that lead while they’re literally looking over your site.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.<br /><br />You’ll be amazed - the difference between contacting someone within 5 minutes versus a half-hour or more later could increase your results 100-fold.<br /><br />It gets even better… once you’ve captured their phone number, with our new SMS Text With Lead feature, you can automatically start a text (SMS) conversation.<br />  <br />That way, even if you don’t close a deal right away, you can follow up with text messages for new offers, content links, even just “how you doing?” notes to build a relationship.<br /><br />Pretty sweet – AND effective.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to discover what Talk With Web Visitor can do for your business.<br /><br />You could be converting up to 100X more leads today!<br /><br />Eric<br />PS: Talk With Web Visitor offers a FREE 14 days trial – and it even includes International Long Distance Calling. <br />You have customers waiting to talk with you right now… don’t keep them waiting. <br />CLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1589919688, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '154.16.69.6', 0, 0), 
(186, 1, 'Consulting', 'Lead Generation to Grow Your Business', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1590121756, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(187, 1, 'Consulting', 'Lead Generation for Your Business', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1590521280, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(188, 1, 'Consulting', 'Want more customers for your business?', 'Hеllо!  vietnamshipsupply.com <br /> <br />Did yоu knоw thаt it is pоssiblе tо sеnd businеss оffеr whоlly lаwfully? <br />Wе prоviding а nеw mеthоd оf sеnding соmmеrсiаl оffеr thrоugh fееdbасk fоrms. Suсh fоrms аrе lосаtеd оn mаny sitеs. <br />Whеn suсh businеss prоpоsаls аrе sеnt, nо pеrsоnаl dаtа is usеd, аnd mеssаgеs аrе sеnt tо fоrms spесifiсаlly dеsignеd tо rесеivе mеssаgеs аnd аppеаls. <br />аlsо, mеssаgеs sеnt thrоugh fееdbасk Fоrms dо nоt gеt intо spаm bесаusе suсh mеssаgеs аrе соnsidеrеd impоrtаnt. <br />Wе оffеr yоu tо tеst оur sеrviсе fоr frее. Wе will sеnd up tо 50,000 mеssаgеs fоr yоu. <br />Thе соst оf sеnding оnе milliоn mеssаgеs is 49 USD. <br /> <br />This lеttеr is сrеаtеd аutоmаtiсаlly. Plеаsе usе thе соntасt dеtаils bеlоw tо соntасt us. <br /> <br />Contact us. <br />Telegram - @FeedbackFormEU <br />Skype  FeedbackForm2019 <br />WhatsApp - +375259112693 <br />Email feedbackform@make-success.com', 1590691467, 0, 'JoshuaTom', 'no-replyPabutle@gmail.com', '86443568364', '37.120.159.24', 0, 0), 
(189, 1, 'Consulting', 'Human body thermal camera high accuracy and medical supplies', 'Dear Sir/mdm, <br /> <br />How are you? <br /> <br />We supply medical products: <br /> <br />Medical masks <br />3M 1860, 9502, 9501 <br />3ply medical, KN95 FFP2, FFP3, N95 masks <br />Face shield <br />Disposable nitrile/latex gloves <br />Isolation/surgical gown <br />Protective PPE/Overalls <br />IR non-contact thermometers <br />Crystal tomato <br /> <br />Human body thermal cameras <br />for Body Temperature Measurement up to accuracy of ±0.1?C <br /> <br />Whatsapp: +65 87695655 <br />Telegram: cctv_hub <br />Skype: cctvhub <br />Email: sales@thecctvhub.com <br />W: http://www.thecctvhub.com/ <br /> <br />If you do not wish to receive email from us again, please let us know by replying. <br /> <br />regards, <br />CCTV HUB', 1590753838, 0, 'Melvinlemap', 'atrixxtrix@gmail.com', '83446793388', '84.17.47.99', 0, 0), 
(190, 1, 'Consulting', 'Get More Leads to Grow Your Business', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1591487146, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(191, 1, 'Consulting', 'Get More Leads Now', 'Hi, would you like more business leads at a lower cost? Currently http://Get-More-Leads-Now.com is offering our popular unlimited lead generation software package - at a reduced price for a limited time. <br /> <br />Download and install now to be building databases of leads in minutes: <br /> <br />http://Get-More-Leads-Now.com <br /> <br />The Ultimate Lead Generation Pack works by automatically visting yellow page directories and building a database according to your search terms. Other software in the pack then finds emails, phone numbers, and other details for that database. The results can be used for email, cold-calling, direct mail, or to sell immediately - priced per lead. Runs on Windows, Mac, and Linux with multiple job and VPN/proxy support. Similar software retails for over $100 with less features. <br /> <br />This pack is only available on sale as a short promotional offer, please download now if at all interested. <br /> <br />Click Here: http://Get-More-Leads-Now.com <br /> <br />Have a Great Day, <br />The Ultimate Lea', 1591754722, 0, 'Ultimate', 'noreply@get-more-leads-now.com', '', '185.234.219.246', 0, 0), 
(192, 1, 'Consulting', 'cheap monthly SEO plans', 'Hi! <br />I have just checked vietnamshipsupply.com for the ranking keywords and seen that your SEO metrics could use a boost. <br /> <br />We will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. <br /> <br />Please check our pricelist here, we offer SEO at cheap rates. <br />https://www.hilkom-digital.de/cheap-seo-packages/ <br /> <br />Start increasing your sales and leads with us, today! <br /> <br />regards <br />Hilkom Digital Team <br />support@hilkom-digital.de', 1591881952, 0, 'Mike Jones', 'no-reply@hilkom-digital.de', '87396436656', '84.17.49.199', 0, 0), 
(193, 1, 'Consulting', 'You are my heart', 'You are my heart: http://clickfrm.com/yG5A', 1592106323, 0, 'Rebeccasew', 'yourmyheart@gmail.com', '88956571315', '31.132.211.144', 0, 0), 
(194, 1, 'Consulting', 'Try this, get more leads', 'Hi, my name is Eric and I’m betting you’d like your website vietnamshipsupply.com to generate more leads.<br /><br />Here’s how:<br />Talk With Web Visitor is a software widget that’s works on your site, ready to capture any visitor’s Name, Email address and Phone Number.  It signals you as soon as they say they’re interested – so that you can talk to that lead while they’re still there at vietnamshipsupply.com.<br /><br />Talk With Web Visitor – CLICK HERE http://www.talkwithwebvisitor.com for a live demo now.<br /><br />And now that you’ve got their phone number, our new SMS Text With Lead feature enables you to start a text (SMS) conversation – answer questions, provide more info, and close a deal that way.<br /><br />If they don’t take you up on your offer then, just follow up with text messages for new offers, content links, even just “how you doing?” notes to build a relationship.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to discover what Talk With Web Visitor can do for your business.<br /><br />The difference between contacting someone within 5 minutes versus a half-hour means you could be converting up to 100X more leads today!<br /><br />Try Talk With Web Visitor and get more leads now.<br /><br />Eric<br />PS: The studies show 7 out of 10 visitors don’t hang around – you can’t afford to lose them!<br />Talk With Web Visitor offers a FREE 14 days trial – and it even includes International Long Distance Calling. <br />You have customers waiting to talk with you right now… don’t keep them waiting. <br />CLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1592244302, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '96.8.119.104', 0, 0), 
(195, 1, 'Consulting', 'Business Inquiry', 'Good Day, <br /> <br />I am Mike Koike (Sales Manager) at Kent Firm National Integration <br />We are interested in purchasing from your company. We are an agency for sole buyers and importers. <br />Our client is in need of your product please get back to me with your business terms. So I can place my demand. <br /> <br />Your early reply is highly appreciated. Contact us through E-mail:   m.koike@kfni-j.com <br /> <br />Best regards <br /> <br />Mike Koike <br />12th floor, Inui Building 112-7 <br />Changgyeonggung-ro Jongno-gu, Seoul, <br />South Korea 110-780 <br />E-mail: m.koike@kfni-j.com', 1592480282, 0, 'Mike Koike', 'tinalim.idlabels@hotmail.com', '85432972535', '84.17.49.188', 0, 0), 
(196, 1, 'Consulting', 'FUNDING', 'My name is John Brooks of AAA Structured Finance Ltd , Thank you for your time, my company offers project financing and lending services, do you have any project that requires funding at the moment? We are ready to work with you on a more transparent approach. <br /> <br />Best regards, <br />John Brooks <br />Principal Partner <br />AAA Structured Finance Ltd <br />E-mail: brooksjohn801@gmail.com', 1592925010, 0, 'John Brooks', 'swetmangdudley@gmail.com', '81593294416', '195.181.172.68', 0, 0), 
(197, 1, 'Consulting', 'quality monthly SEO plans', 'hi there <br />I have just checked vietnamshipsupply.com for the ranking keywords and seen that your SEO metrics could use a boost. <br /> <br />We will improve your SEO metrics and ranks organically and safely, using only whitehat methods, while providing monthly reports and outstanding support. <br /> <br />Please check our pricelist here, we offer result driven SEO services. <br />https://digitalsy.org.uk/seo-pricing/ <br /> <br />Start increasing your sales and leads with us, today! <br /> <br />regards <br />DIGITALSY Team <br />support@digitalsy.org.uk', 1593229917, 0, 'Mike Williams', 'marketing@digitalsy.org.uk', '84818279842', '185.206.224.253', 0, 0), 
(198, 1, 'Consulting', 'Внимание  скидки Устранение сайтов конкурента только сегодня', 'Рады приветствовать вас! <br />Готовы предоставить лучшие прогоны, чтобы &quot;убить&quot; веб-сайт вашего конкурента. Стоимость: от 2000 руб. <br />- Стопроцентный эффект. Сайты ваших конкурентов &quot;упадут&quot;. <br />- Максимальное количество отрицательных фитбеков. <br />- Наша особая база - максимально сильные площадки из 10 млн. веб-ресурсов (спамные, порно, вирусы и т.д.). Это действует безотказно. <br />- Прогон выполняется сразу с четырех серверов. <br />- Постоянный спам токсичных ссылок на email. <br />- Выполнение на протяжении 40-240 часов сутки напролет. Растянем сколько угодно по времени. <br />- Прогон с запрещёнными ключами. <br />- При условии заказа нескольких сайтов - выгодные бонусы. <br /> <br />Стоимость  4000py. <br />Полная отчётность. <br />Оплата: Qiwi, Yandex.Money, Bitcoin, Visa, MasterCard... <br />Телегрм: @exrumer <br />Whatssap: +7(906)5312155 <br />Skype: XRumer.pro <br />маил: support@xrumer.cc', 1594047833, 0, 'TatyanaVlasova', 'myahmarks1989@bumikind.bizml.ru', '89169319983', '92.38.136.69', 0, 0), 
(199, 1, 'Consulting', 'IMPORT EXPORT PRODUCTS &amp; SERVICES', 'Dear Sir/Ma, <br />We humbly introduce our company N.Y & TANTIMONIQUE INTERNATIONAL, we are an export company. We have been in business touching all countries of the world productively for 17 years. <br /> <br />We export Agricultural products; <br />Cocoa Beans, Cocoa Powder, HardWood Charcoal, Bitter Kolanut (Garcinia Kola), Ginger, Palm Oil <br />All types of Hardwoods (processed & Unprocessed Woods), Groundnut & Cashew Nuts <br />Hibiscus Flower, Shea Butter, Cassava Etc <br /> <br />Sea Products; <br />Tillapia Fillet, Mackarel, Titus, Tillapia, Cat fish, crabs, finger Fish, snails, shrimps, crayfish etc <br /> <br />Inverters; <br />1KW – 500 KW Inverters <br /> <br />Sperm Booster Roots; <br />This roots increase greatly the Male Sperm Motility and Morphology. It helps fertility and easy conception. <br /> <br />We look forward to hearing and working with you for a profitable business relationship. <br />Please accept the assurances of our highest corporate regards. <br /> <br />Warm regards, <br />Adenaya Ewunuga <br />MD <br />N.Y & TANTIMONIQUE INTERNATONAL <br />http:/', 1594069297, 0, 'Adenaya Ewunuga', 'sphereemerald@gmail.com', '85283371864', '84.17.60.187', 0, 0), 
(200, 1, 'Consulting', 'Fever screening thermal camera and masks', 'Dear Sir/mdm, <br /> <br />How are you? <br /> <br />We supply Professional surveillance & medical products: <br /> <br />Moldex, makrite and 3M N95 1860, 9502, 9501, 8210 <br />3ply medical, KN95, FFP2, FFP3, PPDS masks <br />Face shield/medical goggles <br />Nitrile/vinyl/PP gloves <br />Isolation/surgical gown lvl1-4 <br />Protective PPE/Overalls lvl1-4 <br />IR non-contact thermometers/oral thermometers <br />sanitizer dispenser <br />Crystal tomato <br /> <br />Logitech/OEM webcam <br />Marine underwater CCTV <br />Explosionproof CCTV <br />4G Solar CCTV <br />Human body thermal cameras <br />for Body Temperature Measurement up to accuracy of ±0.1?C <br /> <br />Whatsapp: +65 87695655 <br />Telegram: cctv_hub <br />Skype: cctvhub <br />Email: sales@thecctvhub.com <br />W: http://www.thecctvhub.com/ <br /> <br />If you do not wish to receive email from us again, please let us know by replying. <br /> <br />regards, <br />CCTV HUB', 1594224903, 0, 'Heatheradvex', 'atrixxtrix@gmail.com', '82332189794', '84.17.60.172', 0, 0), 
(201, 1, 'Consulting', 'New income possibility&#33;', 'Hello <br /> <br />Im looking for investor for my email marketing business. <br />I own 270 million email database with 92% valid emails. Im looking for investor who invest in server infrastructure to send it. Im planning to run infrastructure to send like 10 million emails per day on daily basis, and increase every week by add more servers. <br />Potential earnings are $100-$200 depend on country per million sended messages <br />I have knowledge about email marketing and team which is needed to handle whitelisting. <br /> <br />Investment: $2000 on first run, after you see results you can invest more. <br />You control all investment, all servers, software will be with your access. <br /> <br />If you are interested about partnership please send email on: <br />mailermasters@gmail.com', 1594311223, 0, 'Lauraanids', 'investorsneeded1213@gmail.com', '82668572477', '85.203.44.98', 0, 0), 
(202, 1, 'Consulting', 'how to turn eyeballs into phone calls', 'Hi, Eric here with a quick thought about your website vietnamshipsupply.com...<br /><br />I’m on the internet a lot and I look at a lot of business websites.<br /><br />Like yours, many of them have great content. <br /><br />But all too often, they come up short when it comes to engaging and connecting with anyone who visits.<br /><br />I get it – it’s hard.  Studies show 7 out of 10 people who land on a site, abandon it in moments without leaving even a trace.  You got the eyeball, but nothing else.<br /><br />Here’s a solution for you…<br /><br />Talk With Web Visitor is a software widget that’s works on your site, ready to capture any visitor’s Name, Email address and Phone Number.  You’ll know immediately they’re interested and you can call them directly to talk with them literally while they’re still on the web looking at your site.<br /><br />CLICK HERE http://www.talkwithwebvisitor.com to try out a Live Demo with Talk With Web Visitor now to see exactly how it works.<br /><br />It could be huge for your business – and because you’ve got that phone number, with our new SMS Text With Lead feature, you can automatically start a text (SMS) conversation – immediately… and contacting someone in that 5 minute window is 100 times more powerful than reaching out 30 minutes or more later.<br /><br />Plus, with text messaging you can follow up later with new offers, content links, even just follow up notes to keep the conversation going.<br /><br />Everything I’ve just described is extremely simple to implement, cost-effective, and profitable. <br /> <br />CLICK HERE http://www.talkwithwebvisitor.com to discover what Talk With Web Visitor can do for your business.<br /><br />You could be converting up to 100X more eyeballs into leads today!<br /><br />Eric<br />PS: Talk With Web Visitor offers a FREE 14 days trial – and it even includes International Long Distance Calling. <br />You have customers waiting to talk with you right now… don’t keep them waiting. <br />CLICK HERE http://www.talkwithwebvisitor.com to try Talk With Web Visitor now.<br /><br />If you&#039;d like to unsubscribe click here http://talkwithwebvisitor.com/unsubscribe.aspx?d=vietnamshipsupply.com', 1594563891, 0, 'Eric', 'eric@talkwithwebvisitor.com', '416-385-3200', '138.128.14.239', 0, 0), 
(203, 1, 'Consulting', 'Regarding vietnamshipsupply.com', 'Good day<br /><br />Body Revolution - Medico Postura™ Body Posture Corrector<br />Improve Your Posture INSTANTLY!<br />Get it while it&#039;s still 50% OFF!<br />FREE Worldwide Shipping!<br /><br />Get yours here: medicopostura.online<br /><br />Best regards,<br /><br />Contact - vietnamshipsupply.com', 1594655296, 0, 'Bennett', 'info@vietnamshipsupply.com', '860-826-3254', '199.187.211.107', 0, 0), 
(204, 1, 'Consulting', 'Concerning vietnamshipsupply.com', 'Hi there<br /><br />Defrost frozen foods in minutes safely and naturally with our THAW KING™. <br /><br />50% OFF for the next 24 Hours ONLY + FREE Worldwide Shipping for a LIMITED time<br /><br />Buy now: thawking.online<br /><br />To your success,<br /><br />Contact - vietnamshipsupply.com', 1594916100, 0, 'Elma', 'info@vietnamshipsupply.com', '487 1451', '172.98.82.165', 0, 0), 
(205, 1, 'Consulting', '“great deals”', 'Dear CEO vietnamshipsupply.com , <br />I have an urgent need for a partner to venture in a fully funded investment with you. I would want to negotiate the possibility of a working business agreement with you. Your business plan will be needed for review and your capability to be an Investment Manager is sacrosanct.  I’m constrained from giving you further information now until I hear from you. .  Kindly reply to:  subhammar052@gmail.com <br /> <br />Regards, <br />Mrs. Suhayba Ammar', 1595032745, 0, 'Suhayba Ammar', 'sadiqalbashir12@gmail.com', '84794528922', '78.159.113.196', 0, 0), 
(206, 1, 'Consulting', 'Do You Have A Website vietnamshipsupply.com?', 'Hi,<br /><br />Do you have a Website? Of course you do because I am looking at your website vietnamshipsupply.com now.<br /><br />Are you struggling for Leads and Sales?<br /><br />You’re not the only one.<br /><br />So many Website owners struggle to convert their Visitors into Leads & Sales.<br /><br />There’s a simple way to fix this problem.<br /><br />You could use a Live Chat app on your Website vietnamshipsupply.com and hire Chat Agents.<br /><br />But only if you’ve got deep pockets and you’re happy to fork out THOUSANDS of dollars for the quality you need.<br /><br />=====<br /><br />But what if you could automate Live Chat so it’s HUMAN-FREE?<br /><br />What if you could exploit NEW “AI” Technology to engage with your Visitors INSTANTLY.<br /><br />And AUTOMATICALLY convert them into Leads & Sales.<br /><br />WITHOUT spending THOUSANDS of dollars on Live Chat Agents.<br /><br />And WITHOUT hiring expensive coders.<br /><br />In fact, all you need to do to activate this LATEST “AI” Website Tech..<br /><br />..is to COPY & PASTE a single line of “Website Code”.<br /><br />==&gt; http://www.zoomsoft.net/ConversioBot<br /><br />======<br /><br />Join HUGE Fortune 500 companies like:<br /><br />Facebook Spotify Starbucks Staples The Wall Street Journal Pizza Hut Amtrak Disney H&M & Mastercard<br /><br />They all use similar “AI” Chat Technology to ConversioBot - the Internet’s #1 Chatbot for Website Owners.<br /><br />The founders of ConversioBot have used their highly sophisticated ChatBot to:<br /><br />- AUTOMATICALLY build a massive Email List of 11,643 Subscribers in just 7 Days<br /><br />- AUTOMATICALLY add 6,386 Sales in only 6 Months<br /><br />- AUTOMATICALLY explode their Conversion Rate by 198% in only 6 Hours.<br /><br />=====<br /><br />Now it’s your turn to get in on this exciting NEW Cloud-Based App.<br /><br />You can start using ConversioBot today by copying and pasting ONE line of “Automated Bot Code&quot; to your Website.<br /><br />Watch this short video to find out how &gt;&gt; http://www.zoomsoft.net/ConversioBot<br /><br />Regards,<br /><br />ConversioBot Team<br /><br />P.S. This “AI” Technology works with: - Affiliate Review Sites - List-Building Pages - WordPress Blogs (it comes with a Plugin) - Sales Letters - eCommerce Websites - Local Business Sites - Webinar Registration Pages - Consultancy Websites - Freelance Websites<br /><br />Almost ANY Website you can think of..<br /><br />==&gt; This could be happening on your Website TODAY.. http://www.zoomsoft.net/ConversioBot<br /><br />UNSUBSCRIBE http://www.zoomsoft.net/unsubscribe', 1595274704, 0, 'Lukas', 'armenta.lukas12@gmail.com', '485 7723', '23.94.17.237', 0, 0), 
(207, 1, 'Consulting', 'Re&#x3A; vietnamshipsupply.com', 'Hey there<br /><br />CAREDOGBEST™ - Personalized Dog Harness. All sizes from XS to XXL.  Easy ON/OFF in just 2 seconds.  LIFETIME WARRANTY.<br /><br />Click here: caredogbest.online<br /><br />Best,<br /><br />Contact', 1595435518, 0, 'Nannie', 'info@vietnamshipsupply.com', '806-263-7061', '212.102.40.168', 0, 0), 
(208, 1, 'Consulting', 'New&#x3A; DA50 for vietnamshipsupply.com', 'Gооd dаy! <br />If you want to get ahead of your competition, have a higher Domain Authority score. Its just simple as that. <br />With our service you get Domain Authority above 50 points in just 30 days. <br /> <br />This service is guaranteed <br /> <br />For more information, check our service here <br />https://www.monkeydigital.co/Get-Guaranteed-Domain-Authority-50/ <br /> <br />thank you <br />Mike Abramson<br /> <br />Monkey Digital <br />support@monkeydigital.co', 1596195816, 0, 'Mike Abramson', 'no-replyzex@google.com', '82898374421', '95.168.185.239', 0, 0), 
(209, 1, 'Consulting', 'We offer a service of sending newsletters via contact configurationss to the sites of firms via all domain zones of the world.', 'I&#039;m happy to welcome you! <br /> <br />We send Your offers via contact forms to the sites of firms via all countries and domain zones of the world.  <br /> <br />https://xn----7sbb1bbndheurc1a.xn--p1ai <br /> <br />The commercial offer is sent to E-mail of business organization 100% will get to inbox! <br /> <br />Test: <br />10000 messages on foreign zones to your E-mail - 20 dollars. <br />We need from You only email address, title and text of the letter. <br /> <br />In our price there are more 800 databases for all countries of the world. <br />Common databases: <br />All Europe 44 countries 60726150 of sites - 1100$ <br />All European Union 28 countries 56752547 of domain names- 1000$ <br />All Asia 48 countries 14662004 of domain names - 300$ <br />All Africa 50 countries 1594390 of domains - 200$ <br />All North and Central America in 35 countries 7441637 of domain names - 300$ <br />All South America 14 countries 5826884 of domains - 200$ <br />Enterprises and organizations of Russia 4025015 - 300$ <br />Ukraine 605745 of sites - 100$ <br />All Russian-speaking co', 1596439120, 0, 'contactsdrwyy', 'jerome_sesso37@rambler.ru', '84636526932', '91.79.28.18', 0, 0), 
(210, 1, 'Consulting', 'Admin', 'Hey there<br /><br />Work out to a whole new level with our P-Knee™ power leg knee joint support! <br /><br />Order here: p-knee.online<br /><br />60% OFF + FREE Worldwide Shipping - TODAY ONLY!<br /><br />Kind Regards,<br /><br />Ship Supply', 1596465816, 0, 'Sherri', 'info@vietnamshipsupply.com', '209-728-3960', '199.187.211.102', 0, 0), 
(211, 1, 'Consulting', 'Best Offer', 'Hey<br /><br />Providing Premium Shades at an affordable price.  50% OFF today with free worldwide shipping.<br /><br />Get Yours Today: trendshades.online<br /><br />Kind Regards,<br /><br />Ship Supply', 1596625329, 0, 'Mel', 'info@vietnamshipsupply.com', '03.37.09.58.73', '172.98.82.163', 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_freecontent_blocks`
--

DROP TABLE IF EXISTS `nv4_en_freecontent_blocks`;
CREATE TABLE `nv4_en_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_freecontent_blocks`
--

INSERT INTO `nv4_en_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_freecontent_rows`
--

DROP TABLE IF EXISTS `nv4_en_freecontent_rows`;
CREATE TABLE `nv4_en_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `link` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(10) NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255) NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_freecontent_rows`
--

INSERT INTO `nv4_en_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'nukeviet.jpg', 1439973638, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'nukeviet-portal.jpg', 1439973638, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'nukeviet-edu.jpg', 1439973638, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'nukeviet-toasoan.jpg', 1439973638, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_menu`
--

DROP TABLE IF EXISTS `nv4_en_menu`;
CREATE TABLE `nv4_en_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_menu`
--

INSERT INTO `nv4_en_menu` VALUES
(1, 'Top Menu'), 
(2, 'Menu_Besiness_footer'), 
(3, 'menu_footer');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_menu_rows`
--

DROP TABLE IF EXISTS `nv4_en_menu_rows`;
CREATE TABLE `nv4_en_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `link` text NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `note` varchar(255) DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text,
  `groups_view` varchar(255) DEFAULT '',
  `module_name` varchar(255) DEFAULT '',
  `op` varchar(255) DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255) DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=23  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_menu_rows`
--

INSERT INTO `nv4_en_menu_rows` VALUES
(1, 0, 1, 'About', '/index.php?language=en&nv=about', '', '', 1, 1, 0, '', '6', 'about', '', 1, '', 1, 1), 
(2, 0, 1, 'News', '/index.php?language=en&nv=news', '', '', 3, 7, 0, '', '6', 'news', '', 1, '', 1, 0), 
(16, 14, 1, 'General repairs', '/index.php?language=en&nv=supplies&op=general-repairs', '', '', 3, 5, 1, '', '6', 'supplies', '', 1, '', 0, 1), 
(15, 14, 1, 'Supplies', '/index.php?language=en&nv=supplies&op=supplies', '', '', 2, 4, 1, '', '6', 'supplies', '', 1, '', 0, 1), 
(14, 0, 1, 'Supplies', '/index.php?language=en&nv=supplies', '', '', 2, 2, 0, '16,15,17,19', '6', 'supplies', '', 1, '', 0, 1), 
(7, 0, 1, 'Contact', '/index.php?language=en&nv=contact', '', '', 4, 8, 0, '', '6', 'contact', '', 1, '', 1, 1), 
(8, 0, 2, 'Ship supply', '/Blue_Ocean/index.php?language=en&nv=our-business&amp;op=ship-supply', '', '', 1, 1, 0, '', '6', 'our-business', 'ship-supply', 1, '', 1, 1), 
(9, 0, 2, 'Ship repair', '/Blue_Ocean/index.php?language=en&nv=our-business&amp;op=ship-repair', '', '', 2, 2, 0, '', '6', 'our-business', 'ship-repair', 1, '', 1, 1), 
(10, 0, 2, 'Ship service', '/Blue_Ocean/index.php?language=en&nv=our-business&amp;op=ship-service', '', '', 3, 3, 0, '', '6', 'our-business', 'ship-service', 1, '', 1, 1), 
(17, 14, 1, 'Other services', '/index.php?language=en&nv=supplies&op=other-services', '', '', 4, 6, 1, '', '6', 'supplies', '', 1, '', 0, 1), 
(20, 0, 3, 'Supplies', '/index.php?language=en&nv=supplies&op=supplies-1', '', '', 1, 1, 0, '', '6', 'supplies', '', 1, '', 0, 1), 
(19, 14, 1, 'Port We Serv', '/index.php?language=en&nv=port-we-serv', '', '', 1, 3, 1, '', '6', '', '', 1, '', 0, 1), 
(21, 0, 3, 'General repairs', '/index.php?language=en&nv=supplies&op=general-repairs', '', '', 2, 2, 0, '', '6', 'supplies', '', 1, '', 0, 1), 
(22, 0, 3, 'Other services', '/index.php?language=en&nv=supplies&op=other-services', '', '', 3, 3, 0, '', '6', 'supplies', '', 1, '', 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modfuncs`
--

DROP TABLE IF EXISTS `nv4_en_modfuncs`;
CREATE TABLE `nv4_en_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55) NOT NULL,
  `alias` varchar(55) NOT NULL DEFAULT '',
  `func_custom_name` varchar(255) NOT NULL,
  `in_module` varchar(55) NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=118  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_modfuncs`
--

INSERT INTO `nv4_en_modfuncs` VALUES
(83, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(82, 'rss', 'rss', 'Rss', 'about', 1, 0, 2, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 7, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 8, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 9, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 6, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 4, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Login', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Register', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Lostpass', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Active', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Edit User Info', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Memberlist', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Logout', 'users', 1, 1, 10, ''), 
(28, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(29, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(30, 'allreferers', 'allreferers', 'All Referers', 'statistics', 1, 1, 2, ''), 
(31, 'allcountries', 'allcountries', 'Countries', 'statistics', 1, 1, 3, ''), 
(32, 'allbrowsers', 'allbrowsers', 'Browsers', 'statistics', 1, 1, 4, ''), 
(33, 'allos', 'allos', 'OS', 'statistics', 1, 1, 5, ''), 
(34, 'allbots', 'allbots', 'Bots', 'statistics', 1, 1, 6, ''), 
(35, 'referer', 'referer', 'refererg', 'statistics', 1, 0, 7, ''), 
(36, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(37, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(38, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(39, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(40, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(41, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(42, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(43, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(44, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(45, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(46, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(47, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(48, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(49, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(50, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(51, 'rss', 'rss', 'Rss', 'page', 1, 0, 2, ''), 
(52, 'main', 'main', 'Main', 'siteterms', 1, 0, 1, ''), 
(53, 'rss', 'rss', 'Rss', 'siteterms', 1, 0, 2, ''), 
(54, 'sitemap', 'sitemap', 'Sitemap', 'siteterms', 0, 0, 0, ''), 
(55, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(56, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(110, 'topic', 'topic', 'Topic', 'supplies', 1, 0, 3, ''), 
(109, 'tag', 'tag', 'Tag', 'supplies', 1, 0, 8, ''), 
(108, 'sitemap', 'sitemap', 'Sitemap', 'supplies', 0, 0, 0, ''), 
(107, 'sendmail', 'sendmail', 'Sendmail', 'supplies', 0, 0, 0, ''), 
(106, 'search', 'search', 'Search', 'supplies', 1, 1, 6, ''), 
(105, 'savefile', 'savefile', 'Savefile', 'supplies', 0, 0, 0, ''), 
(104, 'rss', 'rss', 'Rss', 'supplies', 1, 1, 9, ''), 
(103, 'rating', 'rating', 'Rating', 'supplies', 0, 0, 0, ''), 
(102, 'print', 'print', 'Print', 'supplies', 0, 0, 0, ''), 
(101, 'main', 'main', 'Main', 'supplies', 1, 0, 1, ''), 
(73, 'main', 'main', 'Main', 'home', 1, 0, 1, ''), 
(74, 'main', 'main', 'Main', 'slider', 1, 0, 1, ''), 
(75, 'rss', 'rss', 'Rss', 'slider', 1, 0, 2, ''), 
(76, 'sitemap', 'sitemap', 'Sitemap', 'slider', 0, 0, 0, ''), 
(77, 'main', 'main', 'Main', 'support', 1, 0, 1, ''), 
(81, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(100, 'groups', 'groups', 'Groups', 'supplies', 1, 0, 4, ''), 
(99, 'detail', 'detail', 'Detail', 'supplies', 1, 0, 5, ''), 
(98, 'content', 'content', 'Content', 'supplies', 1, 1, 7, ''), 
(111, 'viewcat', 'viewcat', 'Viewcat', 'supplies', 1, 0, 2, ''), 
(117, 'sitemap', 'sitemap', 'Sitemap', 'port-we-serv', 0, 0, 0, ''), 
(116, 'rss', 'rss', 'Rss', 'port-we-serv', 1, 0, 2, ''), 
(115, 'main', 'main', 'Main', 'port-we-serv', 1, 0, 1, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modthemes`
--

DROP TABLE IF EXISTS `nv4_en_modthemes`;
CREATE TABLE `nv4_en_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100) DEFAULT NULL,
  `theme` varchar(100) DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_modthemes`
--

INSERT INTO `nv4_en_modthemes` VALUES
(0, 'body', 'mobile_default'), 
(0, 'left-body-right', 'default'), 
(4, 'body', 'mobile_default'), 
(4, 'body1', 'default'), 
(5, 'body', 'mobile_default'), 
(5, 'body1', 'default'), 
(6, 'body', 'mobile_default'), 
(6, 'body1', 'default'), 
(7, 'body', 'mobile_default'), 
(7, 'body1', 'default'), 
(8, 'body', 'mobile_default'), 
(8, 'body1', 'default'), 
(9, 'body', 'mobile_default'), 
(9, 'body1', 'default'), 
(10, 'body1', 'default'), 
(11, 'body', 'mobile_default'), 
(11, 'body1', 'default'), 
(12, 'body', 'mobile_default'), 
(12, 'body1', 'default'), 
(18, 'body', 'mobile_default'), 
(18, 'body1', 'default'), 
(19, 'body', 'mobile_default'), 
(19, 'body1', 'default'), 
(20, 'body', 'mobile_default'), 
(20, 'body1', 'default'), 
(21, 'body', 'mobile_default'), 
(21, 'body1', 'default'), 
(22, 'body', 'mobile_default'), 
(22, 'body1', 'default'), 
(23, 'body', 'mobile_default'), 
(23, 'body1', 'default'), 
(24, 'body', 'mobile_default'), 
(24, 'body1', 'default'), 
(25, 'body', 'mobile_default'), 
(25, 'body1', 'default'), 
(26, 'body1', 'default'), 
(27, 'body', 'mobile_default'), 
(27, 'body1', 'default'), 
(29, 'body', 'mobile_default'), 
(29, 'body1', 'default'), 
(30, 'body', 'mobile_default'), 
(30, 'body1', 'default'), 
(31, 'body', 'mobile_default'), 
(31, 'body1', 'default'), 
(32, 'body', 'mobile_default'), 
(32, 'body1', 'default'), 
(33, 'body', 'mobile_default'), 
(33, 'body1', 'default'), 
(34, 'body', 'mobile_default'), 
(34, 'body1', 'default'), 
(35, 'body', 'mobile_default'), 
(35, 'body1', 'default'), 
(36, 'body', 'mobile_default'), 
(36, 'body1', 'default'), 
(37, 'body', 'mobile_default'), 
(37, 'body1', 'default'), 
(38, 'body', 'mobile_default'), 
(38, 'body1', 'default'), 
(39, 'body', 'mobile_default'), 
(39, 'body1', 'default'), 
(45, 'body', 'mobile_default'), 
(45, 'body1', 'default'), 
(46, 'body', 'mobile_default'), 
(46, 'body1', 'default'), 
(47, 'body', 'mobile_default'), 
(47, 'body1', 'default'), 
(48, 'body', 'mobile_default'), 
(48, 'body1', 'default'), 
(49, 'body', 'mobile_default'), 
(49, 'body1', 'default'), 
(51, 'body1', 'default'), 
(52, 'body', 'mobile_default'), 
(52, 'body1', 'default'), 
(53, 'body', 'mobile_default'), 
(53, 'body1', 'default'), 
(55, 'body', 'mobile_default'), 
(55, 'left-body-contact', 'default'), 
(56, 'body', 'mobile_default'), 
(56, 'body1', 'default'), 
(57, 'body', 'mobile_default'), 
(57, 'body1', 'default'), 
(58, 'body', 'mobile_default'), 
(58, 'body1', 'default'), 
(73, 'body', 'default'), 
(73, 'body', 'mobile_default'), 
(74, 'body', 'mobile_default'), 
(74, 'body1', 'default'), 
(75, 'body', 'mobile_default'), 
(75, 'body1', 'default'), 
(76, 'left-body-right', 'default'), 
(77, 'body', 'mobile_default'), 
(77, 'body1', 'default'), 
(81, 'body', 'mobile_default'), 
(81, 'body1', 'default'), 
(82, 'body', 'mobile_default'), 
(82, 'body1', 'default'), 
(83, 'left-body-right', 'default'), 
(98, 'body', 'mobile_default'), 
(98, 'left-body', 'default'), 
(99, 'body', 'mobile_default'), 
(99, 'left-body', 'default'), 
(100, 'body', 'mobile_default'), 
(100, 'left-body', 'default'), 
(101, 'body', 'mobile_default'), 
(101, 'left-body', 'default'), 
(102, 'left-body-right', 'default'), 
(103, 'left-body-right', 'default'), 
(104, 'body', 'mobile_default'), 
(104, 'left-body', 'default'), 
(105, 'left-body-right', 'default'), 
(106, 'body', 'mobile_default'), 
(106, 'left-body', 'default'), 
(107, 'left-body-right', 'default'), 
(108, 'left-body-right', 'default'), 
(109, 'body', 'mobile_default'), 
(109, 'left-body', 'default'), 
(110, 'body', 'mobile_default'), 
(110, 'left-body', 'default'), 
(111, 'body', 'mobile_default'), 
(111, 'left-body', 'default'), 
(115, 'body', 'mobile_default'), 
(115, 'body1', 'default'), 
(116, 'body', 'mobile_default'), 
(116, 'body1', 'default'), 
(117, 'left-body-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_modules`
--

DROP TABLE IF EXISTS `nv4_en_modules`;
CREATE TABLE `nv4_en_modules` (
  `title` varchar(55) NOT NULL,
  `module_file` varchar(55) NOT NULL DEFAULT '',
  `module_data` varchar(55) NOT NULL DEFAULT '',
  `module_upload` varchar(55) NOT NULL DEFAULT '',
  `custom_title` varchar(255) NOT NULL,
  `admin_title` varchar(255) DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100) DEFAULT '',
  `mobile` varchar(100) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `keywords` text,
  `groups_view` varchar(255) NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255) DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_modules`
--

INSERT INTO `nv4_en_modules` VALUES
('news', 'news', 'news', 'news', 'News', '', 1439973638, 1, 1, '', '', '', '', '6', 5, 1, '', 1, 0), 
('users', 'users', 'users', 'users', 'users', 'Users', 1439973638, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Contact', '', 1439973638, 1, 1, '', '', '', '', '6', 6, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Statistics', '', 1439973638, 1, 1, '', '', '', 'online, statistics', '2', 8, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Voting', '', 1439973638, 1, 1, '', '', '', '', '6', 9, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Banners', '', 1439973638, 1, 1, '', '', '', '', '6', 10, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Search', '', 1439973638, 1, 0, '', '', '', '', '6', 11, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1439973638, 0, 1, '', '', '', '', '6', 12, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'Rss Feeds', '', 1439973638, 1, 1, '', '', '', '', '6', 13, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1439973638, 1, 1, '', '', '', '', '6', 14, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Comment', '', 1439973638, 0, 1, '', '', '', '', '6', 15, 1, '', 0, 0), 
('siteterms', 'page', 'siteterms', 'siteterms', 'Terms & Conditions', '', 1439973638, 1, 1, '', '', '', '', '6', 16, 1, '', 1, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Freecontent', '', 1439973638, 0, 1, '', '', '', '', '6', 17, 1, '', 0, 0), 
('supplies', 'news', 'supplies', 'supplies', 'Supplies', 'Supplies', 1441323656, 1, 1, '', '', 'Supplies', 'Supplies', '6', 3, 1, '', 1, 0), 
('home', 'home', 'home', 'home', 'Home', 'Home', 1439977336, 1, 0, '', '', 'Home', 'Home', '6', 1, 1, '', 0, 0), 
('slider', 'slider', 'slider', 'slider', 'Banner', 'Banner', 1439987546, 1, 1, '', '', 'Banner', 'Banner', '6', 18, 1, '', 1, 0), 
('support', 'support', 'support', 'support', 'Support', 'Support', 1440001506, 1, 1, '', '', 'Support', 'Support', '6', 19, 1, '', 0, 0), 
('about', 'page', 'about', 'about', 'About', 'About', 1441004509, 1, 1, '', '', 'About', 'About', '6', 2, 1, '', 1, 0), 
('port-we-serv', 'page', 'port_we_serv', 'port-we-serv', 'Port We Serv', 'Port We Serv', 1442638842, 1, 1, '', '', 'Port We Serv', 'Port We Serv', '6', 4, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_4`
--

DROP TABLE IF EXISTS `nv4_en_news_4`;
CREATE TABLE `nv4_en_news_4` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_4`
--

INSERT INTO `nv4_en_news_4` VALUES
(3, 4, '4', 0, 2, '', 0, 1441209833, 1441335197, 1, 1441209780, 0, 2, 'VIKING Moves to Expand Australasian Activities', 'viking-moves-to-expand-australasian-activities', '', '2015_09/viking-pic-300x199.jpg', 'VIKING PIC 300x199', 1, '', 1, '4', 1, 1695, 0, 0, 0), 
(4, 4, '4', 0, 2, '', 0, 1441209938, 1441335153, 1, 1441209840, 0, 2, 'Viking acquires hook retrofit leader', 'viking-acquires-hook-retrofit-leader', '', '2015_09/viking-300x200.jpg', 'VIKING 300x200', 1, '', 1, '4', 1, 2162, 0, 0, 0), 
(5, 4, '4', 0, 2, '', 0, 1441210036, 1441335186, 1, 1441209900, 0, 2, 'Nautilus comments on research that says people who work longer hours are at risk of stroke', 'nautilus-comments-on-research-that-says-people-who-work-longer-hours-are-at-risk-of-stroke', '', '2015_09/paper-ships-300x199.jpg', '', 1, '', 1, '4', 1, 1894, 0, 0, 0), 
(6, 4, '4', 0, 1, '', 0, 1441335327, 1441335327, 1, 1441335180, 0, 2, 'Hungary migrant stand-off continues', 'hungary-migrant-stand-off-continues', 'On Thursday, police let the migrants board the train in Budapest but then tried to force them off at a refugee camp to the west of the capital.', '2015_09/viking-pic-300x199.jpg', 'VIKING PIC 300x199', 1, '', 1, '4', 1, 1687, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_5`
--

DROP TABLE IF EXISTS `nv4_en_news_5`;
CREATE TABLE `nv4_en_news_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_admins`
--

DROP TABLE IF EXISTS `nv4_en_news_admins`;
CREATE TABLE `nv4_en_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_block`
--

DROP TABLE IF EXISTS `nv4_en_news_block`;
CREATE TABLE `nv4_en_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_block`
--

INSERT INTO `nv4_en_news_block` VALUES
(1, 4, 4), 
(1, 5, 3), 
(1, 3, 2), 
(1, 6, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_block_cat`
--

DROP TABLE IF EXISTS `nv4_en_news_block_cat`;
CREATE TABLE `nv4_en_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_block_cat`
--

INSERT INTO `nv4_en_news_block_cat` VALUES
(1, 0, 4, 'New', 'new', '', 'New', 1, 'New', 1441335074, 1441335074);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_en_news_bodyhtml_1`;
CREATE TABLE `nv4_en_news_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_bodyhtml_1`
--

INSERT INTO `nv4_en_news_bodyhtml_1` VALUES
(3, '<p>VIKING Life-Saving Equipment has acquired a part of Australia-based Wiltrading’s maritime safety equipment activities, the firm has announced.</p><p>The move strengthens VIKING’s offering in Australasia, adding&nbsp;four locations to the company’s global network of wholly-owned servicing stations, as well as several products and services, bringing new advantages for shipowners and offshore operators in the region.</p><p>A subsidiary of Wilh. Wilhelmsen Investments (WWI), Wiltrading offers integrated activities in marine safety, fire fighting and protection, equipment and servicing, serving the offshore, oil and gas, shipping, military and cruise industries.</p><p>The company is an authorised representative and service partner for a wide variety of maritime and offshore equipment producers. Under the new agreement, selected safety equipment and servicing activities previously managed by Wiltrading will be seamlessly integrated into the global VIKING organisation, offered and serviced locally, whereas remaining activities will be carried out in close cooperation between the two.</p><p>VIKING’s CEO Henrik Uhd Christensen welcomed the new addition to his company, saying: “We’ve worked in close partnership with Wiltrading for several years. They are a professional organisation with a strong, service-minded approach to customers –&nbsp;something that makes these activities and the people who operate them an excellent fit for VIKING. We strive to be close to our customers, so we can support their competitiveness with fixed prices, flexibility and fast delivery no matter where they operate.”</p><p>At the same time General Manager of Wiltrading, Michael Connolly is pleased that VIKING and Wiltrading can continue their respective growth activities.</p><p>He said: &nbsp;“With the VIKING Shipowner Agreement rapidly winning favour in the market, and plans for even more capabilities in the future, VIKING has much to offer Wiltrading’s customers and staff. We have always had a great deal of respect for the company, and are really looking forward to leveraging VIKING’s global network resources.”</p><p>Brian Jacobsen has been appointed Country Manager for VIKING Australia. He is a former VIKING sales and marketing director, and started the company’s Singapore office several years ago. He has recently returned to VIKING.</p>', '', 2, 0, 1, 1, 1, 0), 
(4, '<p>Marine and fire safety provider VIKING Life Saving Equipment has&nbsp;joined forces with&nbsp;Nadiro, manufacturers of high-quality lifeboat and rescue systems.</p><p>VIKING this week&nbsp;announced the&nbsp;“strategic move”&nbsp;in the&nbsp;acquisition of Nadiro, a company owned by maritime and energy conglomerate Maersk Group and SH Group.</p><p>Nadiro, &nbsp;based&nbsp;in&nbsp;Svendborg, Denmark,&nbsp;manufactures lifeboat and rescue craft systems, developing and promoting its Drop-in-Ball technology to help ensure crew safety.</p><p>VIKING has had the status of preferred distributor and service provider, supplying the company’s lifeboat release and retrieval systems to enable the world’s shipowners to comply with new SOLAS regulations by or before 2019. Hook retrofitting is necessary to prevent serious accidents resulting from unsafe lifeboat deployment systems.</p><p>Nadiro enables VIKING to provide high-quality, extremely reliable solutions that ensure safety levels beyond basic compliance.</p><p>VIKING CEO Henrik Uhd Christensen explained the acquisition of Nadiro as a strategic move that enables his company to better address this key safety issue for its customers, and as part of the continued expansion of VIKING’s already extensive product portfolio.</p><p>He said:&nbsp;“For more than a decade, on-load release hooks were&nbsp;installed to enable lifeboats to be lowered into and retrieved from the water have themselves been the cause of numerous accidents.</p><p>“Some have involved fatalities. With our stated mission to protect and save human lives all over the world, and our global leadership within maritime safety equipment, doing everything we can to rectify the problem has been a natural focal point for VIKING over the past few years.”</p><p>Henrik Uhd Christensen sees Nadiro, which will be integrated into the VIKING organization, as a perfect fit for the company: “Nadiro has performed well, and its products have been instrumental in ensuring the safety of crew on board many vessels. Now the time has come to add further power to Nadiro’s expansion via a focused, global safety platform. And VIKING is the right company to provide that platform.”</p><p>With VIKING’s global network and resources supporting its work, VIKING Nadiro, as the brand will be renamed, enables &nbsp;VIKING to provide a solution that goes beyond basic compliance.</p><p>Mr Christensen added: “The VIKING Nadiro brand will give shipowners a complete and high-quality answer to the LRRS compliance challenge.”</p>', '', 2, 0, 1, 1, 1, 0), 
(5, '<p>Seafarers working a 91/98-hour working week is “unacceptable” – according to&nbsp;the union for maritime professionals&nbsp;Nautilus&nbsp;who made the comments following&nbsp;research published that said people who work longer hours are more likely to have a stroke.</p><p>International senior national secretary Allan Graveson from Nautilus said that stroke, heart disease, diabetes and cancer have all&nbsp;been identified as long-term risks for people who work longer&nbsp;hours with not enough rest.</p><p>He said: “In addition to “acute” and “chronic” fatigue that pose an immediate risk to the individual, the traveling public and the environment, this research rightly identifies one of the long term effects of working long hours. In addition to stroke, heart disease, diabetes and cancer have been identified as long term increased risks to health as a consequence of working long hours especially, at night with inadequate rest.</p><p>‘In shipping, where there is the potential for the greatest loss of life in a single incident, regulations provide for working a 91/98 hour working week. Independent research Project Horizon&nbsp;has confirmed that human performance seriously degrades when working long hours, especially at night. This causes tiredness and places all marine users at risk.</p><p>‘The long term risk to health is considerable and was recognised with the European Working Time Directive in 1993. Unlike asbestos, ignored for decades, employers now need to take responsibility. A 91/98 hour working week is unacceptable.’</p>', '', 2, 0, 1, 1, 1, 0), 
(6, '<p>On Thursday, police let the migrants board the train in Budapest but then tried to force them off at a refugee camp to the west of the capital.</p><p>Hungarian MPs face a key vote later on whether to tighten border controls as migrants try to pass through to their preferred destination, Germany.</p><p>Three other European meetings on Friday will discuss the migrant crisis.</p><p>Members of the European Commission are also flying to the Greek island of Kos to examine the difficulties caused by the large numbers of refugees and migrants landing there.</p><p>The UN has meanwhile urged the EU to admit up to 200,000 refugees as part of &quot;a mass relocation programme&quot; that had the &quot;mandatory participation&quot; of all member states.</p><p>A statement from Antonio Guterres, the UN High Commissioner of Refugees, said Europe needed to build &quot;adequate reception capacities&quot;, especially in Greece, replacing a &quot;piecemeal&quot; approach with a &quot;common strategy&quot;.</p><h2>&#039;Ashamed&#039;</h2><p>The Hungarian MPs will also vote on creating new holding camps for migrants, and on whether the situation constitutes a state of emergency.</p><p>Prime Minister Viktor Orban on Thursday described the situation as a &quot;German problem&quot; as Germany was where those arriving in the EU &quot;would like to go&quot;.</p><figure><a href=\"http://www.bbc.com/news/world-europe-34148891\" id=\"media-85345413jumpMediaPlayerLink\">Jump media player</a><br  /><a href=\"http://www.bbc.co.uk/faqs/online/mp_accessibility_help\" id=\"media-85345413beforeFlashLink\">Media player help</a><br  /><object data=\"http://emp.bbci.co.uk/emp/SMPf/1.13.11/StandardMediaPlayerChromelessFlash.swf\" height=\"100%\" id=\"smp-flashSWFmedia-85345413\" type=\"application/x-shockwave-flash\" width=\"100%\"></object><br  /><a href=\"http://www.bbc.com/news/world-europe-34148891#afterFlash\" id=\"media-85345413returnToMediaPlayerLink\">Out of media player. Press enter to return or tab to continue.</a><figcaption>Media captionHungary&#039;s prime minister says the migrant crisis is &quot;a not a European problem, it is a German problem&quot;</figcaption></figure><p>However, Luxembourg&#039;s Foreign Minister Jean Asselborn - who is heading the EU meetings on the crisis - criticised Hungary&#039;s conservative leader on German television on Thursday night, saying: &quot;One sometimes has to be ashamed for Viktor Orban.&quot;</p><p>European Council President Donald Tusk said at least 100,000 refugees should be distributed across EU states - a sharp increase on a previous European Commission target of 40,000.</p><p>German Chancellor Angela Merkel and French President Francois Hollande said they would present plans for the redistribution of refugees within the EU.</p><p>The British government, in particular, is coming under growing pressure to take in more migrants.</p><p>British Prime Minister David Cameron is expected to announce&nbsp;<a href=\"http://www.bbc.co.uk/news/uk-34148913\">plans to allow more Syrian refugees into the country</a>, to help ease a crisis brought to the fore this week by&nbsp;<a href=\"http://www.bbc.co.uk/news/world-europe-34143445\">images of a three-year-old Syrian boy found drowned in Turkey</a>.</p><p>Mr Cameron is heading to Spain and Portugal for talks on Friday that are sure to include the migrant crisis.</p><p>The crisis is also due to be discussed at a series of high-level talks across Europe on Friday:</p><ul>	<li>The leaders of Poland, the Czech Republic, Slovakia and Hungary will hold an extraordinary summit in Prague</li>	<li>European Commission officials will arrive on the island of Kos, in Greece, where thousands of migrants have arrived by boat</li>	<li>EU foreign ministers will meet in Brussels</li></ul><hr  /><h2>Migrant crisis: coverage in detail</h2><figure><img alt=\"Migrants are seen at a makeshift camp in an underground station in front of the Keleti railway station in Budapest, Hungary, September 3, 2015.\" datasrc=\"http://ichef.bbci.co.uk/news/1180/cpsprodpb/CEF9/production/_85358925_af91ca72-e6f7-4e6a-bd7c-765410fce2cf.jpg\" height=\"549\" src=\"http://ichef.bbci.co.uk/news/624/cpsprodpb/CEF9/production/_85358925_af91ca72-e6f7-4e6a-bd7c-765410fce2cf.jpg\" width=\"1180\" />Image copyrightReuters</figure><p><a href=\"http://www.bbc.co.uk/news/magazine-34137358\">Ten powerful photos</a></p><p><a href=\"http://www.bbc.co.uk/news/blogs-eu-34144554\">Hungary lays bare EU East-West split</a></p><p><a href=\"http://www.bbc.co.uk/news/blogs-trending-34142804\">Will one image change our views?</a></p><p><a href=\"http://www.bbc.co.uk/news/world-europe-34131911\">Migrant crisis in graphics</a></p><p><a href=\"http://www.bbc.co.uk/news/world-europe-34130639\">Volunteers step up</a></p><hr  /><h2>Analysis: Jenny Hill, BBC News, Berlin</h2><figure><img alt=\"A girl from Syria, who has just arrived by train, waits to travel onto a reception centre, at the central railway station in Munich, Germany, 03 September 2015.\" datasrc=\"http://ichef-1.bbci.co.uk/news/976/cpsprodpb/1742B/production/_85357259_85357258.jpg\" height=\"549\" src=\"http://ichef-1.bbci.co.uk/news/624/cpsprodpb/1742B/production/_85357259_85357258.jpg\" width=\"976\" />Image copyrightEPA<figcaption>Image captionMany of those travelling through Hungary - like this girl from Syria - have moved on to Germany</figcaption></figure><p>Last week, the German government indicated it would grant asylum to Syrian refugees regardless of how they&#039;d entered Europe.</p><p>That attitude has enraged the Hungarian leader, Viktor Orban, who blames Germany&#039;s welcoming reputation for the high number of refugees crossing his country.</p><p>Angela Merkel disagrees. Germany, she said, is simply fulfilling its &quot;moral and legal&quot; obligations. This is a situation which, she argues, &quot;affects all of us in Europe&quot;.</p><p>But it&#039;s a situation that creates a huge domestic challenge too. Up to 800,000 people are expected to seek asylum in Germany this year alone.</p><figure><img alt=\"Map\" datasrc=\"http://ichef.bbci.co.uk/news/624/cpsprodpb/6B16/production/_85341472_migrant_journeys_turkey_to_germany_624_v2.png\" height=\"570\" src=\"http://ichef.bbci.co.uk/news/624/cpsprodpb/6B16/production/_85341472_migrant_journeys_turkey_to_germany_624_v2.png\" width=\"624\" /></figure><p><a href=\"http://www.bbc.co.uk/news/world-europe-34148159\">Germany seizes its chance to help</a></p><p><a href=\"http://www.bbc.co.uk/news/world-europe-34139348\">How could EU solve the crisis?</a></p><hr  /><p>International services had been suspended at Budapest&#039;s Keleti railway station but hundreds crammed on to the first train on Thursday, hoping it would take them to the Austrian border.</p><p>Instead, the train stopped at the Hungarian town of Bicske about 40km (25 miles) west of Budapest, which hosts a major refugee camp. Police then lined the platforms.</p>', '', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_bodytext`
--

DROP TABLE IF EXISTS `nv4_en_news_bodytext`;
CREATE TABLE `nv4_en_news_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_bodytext`
--

INSERT INTO `nv4_en_news_bodytext` VALUES
(3, 'VIKING Life-Saving Equipment has acquired a part of Australia-based Wiltrading’s maritime safety equipment activities, the firm has announced.  The move strengthens VIKING’s offering in Australasia, adding four locations to the company’s global network of wholly-owned servicing stations, as well as several products and services, bringing new advantages for shipowners and offshore operators in the region.  A subsidiary of Wilh. Wilhelmsen Investments (WWI), Wiltrading offers integrated activities in marine safety, fire fighting and protection, equipment and servicing, serving the offshore, oil and gas, shipping, military and cruise industries.  The company is an authorised representative and service partner for a wide variety of maritime and offshore equipment producers. Under the new agreement, selected safety equipment and servicing activities previously managed by Wiltrading will be seamlessly integrated into the global VIKING organisation, offered and serviced locally, whereas remaining activities will be carried out in close cooperation between the two.  VIKING’s CEO Henrik Uhd Christensen welcomed the new addition to his company, saying: “We’ve worked in close partnership with Wiltrading for several years. They are a professional organisation with a strong, service-minded approach to customers – something that makes these activities and the people who operate them an excellent fit for VIKING. We strive to be close to our customers, so we can support their competitiveness with fixed prices, flexibility and fast delivery no matter where they operate.”  At the same time General Manager of Wiltrading, Michael Connolly is pleased that VIKING and Wiltrading can continue their respective growth activities.  He said: “With the VIKING Shipowner Agreement rapidly winning favour in the market, and plans for even more capabilities in the future, VIKING has much to offer Wiltrading’s customers and staff. We have always had a great deal of respect for the company, and are really looking forward to leveraging VIKING’s global network resources.”  Brian Jacobsen has been appointed Country Manager for VIKING Australia. He is a former VIKING sales and marketing director, and started the company’s Singapore office several years ago. He has recently returned to VIKING.'), 
(4, 'Marine and fire safety provider VIKING Life Saving Equipment has joined forces with Nadiro, manufacturers of high-quality lifeboat and rescue systems.  VIKING this week announced the “strategic move” in the acquisition of Nadiro, a company owned by maritime and energy conglomerate Maersk Group and SH Group.  Nadiro, based in Svendborg, Denmark, manufactures lifeboat and rescue craft systems, developing and promoting its Drop-in-Ball technology to help ensure crew safety.  VIKING has had the status of preferred distributor and service provider, supplying the company’s lifeboat release and retrieval systems to enable the world’s shipowners to comply with new SOLAS regulations by or before 2019. Hook retrofitting is necessary to prevent serious accidents resulting from unsafe lifeboat deployment systems.  Nadiro enables VIKING to provide high-quality, extremely reliable solutions that ensure safety levels beyond basic compliance.  VIKING CEO Henrik Uhd Christensen explained the acquisition of Nadiro as a strategic move that enables his company to better address this key safety issue for its customers, and as part of the continued expansion of VIKING’s already extensive product portfolio.  He said: “For more than a decade, on-load release hooks were installed to enable lifeboats to be lowered into and retrieved from the water have themselves been the cause of numerous accidents.  “Some have involved fatalities. With our stated mission to protect and save human lives all over the world, and our global leadership within maritime safety equipment, doing everything we can to rectify the problem has been a natural focal point for VIKING over the past few years.”  Henrik Uhd Christensen sees Nadiro, which will be integrated into the VIKING organization, as a perfect fit for the company: “Nadiro has performed well, and its products have been instrumental in ensuring the safety of crew on board many vessels. Now the time has come to add further power to Nadiro’s expansion via a focused, global safety platform. And VIKING is the right company to provide that platform.”  With VIKING’s global network and resources supporting its work, VIKING Nadiro, as the brand will be renamed, enables VIKING to provide a solution that goes beyond basic compliance.  Mr Christensen added: “The VIKING Nadiro brand will give shipowners a complete and high-quality answer to the LRRS compliance challenge.”'), 
(5, 'Seafarers working a 91/98-hour working week is “unacceptable” – according to the union for maritime professionals Nautilus who made the comments following research published that said people who work longer hours are more likely to have a stroke.  International senior national secretary Allan Graveson from Nautilus said that stroke, heart disease, diabetes and cancer have all been identified as long-term risks for people who work longer hours with not enough rest.  He said: “In addition to “acute” and “chronic” fatigue that pose an immediate risk to the individual, the traveling public and the environment, this research rightly identifies one of the long term effects of working long hours. In addition to stroke, heart disease, diabetes and cancer have been identified as long term increased risks to health as a consequence of working long hours especially, at night with inadequate rest.  ‘In shipping, where there is the potential for the greatest loss of life in a single incident, regulations provide for working a 91/98 hour working week. Independent research Project Horizon has confirmed that human performance seriously degrades when working long hours, especially at night. This causes tiredness and places all marine users at risk.  ‘The long term risk to health is considerable and was recognised with the European Working Time Directive in 1993. Unlike asbestos, ignored for decades, employers now need to take responsibility. A 91/98 hour working week is unacceptable.’'), 
(6, 'On Thursday, police let the migrants board the train in Budapest but then tried to force them off at a refugee camp to the west of the capital.  Hungarian MPs face a key vote later on whether to tighten border controls as migrants try to pass through to their preferred destination, Germany.  Three other European meetings on Friday will discuss the migrant crisis.  Members of the European Commission are also flying to the Greek island of Kos to examine the difficulties caused by the large numbers of refugees and migrants landing there.  The UN has meanwhile urged the EU to admit up to 200,000 refugees as part of &quot;a mass relocation programme&quot; that had the &quot;mandatory participation&quot; of all member states.  A statement from Antonio Guterres, the UN High Commissioner of Refugees, said Europe needed to build &quot;adequate reception capacities&quot;, especially in Greece, replacing a &quot;piecemeal&quot; approach with a &quot;common strategy&quot;.  &#039;Ashamed&#039;  The Hungarian MPs will also vote on creating new holding camps for migrants, and on whether the situation constitutes a state of emergency.  Prime Minister Viktor Orban on Thursday described the situation as a &quot;German problem&quot; as Germany was where those arriving in the EU &quot;would like to go&quot;.  http://www.bbc.com/news/world-europe-34148891 Jump media player http://www.bbc.co.uk/faqs/online/mp_accessibility_help Media player help  http://www.bbc.com/news/world-europe-34148891#afterFlash Out of media player. Press enter to return or tab to continue.  Media captionHungary&#039;s prime minister says the migrant crisis is &quot;a not a European problem, it is a German problem&quot;   However, Luxembourg&#039;s Foreign Minister Jean Asselborn - who is heading the EU meetings on the crisis - criticised Hungary&#039;s conservative leader on German television on Thursday night, saying: &quot;One sometimes has to be ashamed for Viktor Orban.&quot;  European Council President Donald Tusk said at least 100,000 refugees should be distributed across EU states - a sharp increase on a previous European Commission target of 40,000.  German Chancellor Angela Merkel and French President Francois Hollande said they would present plans for the redistribution of refugees within the EU.  The British government, in particular, is coming under growing pressure to take in more migrants.  British Prime Minister David Cameron is expected to announce http://www.bbc.co.uk/news/uk-34148913 plans to allow more Syrian refugees into the country, to help ease a crisis brought to the fore this week by http://www.bbc.co.uk/news/world-europe-34143445 images of a three-year-old Syrian boy found drowned in Turkey.  Mr Cameron is heading to Spain and Portugal for talks on Friday that are sure to include the migrant crisis.  The crisis is also due to be discussed at a series of high-level talks across Europe on Friday:   	The leaders of Poland, the Czech Republic, Slovakia and Hungary will hold an extraordinary summit in Prague 	European Commission officials will arrive on the island of Kos, in Greece, where thousands of migrants have arrived by boat 	EU foreign ministers will meet in Brussels    Migrant crisis: coverage in detail   http://ichef.bbci.co.uk/news/624/cpsprodpb/CEF9/production/_85358925_af91ca72-e6f7-4e6a-bd7c-765410fce2cf.jpg Migrants are seen at a makeshift camp in an underground station in front of the Keleti railway station in Budapest, Hungary, September 3, 2015.Image copyrightReuters  http://www.bbc.co.uk/news/magazine-34137358 Ten powerful photos  http://www.bbc.co.uk/news/blogs-eu-34144554 Hungary lays bare EU East-West split  http://www.bbc.co.uk/news/blogs-trending-34142804 Will one image change our views?  http://www.bbc.co.uk/news/world-europe-34131911 Migrant crisis in graphics  http://www.bbc.co.uk/news/world-europe-34130639 Volunteers step up   Analysis: Jenny Hill, BBC News, Berlin   http://ichef-1.bbci.co.uk/news/624/cpsprodpb/1742B/production/_85357259_85357258.jpg A girl from Syria, who has just arrived by train, waits to travel onto a reception centre, at the central railway station in Munich, Germany, 03 September 2015.Image copyrightEPA Image captionMany of those travelling through Hungary - like this girl from Syria - have moved on to Germany   Last week, the German government indicated it would grant asylum to Syrian refugees regardless of how they&#039;d entered Europe.  That attitude has enraged the Hungarian leader, Viktor Orban, who blames Germany&#039;s welcoming reputation for the high number of refugees crossing his country.  Angela Merkel disagrees. Germany, she said, is simply fulfilling its &quot;moral and legal&quot; obligations. This is a situation which, she argues, &quot;affects all of us in Europe&quot;.  But it&#039;s a situation that creates a huge domestic challenge too. Up to 800,000 people are expected to seek asylum in Germany this year alone.   http://ichef.bbci.co.uk/news/624/cpsprodpb/6B16/production/_85341472_migrant_journeys_turkey_to_germany_624_v2.png Map  http://www.bbc.co.uk/news/world-europe-34148159 Germany seizes its chance to help  http://www.bbc.co.uk/news/world-europe-34139348 How could EU solve the crisis?   International services had been suspended at Budapest&#039;s Keleti railway station but hundreds crammed on to the first train on Thursday, hoping it would take them to the Austrian border.  Instead, the train stopped at the Hungarian town of Bicske about 40km (25 miles) west of Budapest, which hosts a major refugee camp. Police then lined the platforms.');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_cat`
--

DROP TABLE IF EXISTS `nv4_en_news_cat`;
CREATE TABLE `nv4_en_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_cat`
--

INSERT INTO `nv4_en_news_cat` VALUES
(5, 0, 'Events', '', 'events', '', '', '', 0, 2, 2, 0, 'viewcat_page_new', 0, '', 1, 3, 2, 0, '', '', 1441208947, 1441208947, '6'), 
(4, 0, 'News', '', 'news', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 3, 0, 0, '', '', 1441207346, 1441207346, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_config_post`
--

DROP TABLE IF EXISTS `nv4_en_news_config_post`;
CREATE TABLE `nv4_en_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_config_post`
--

INSERT INTO `nv4_en_news_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(5, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_logs`
--

DROP TABLE IF EXISTS `nv4_en_news_logs`;
CREATE TABLE `nv4_en_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_rows`
--

DROP TABLE IF EXISTS `nv4_en_news_rows`;
CREATE TABLE `nv4_en_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_rows`
--

INSERT INTO `nv4_en_news_rows` VALUES
(3, 4, '4', 0, 2, '', 0, 1441209833, 1441335197, 1, 1441209780, 0, 2, 'VIKING Moves to Expand Australasian Activities', 'viking-moves-to-expand-australasian-activities', '', '2015_09/viking-pic-300x199.jpg', 'VIKING PIC 300x199', 1, '', 1, '4', 1, 1695, 0, 0, 0), 
(4, 4, '4', 0, 2, '', 0, 1441209938, 1441335153, 1, 1441209840, 0, 2, 'Viking acquires hook retrofit leader', 'viking-acquires-hook-retrofit-leader', '', '2015_09/viking-300x200.jpg', 'VIKING 300x200', 1, '', 1, '4', 1, 2162, 0, 0, 0), 
(5, 4, '4', 0, 2, '', 0, 1441210036, 1441335186, 1, 1441209900, 0, 2, 'Nautilus comments on research that says people who work longer hours are at risk of stroke', 'nautilus-comments-on-research-that-says-people-who-work-longer-hours-are-at-risk-of-stroke', '', '2015_09/paper-ships-300x199.jpg', '', 1, '', 1, '4', 1, 1894, 0, 0, 0), 
(6, 4, '4', 0, 1, '', 0, 1441335327, 1441335327, 1, 1441335180, 0, 2, 'Hungary migrant stand-off continues', 'hungary-migrant-stand-off-continues', 'On Thursday, police let the migrants board the train in Budapest but then tried to force them off at a refugee camp to the west of the capital.', '2015_09/viking-pic-300x199.jpg', 'VIKING PIC 300x199', 1, '', 1, '4', 1, 1687, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_sources`
--

DROP TABLE IF EXISTS `nv4_en_news_sources`;
CREATE TABLE `nv4_en_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_tags`
--

DROP TABLE IF EXISTS `nv4_en_news_tags`;
CREATE TABLE `nv4_en_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_tags`
--

INSERT INTO `nv4_en_news_tags` VALUES
(1, 1, 'nautilus', '', '', 'Nautilus'), 
(2, 1, 'research', '', '', 'research');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_tags_id`
--

DROP TABLE IF EXISTS `nv4_en_news_tags_id`;
CREATE TABLE `nv4_en_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_news_tags_id`
--

INSERT INTO `nv4_en_news_tags_id` VALUES
(5, 1, 'Nautilus'), 
(5, 2, 'research');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_news_topics`
--

DROP TABLE IF EXISTS `nv4_en_news_topics`;
CREATE TABLE `nv4_en_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_our_business_logs`
--

DROP TABLE IF EXISTS `nv4_en_our_business_logs`;
CREATE TABLE `nv4_en_our_business_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_page`
--

DROP TABLE IF EXISTS `nv4_en_page`;
CREATE TABLE `nv4_en_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_page_config`
--

DROP TABLE IF EXISTS `nv4_en_page_config`;
CREATE TABLE `nv4_en_page_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_page_config`
--

INSERT INTO `nv4_en_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_port_we_serv`
--

DROP TABLE IF EXISTS `nv4_en_port_we_serv`;
CREATE TABLE `nv4_en_port_we_serv` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_port_we_serv`
--

INSERT INTO `nv4_en_port_we_serv` VALUES
(1, 'Ports we serve', 'Ports-We-Serve', '', '', '', '<div class=\"col-xs-24 col-sm-12 col-md-12\"> <figure class=\"image\" style=\"float:left\"><img alt=\"ship supply port we serv\" src=\"/uploads/port-we-serv/ship-supply-port-we-serv.jpg\" style=\"width: 100%;\" /> <figcaption></figcaption> </figure> </div>  <div class=\"col-xs-24 col-sm-12 col-md-12\"> <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">1. Ho Chi Minh City</span></strong></div>  <div style=\"margin-bottom:15px; margin-left: 50px;\"> <ul style=\"list-style: inherit;\"> 	<li style=\"margin-bottom: 2px; text-align: justify\">Khanh Hoi port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">SPCT port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Cat Lai port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Tan Thuan port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Ben Nghe port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Tan Thuan Dong port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Vopak port</li> </ul> </div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">2. Vung Tau</span></strong></div>  <div style=\"margin-bottom:15px; margin-left: 50px;\"> <ul style=\"list-style: inherit;\"> 	<li style=\"margin-bottom: 2px; text-align: justify\">Dong Nai port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Phu My port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Go dau port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Vedan port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Holcim Thi Vai port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">PTSC port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Cai Mep port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Ha Loc port</li> </ul> </div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">3. Hai Phong – Quang Ninh – Thanh Hoa</span></strong></div>  <div style=\"margin-bottom:15px; margin-left: 50px;\"> <ul style=\"list-style: inherit;\"> 	<li style=\"margin-bottom: 2px; text-align: justify\">Dinh Vu port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Cai Lan port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Hon Gai port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Ha Long port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Nghi Son port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Vung Ang port</li> </ul> </div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">4. Da Nang – Quy Nhon – Tuy Hoa – Nha Trang</span></strong></div>  <div style=\"margin-bottom:15px; margin-left: 50px;\"> <ul style=\"list-style: inherit;\"> 	<li style=\"margin-bottom: 2px; text-align: justify\">Tien Sa port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Thi Nai port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Dung Quoc</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Vung Ro port</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Cam Ranh port</li> </ul> </div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">5. Can Tho port</span></strong></div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">6. Holcim Binh Tri port</span></strong></div>  <div style=\"margin-bottom: 5px; text-align: justify;\"><strong><span style=\"font-size:17px\">7. Shipyards</span></strong></div>  <div style=\"margin-bottom:15px; margin-left: 50px;\"> <ul style=\"list-style: inherit;\"> 	<li style=\"margin-bottom: 2px; text-align: justify\">Bason shipyard</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">SSIC shipyard</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Triyard Ho Chi Minh</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Triyard Vung Tau</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">An Phu shipyard</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">TX51 shipyard</li> 	<li style=\"margin-bottom: 2px; text-align: justify\">Nam Trieu shipyard</li> </ul> </div> </div>', 'ports we,serve', 0, '4', '', 0, 1, 3, 1442638892, 1564823284, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_port_we_serv_config`
--

DROP TABLE IF EXISTS `nv4_en_port_we_serv_config`;
CREATE TABLE `nv4_en_port_we_serv_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_port_we_serv_config`
--

INSERT INTO `nv4_en_port_we_serv_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_referer_stats`
--

DROP TABLE IF EXISTS `nv4_en_referer_stats`;
CREATE TABLE `nv4_en_referer_stats` (
  `host` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_referer_stats`
--

INSERT INTO `nv4_en_referer_stats` VALUES
('google.com', 1922, 163, 133, 160, 186, 211, 227, 264, 129, 99, 106, 125, 119, 1596706209), 
('success-seo.com', 35, 0, 0, 0, 0, 0, 0, 0, 0, 35, 0, 0, 0, 1442991334), 
('burger-imperia.com', 77, 8, 11, 19, 8, 5, 4, 3, 0, 4, 4, 8, 3, 1556871143), 
('hvd-store.com', 8, 1, 2, 0, 2, 1, 0, 1, 0, 1, 0, 0, 0, 1500818928), 
('buttons-for-website.com', 35, 3, 5, 0, 1, 0, 0, 0, 0, 5, 0, 18, 3, 1459808289), 
('pizza-imperia.com', 26, 1, 10, 2, 1, 6, 0, 1, 0, 1, 3, 1, 0, 1556871500), 
('google.com.vn', 388, 31, 17, 41, 31, 30, 41, 32, 40, 36, 34, 31, 24, 1596623702), 
('bluerobot.info', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1441990664), 
('video--production.com', 4, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 3, 0, 1447740627), 
('google.com.sg', 100, 10, 5, 6, 7, 6, 6, 9, 15, 8, 8, 12, 8, 1589633230), 
('google.com.bd', 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1442892130), 
('hundejo.com', 24, 1, 8, 3, 2, 4, 1, 1, 1, 1, 1, 1, 0, 1557076959), 
('google.com.pr', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1442946483), 
('seavendors.com', 17, 0, 0, 2, 0, 4, 2, 2, 4, 1, 0, 1, 1, 1499676393), 
('facebook.com', 48, 8, 6, 2, 0, 4, 4, 3, 1, 0, 6, 7, 7, 1594022764), 
('m.facebook.com', 632, 45, 17, 10, 8, 24, 31, 29, 3, 3, 25, 89, 348, 1596621199), 
('vietnamshipsupply.com', 405, 10, 10, 81, 67, 28, 65, 67, 6, 4, 22, 5, 40, 1592686740), 
('whois.domaintools.com', 38, 3, 2, 2, 3, 4, 1, 2, 4, 2, 5, 6, 4, 1518846996), 
('rankings-analytics.com', 66, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 54, 3, 1449094712), 
('justprofit.xyz', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1445849979), 
('l.facebook.com', 42, 3, 2, 1, 4, 7, 6, 3, 3, 0, 3, 3, 7, 1596420307), 
('google.com.sv', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1446233617), 
('google.it', 19, 3, 5, 1, 5, 0, 0, 1, 1, 0, 1, 2, 0, 1554712424), 
('google.de', 44, 6, 1, 1, 7, 1, 3, 1, 0, 2, 5, 15, 2, 1568386739), 
('scripted.com', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 1450681298), 
('google.co.in', 195, 18, 18, 16, 17, 11, 30, 8, 21, 22, 11, 10, 13, 1592808144), 
('google.cl', 3, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 1492901212), 
('google.nl', 23, 3, 2, 1, 2, 2, 5, 2, 0, 0, 1, 1, 4, 1579241343), 
('pizza-tycoon.com', 39, 4, 8, 6, 3, 2, 6, 1, 0, 1, 3, 4, 1, 1553057818), 
('', 122, 4, 7, 10, 13, 17, 13, 15, 16, 3, 5, 12, 7, 1595629657), 
('google.com.ua', 7, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1541624575), 
('uptimebot.net', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1451077421), 
('google.co.uk', 36, 5, 1, 5, 0, 3, 3, 3, 8, 3, 1, 3, 1, 1584582564), 
('top1-seo-service.com', 51, 15, 17, 8, 11, 0, 0, 0, 0, 0, 0, 0, 0, 1460412987), 
('google.com.hk', 56, 5, 5, 4, 6, 5, 2, 13, 5, 1, 3, 4, 3, 1596443543), 
('google.co.kr', 42, 5, 5, 7, 5, 1, 2, 3, 3, 3, 5, 1, 2, 1583807569), 
('google.co.th', 38, 5, 9, 7, 1, 0, 1, 7, 1, 2, 1, 3, 1, 1594201396), 
('google.com.ng', 59, 9, 10, 1, 8, 5, 4, 3, 6, 3, 4, 4, 2, 1559176842), 
('buyessaynow.biz', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1456121959), 
('bing.com', 140, 11, 9, 12, 8, 12, 12, 12, 11, 9, 22, 13, 9, 1594231944), 
('google.gr', 28, 1, 1, 2, 2, 0, 3, 6, 2, 4, 3, 0, 4, 1578660604), 
('google.com.sa', 6, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1538636501), 
('google.ae', 21, 3, 2, 3, 3, 0, 1, 0, 1, 1, 3, 2, 2, 1556434836), 
('google.com.ph', 45, 3, 0, 8, 5, 1, 3, 4, 8, 6, 2, 2, 3, 1587536189), 
('google.at', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1457597284), 
('shar.es', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1457758007), 
('uptime.com', 177, 1, 19, 38, 23, 27, 42, 0, 0, 0, 4, 0, 23, 1561557966), 
('t.co', 6, 2, 0, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1548571071), 
('google.co.id', 24, 4, 1, 4, 3, 0, 1, 1, 3, 1, 4, 1, 1, 1564751431), 
('stenham.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1458851746), 
('google.es', 9, 1, 0, 1, 2, 2, 1, 0, 0, 0, 2, 0, 0, 1561447953), 
('google.se', 5, 2, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1578125788), 
('google.dk', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1494403763), 
('google.com.pk', 11, 0, 0, 1, 2, 2, 0, 1, 1, 3, 1, 0, 0, 1556637772), 
('google.com.au', 18, 3, 0, 0, 2, 2, 1, 4, 0, 2, 3, 1, 0, 1596165225), 
('google.com.tr', 43, 6, 3, 3, 2, 1, 3, 2, 2, 4, 4, 8, 5, 1574456450), 
('google.hr', 9, 1, 0, 3, 1, 1, 0, 0, 0, 0, 1, 0, 2, 1583840825), 
('vietnamquartzstone.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1462320720), 
('stanleylei.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1462427278), 
('google.co.nz', 5, 0, 0, 1, 0, 2, 0, 0, 1, 0, 1, 0, 0, 1585552746), 
('10.2.1.31', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1463728104), 
('google.be', 5, 0, 0, 0, 0, 1, 0, 0, 0, 3, 1, 0, 0, 1540912147), 
('google.lk', 8, 1, 0, 0, 1, 0, 1, 2, 0, 2, 1, 0, 0, 1556273080), 
('findmeakaw.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1465588924), 
('soundbeachtech.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1465851058), 
('inncov.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1466014337), 
('yachting-pages.com', 10, 1, 1, 0, 2, 0, 2, 2, 1, 0, 1, 0, 0, 1523873987), 
('ship.gr', 193, 17, 12, 15, 11, 20, 21, 19, 21, 17, 7, 18, 15, 1594456882), 
('mlicnak.top', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1466363979), 
('mobile.companiess.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1466503816), 
('sharplyknives.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1466709037), 
('google.com.tw', 25, 2, 3, 5, 2, 2, 3, 4, 0, 0, 0, 4, 0, 1563245338), 
('eggcarvers.com', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1467792330), 
('r.search.yahoo.com', 10, 0, 1, 1, 2, 0, 3, 1, 0, 2, 0, 0, 0, 1554294627), 
('images.google.fr', 2, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1473839842), 
('google.fi', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1468329195), 
('search.yahoo.com', 32, 1, 1, 5, 0, 2, 1, 6, 2, 2, 5, 3, 4, 1553366133), 
('lm.facebook.com', 4, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 1594567755), 
('search.yahoo.co.jp', 23, 1, 1, 0, 0, 3, 1, 9, 4, 1, 3, 0, 0, 1595385205), 
('google.com.br', 3, 1, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1516572949), 
('shipsup.com', 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 1471917209), 
('google.pl', 7, 0, 1, 1, 0, 0, 1, 0, 2, 1, 0, 0, 1, 1591721498), 
('viet-kabu.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1473353582), 
('google.com.eg', 11, 1, 0, 2, 0, 0, 1, 2, 1, 2, 1, 0, 1, 1538674899), 
('dmoz.org', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1474118721), 
('google.ru', 9, 1, 1, 0, 2, 1, 1, 1, 1, 1, 0, 0, 0, 1589883412), 
('yandex.ru', 177, 9, 15, 10, 14, 24, 25, 19, 14, 5, 20, 12, 10, 1595921041), 
('google.ca', 21, 2, 0, 3, 0, 1, 1, 1, 3, 3, 2, 1, 4, 1576360327), 
('ya.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1476444960), 
('search.ask.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1477300232), 
('google.com.my', 10, 2, 0, 0, 1, 1, 0, 2, 1, 0, 1, 2, 0, 1579268127), 
('google.co.il', 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1515677030), 
('inboundlinks.win', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1480721004), 
('google.ro', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1481350957), 
('google.co.jp', 25, 0, 1, 3, 0, 2, 3, 3, 5, 3, 1, 1, 3, 1594605130), 
('localhost', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1482597300), 
('companiess.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1483498959), 
('google.mv', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1484839604), 
('google.com.mm', 4, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 1557209009), 
('google.sn', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1485454763), 
('images.google.de', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1485708649), 
('search.aol.com', 2, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534296799), 
('duckduckgo.com', 6, 0, 1, 0, 0, 0, 1, 0, 0, 1, 2, 0, 1, 1568878785), 
('google.com.kw', 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1510748613), 
('w3data.co', 4, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1490787298), 
('google.lv', 4, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1535974022), 
('tex-smoke.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1489698762), 
('google.com.kh', 5, 0, 1, 1, 0, 0, 0, 1, 0, 0, 2, 0, 0, 1594825525), 
('de.search.yahoo.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1490922120), 
('marinetraffic.com', 26, 2, 1, 1, 5, 2, 6, 2, 3, 0, 3, 1, 0, 1596617784), 
('google.tn', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1493606979), 
('astrakhan.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1497003452), 
('kemerovo.zrus.org', 6, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 1496045997), 
('vladimir.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1497170262), 
('your-bearings.com', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1495175089), 
('bio-optomarket.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494528287), 
('angarsk.zrus.org', 4, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1496464670), 
('vologda.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1496916148), 
('wttavern.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494560400), 
('dvervmoskvu.ru', 2, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1500162189), 
('khantymansiysk.zrus.org', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1496193690), 
('arenda-avtoprokat-krasnodar.ru', 6, 0, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, 1497014799), 
('vzglyadriv.kg', 4, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1497099323), 
('ufa.zrus.org', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1496207402), 
('kazan.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494573972), 
('perm.zrus.org', 5, 0, 0, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 1496891036), 
('novorossiysk.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496656808), 
('lipetsk.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1496584202), 
('bestdraws.com', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496924412), 
('khabarovsk.zrus.org', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1495374694), 
('ivanovo.zrus.org', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1494660851), 
('saratov.zrus.org', 5, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1495762530), 
('irkutsk.zrus.org', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1495870132), 
('prohoster.info', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1496128681), 
('pechikamini.ru', 9, 0, 0, 0, 0, 3, 5, 1, 0, 0, 0, 0, 0, 1594970939), 
('jjbabskoe.ru', 9, 1, 3, 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1552523190), 
('tagil.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494697138), 
('european-torches.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1495849760), 
('dellalimov.com', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496509375), 
('nagdak.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1495152459), 
('japan-bearings.ru', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1496452365), 
('ekaterinburg.nodup.ru', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1495629529), 
('novosibirsk.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1496372614), 
('ekaterinburg.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496930877), 
('magnitogorsk.zrus.org', 5, 0, 0, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 1496420796), 
('777-club.ru', 3, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1496695791), 
('yaroslavl.zrus.org', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1495209997), 
('kirov.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496536044), 
('simferopol.zrus.org', 7, 0, 0, 0, 0, 6, 1, 0, 0, 0, 0, 0, 0, 1496839818), 
('yoshkarola.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494863204), 
('google.no', 4, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1528634992), 
('4istoshop.com', 7, 0, 0, 0, 0, 6, 1, 0, 0, 0, 0, 0, 0, 1527163380), 
('sevastopol.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494907171), 
('store-rx.com', 4, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1524411472), 
('mygameplus.ru', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1496159542), 
('vykupavto-krasnodar.ru', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1593042307), 
('vipms.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1494956899), 
('murmansk.zrus.org', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1496102241), 
('tuapse.zrus.org', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1496036472), 
('kinoplen.ru', 4, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 1496910950), 
('oballergiya.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1495960164), 
('stavropol.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1497033789), 
('8xv8.com', 5, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 4, 0, 1542354508), 
('volgograd.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1496705179), 
('penza.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496813632), 
('naberezhnyechelny.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496740847), 
('groupmoney.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495152899), 
('videochat.world', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495160252), 
('ulanude.zrus.org', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1495347916), 
('izhevsk.zrus.org', 3, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1497003383), 
('eorogo.top', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495190492), 
('link.ac', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495205594), 
('belgorod.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495235636), 
('moscow.zrus.org', 5, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1496004520), 
('autolombard-krasnodar.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495277632), 
('google.bj', 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1508508063), 
('coindirect.io', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495324294), 
('tyumen.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496648350), 
('freza-sverlo.ru', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1495686163), 
('tomsk.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495374028), 
('tver.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496640574), 
('craftinsta.ru', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496639851), 
('kursk.zrus.org', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1496259703), 
('novgorod.zrus.org', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1496191417), 
('krasnoyarsk.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496595739), 
('paydayloanslocal.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495457509), 
('moivestiy.biz', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495491910), 
('yalta.zrus.org', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1495846574), 
('barnaul.zrus.org', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496832092), 
('serdcenebolit.com', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1496615451), 
('nefteyugansk.zrus.org', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1497058242), 
('gelendzhik.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495613337), 
('tolyatti.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495627917), 
('orenburg.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496970696), 
('kaliningrad.zrus.org', 4, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1497172274), 
('impa.net', 48, 7, 3, 5, 1, 3, 7, 5, 4, 7, 0, 2, 4, 1564519495), 
('ulyanovsk.zrus.org', 5, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 1496345132), 
('piter.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1497101896), 
('bpro1.top', 7, 0, 0, 0, 0, 1, 1, 0, 0, 0, 4, 1, 0, 1541770375), 
('ascat.porn', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495973442), 
('rostov.zrus.org', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496779572), 
('bryansk.zrus.org', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1495990430), 
('nac-bearings.ru', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1496660755), 
('xn--e1afanlbnfckd7c3d.xn--p1ai', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1496025629), 
('life-instyle.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1496051805), 
('landscaping.center', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1496239008), 
('krasnodar.zrus.org', 4, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1497064516), 
('free-gluten.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1496182441), 
('chatroulette.online', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1498021763), 
('sochi.zrus.org', 4, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 1496452891), 
('stal-rulon.ru', 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1496266067), 
('namenectar.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496267770), 
('nodup.ru', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1496820456), 
('akita.kz', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496351247), 
('video-chat.in', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1496552323), 
('samara.zrus.org', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496412006), 
('videochat.tv.br', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496432891), 
('maslenka.kz', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1497084053), 
('murmansk.xrus.org', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496609658), 
('inome.com.ua', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1496796468), 
('murmansk.afora.ru', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496764096), 
('kostroma.zrus.org', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496899467), 
('buydissertation.net', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496912553), 
('x-lime.net', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496956822), 
('omsk.zrus.org', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1496959273), 
('typer.one', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497054958), 
('nizhnevartovsk.zrus.org', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497128032), 
('coinsspb.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497141590), 
('essayservicewriting.org', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1498445026), 
('google.bg', 5, 0, 0, 0, 0, 1, 4, 0, 0, 0, 0, 0, 0, 1560952442), 
('videochat.cafe', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497476642), 
('chatroulette.world', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497623808), 
('discretesearch.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1497865505), 
('na19.salesforce.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1498061591), 
('baidu.com', 22, 0, 0, 0, 0, 0, 13, 9, 0, 0, 0, 0, 0, 1500899690), 
('google.pt', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1498597689), 
('203.229.225.135', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1498807349), 
('uptime-beta.net', 19, 0, 0, 0, 0, 0, 0, 11, 0, 0, 7, 1, 0, 1509759936), 
('uptime-gamma.net', 16, 0, 0, 0, 0, 0, 0, 11, 0, 0, 5, 0, 0, 1509186071), 
('uptime-alpha.net', 11, 0, 0, 0, 0, 0, 0, 6, 0, 0, 4, 1, 0, 1509997630), 
('uptime-delta.net', 16, 0, 0, 0, 0, 0, 0, 9, 0, 0, 5, 2, 0, 1509862841), 
('coccoc.com', 12, 0, 0, 3, 1, 2, 0, 4, 0, 0, 2, 0, 0, 1559204272), 
('shoppingmiracles.co.uk', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1501147361), 
('google.com.bh', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1502001504), 
('google.com.om', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1502260257), 
('google.fr', 5, 1, 0, 0, 0, 0, 0, 2, 1, 0, 1, 0, 0, 1563704277), 
('google.com.co', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1503605078), 
('google.com.py', 2, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1504624399), 
('int.search.myway.com', 6, 0, 1, 0, 0, 0, 1, 0, 0, 2, 1, 0, 1, 1571730311), 
('google.az', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1505978900), 
('infomarine.gr', 8, 0, 1, 2, 0, 0, 0, 0, 0, 2, 3, 0, 0, 1522405658), 
('translate.googleusercontent.com', 27, 0, 0, 0, 0, 0, 14, 0, 0, 10, 0, 3, 0, 1560468822), 
('google.ee', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1507025512), 
('google.com.ar', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1544037033), 
('info.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1509270772), 
('l.instagram.com', 11, 3, 0, 1, 0, 1, 0, 0, 0, 1, 4, 0, 1, 1578471738), 
('webcache.googleusercontent.com', 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1552512472), 
('teoma.com', 3, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1534295163), 
('google.com.cy', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 0, 1539766008), 
('google.lt', 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1515136032), 
('search.azby.fmworld.net', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1513238336), 
('uptime-us.net', 12, 7, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1518125286), 
('uptime-as.net', 15, 10, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1517954307), 
('vietnamshipsupply.com.seocheckupx.net', 4, 1, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1524233085), 
('uptime-eu.net', 9, 8, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1517606673), 
('google.rs', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1515504738), 
('google.hn', 2, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1563716850), 
('ca.search.yahoo.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1516238203), 
('google.com.mx', 4, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1549912559), 
('ask.com', 5, 2, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1551044815), 
('google.mu', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1516887843), 
('pills24h.com', 35, 0, 24, 8, 0, 1, 0, 0, 0, 0, 0, 2, 0, 1542668881), 
('natprof.ru', 4, 0, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521829529), 
('perl.dp.ua', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518383876), 
('electronic-component.org', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1517997163), 
('yur-p.ru', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519045888), 
('beclean-nn.ru', 9, 0, 1, 0, 0, 0, 3, 3, 0, 0, 0, 2, 0, 1593914355), 
('whoiswho.crimea.ua', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521335227), 
('mamasuper.prom.ua', 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521652358), 
('kozhakoshek.com', 4, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521959195), 
('meriton.ru', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518794559), 
('no-rx.info', 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520127451), 
('metallo-konstruktsii.ru', 7, 0, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522283686), 
('ege-russian.ru', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518689959), 
('sildenafil-tadalafil.info', 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520526603), 
('petrushka-restoran.ru', 6, 0, 2, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521626330), 
('msk.prom23.ru', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518175288), 
('hentai-manga.porn', 4, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521766424), 
('truebeauty.cc', 6, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521074764), 
('pornosemki.info', 9, 0, 5, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552127189), 
('chatroulette.life', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518286190), 
('vgoloveboli.net', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518293713), 
('cryptoswap.biz', 4, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520691971), 
('buynorxx.com', 5, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520761414), 
('nakozhe.com', 7, 0, 1, 1, 0, 0, 0, 0, 0, 0, 2, 3, 0, 1542403228), 
('englishtopik.ru', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518483572), 
('pillscheap24h.com', 5, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521138972), 
('buy-meds24.com', 9, 0, 1, 1, 0, 3, 0, 0, 0, 0, 4, 0, 0, 1540045204), 
('pospektr.ru', 3, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1539515873), 
('msu.kharkov.ua', 5, 0, 1, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522450440), 
('spy-app.info', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518695841), 
('texnika.com.ua', 7, 0, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521850944), 
('zelena-mriya.com.ua', 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522456201), 
('mysexpics.ru', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518794560), 
('pfrf-kabinet.ru', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520835785), 
('columb.net.ua', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518855330), 
('raschtextil.com.ua', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519686977), 
('tam-gde-more.ru', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1518938494), 
('club-lukojl.ru', 5, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522268892), 
('vzube.com', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520025362), 
('komp-pomosch.ru', 18, 0, 13, 1, 0, 0, 0, 0, 0, 0, 3, 1, 0, 1552042369), 
('onlywood.ru', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521263816), 
('ankerch.crimea.ua', 4, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521153027), 
('slomm.ru', 9, 0, 2, 3, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1527711271), 
('pornohd1080.online', 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520949594), 
('kipu.crimea.ua', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521299073), 
('pornosmola.info', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520050277), 
('profnastil-moscow.ru', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519162512), 
('rangjued.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519189638), 
('gazel-72.ru', 4, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521219104), 
('skinali.photo-clip.ru', 11, 1, 2, 1, 0, 0, 3, 0, 0, 0, 1, 3, 0, 1550180507), 
('mtsguru.ru', 6, 0, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522616978), 
('pornoelita.info', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519758492), 
('feminist.org.ua', 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521560111), 
('makler.org.ua', 5, 0, 1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523251923), 
('kinoduh.ru', 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520504141), 
('kerch.site', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522057397), 
('headpharmacy.com', 3, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521570115), 
('aktau.xkaz.org', 4, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521544423), 
('potolokelekor.ru', 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521105641), 
('kazka.ru', 7, 0, 2, 2, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1593232654), 
('sundrugstore.com', 5, 0, 1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524116834), 
('avtorskoe-vino.ru', 3, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520883778), 
('doxyporno.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1519665519), 
('gezlev.com.ua', 2, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521018491), 
('12u.info', 5, 0, 1, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522815151), 
('studentguide.ru', 20, 0, 1, 6, 2, 11, 0, 0, 0, 0, 0, 0, 0, 1590858673), 
('superoboi.com.ua', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520500467), 
('suzuki-metropolis.kiev.ua', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521667088), 
('autoblog.org.ua', 4, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522006843), 
('game300.ru', 3, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522720884), 
('aibolita.com', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520663198), 
('03p.info', 5, 0, 1, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551039512), 
('krasivoe-hd.net', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521437238), 
('4inn.ru', 6, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1523517249), 
('inet-shop.su', 5, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523722784), 
('med-dopomoga.com', 7, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1542681735), 
('happysong.ru', 5, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522816685), 
('online-sbank.ru', 3, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522652399), 
('bonkers.name', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520410809), 
('transit.in.ua', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521300979), 
('elementspluss.ru', 3, 0, 0, 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1529341657), 
('atyrau.xkaz.org', 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521182790), 
('03e.info', 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521606115), 
('sildia.com', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520901642), 
('google.com.lb', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520627665), 
('beachtoday.ru', 7, 0, 0, 6, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522883451), 
('animenime.ru', 3, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524809645), 
('stat.lviv.ua', 3, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522855631), 
('td-l-market.ru', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520774274), 
('deart-13.ru', 6, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1524825512), 
('allergick.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1520933470), 
('picturesmania.com', 3, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1524338757), 
('professionalsolutions.eu', 4, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523566898), 
('strady.org.ua', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521521749), 
('veselokloun.ru', 2, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523391803), 
('mikozstop.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521332678), 
('buypuppies.ca', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521374534), 
('rieltor.crimea.ua', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521569584), 
('laminat.com.ua', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1521668416), 
('fartunabest.ru', 5, 0, 0, 1, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1524660631), 
('pk-services.ru', 3, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1552142822), 
('dermatovenerologiya.com', 5, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1552211510), 
('komputers-best.ru', 25, 0, 4, 2, 0, 0, 4, 0, 0, 0, 10, 5, 0, 1593493033), 
('lerporn.info', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522060645), 
('workius.ru', 2, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522770358), 
('ek-invest.ru', 3, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1525530671), 
('filesclub.net', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522350980), 
('exdocsfiles.com', 3, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522591201), 
('zahvat.ru', 4, 0, 0, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1525124976), 
('hoztorg-opt.ru', 3, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1525476282), 
('popugaychiki.com', 3, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1526705728), 
('goodhumor24.com', 2, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523952809), 
('uralsk.xkaz.org', 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522353269), 
('kozhasobak.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522236380), 
('distonija.com', 7, 0, 3, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1551979773), 
('eduinfosite.com', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1522411748), 
('magnetic-bracelets.ru', 7, 0, 3, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1549307831), 
('edudocs.net', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522531859), 
('jobius.com.ua', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1526514832), 
('sovetskie-plakaty.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522603214), 
('xn--80aaajkrncdlqdh6ane8t.xn--p1ai', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522660994), 
('univerfiles.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522674348), 
('svetka.info', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522720054), 
('healbio.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522742321), 
('spb-scenar.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522750512), 
('unlimitdocs.net', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1523628697), 
('xn----7sbabn5abjehfwi8bj.xn--p1ai', 8, 0, 0, 0, 1, 0, 0, 0, 0, 0, 5, 2, 0, 1542049110), 
('infodocsportal.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1522855346), 
('landliver.org', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523252264), 
('prosmibank.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523523162), 
('docsarchive.net', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523630818), 
('healgastro.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523746278), 
('docsportal.net', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523785893), 
('docs4all.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1523785897), 
('krasnodar-avtolombard.ru', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1526628248), 
('stavimdveri.ru', 3, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 1526363576), 
('brillianty.info', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524640811), 
('google.com.pe', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1555002056), 
('incitystroy.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524699492), 
('documentbase.net', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524839820), 
('sorus.ucoz.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1524989426), 
('bird1.ru', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1526255235), 
('elvel.com.ua', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1527392642), 
('yhirurga.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1527301383), 
('tsatu.edu.ua', 3, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 1541528607), 
('office2web.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1525758031), 
('kino2018.cc', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1525790505), 
('spb-plitka.ru', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1527301555), 
('tattoo-stickers.ru', 3, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1529171173), 
('pc-services.ru', 4, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1529827352), 
('nova.rambler.ru', 4, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1544245013), 
('kinosed.net', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1526091830), 
('fidalsa.de', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1526099268), 
('google.so', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1526304785), 
('documentsite.net', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1526337013), 
('atyks.ru', 2, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1527881777), 
('regionshop.biz', 5, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, 1, 0, 1541323130), 
('shnyagi.net', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527016780), 
('sovetogorod.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527064457), 
('beremenyashka.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527137410), 
('ogorodnic.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527245265), 
('hyip-zanoza.me', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1527758303), 
('gandikapper.ru', 6, 0, 0, 0, 0, 1, 5, 0, 0, 0, 0, 0, 0, 1529346815), 
('odiabetikah.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527783386), 
('prostitutki-spb.spb.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527786808), 
('officedocuments.net', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1527797823), 
('tw.search.yahoo.com', 4, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 1529572250), 
('yandex.ua', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1528712740), 
('xn-----7kcaaxchbbmgncr7chzy0k0hk.xn--p1ai', 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1529523255), 
('resell-seo-services.com', 7, 0, 0, 0, 0, 0, 3, 2, 2, 0, 0, 0, 0, 1533313799), 
('mybuh.kz', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1529514715), 
('hard-porn.mobi', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1528869181), 
('google.ba', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1528891743), 
('google.hu', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1529910791), 
('cjb.net', 3, 0, 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 1534033978), 
('vietnamshipsupply.com.seoservices2018.com', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1530501812), 
('google.cz', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1530640131), 
('th.search.yahoo.com', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1531368025), 
(' vietnamshipsupply.com', 463, 0, 0, 0, 0, 12, 0, 9, 0, 0, 0, 312, 130, 1589545797), 
('sildenafilreviews.com', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1532419744), 
('images.google.com', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1533881181), 
('modnie-futbolki.net', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534427395), 
('lider82.ru', 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1539240509), 
('gepatit-info.top', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534612000), 
('metallosajding.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534742641), 
('avtointeres.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534763122), 
('rybalka-opt.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534881011), 
('technika-remont.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1534916542), 
('google.co.ve', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1535123436), 
('xn-----6kcamwewcd9bayelq.xn--p1ai', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1535189995), 
('dosugrostov.site', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1535415142), 
('x5market.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1535431271), 
('google.ie', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1536359536), 
('203.233.24.9', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1536626969), 
('openurls.com.cn', 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1542252361), 
('maytau.ut.edu.vn', 14, 2, 0, 0, 1, 2, 1, 2, 0, 1, 3, 1, 1, 1591063823), 
('serdechnic.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1538529654), 
('innoslicon.com', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1539128187), 
('cariestop.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1538720428), 
('grafaman.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1539570945), 
('sky-mine.ru', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1540165200), 
('mega-polis.biz.ua', 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 0, 1541871573), 
('xn--80aaafbn2bc2ahdfrfkln6l.xn--p1ai', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 1541496807), 
('detskiezabolevaniya.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1538696811), 
('buypillsonline24h.com', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 1541804993), 
('elonm.ru', 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 0, 1542272996), 
('xn----7sbbahaq9bb5afgiqfliv4m.xn--p1ai', 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 1540599614), 
('yginekologa.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1538867252), 
('vector.peskostryi.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1541885263), 
('veterinariya.com', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1540901929), 
('dverirespekt.ru', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1540462687), 
('xn--e1aaajzchnkg.ru.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1540410192), 
('spinanebolit.com', 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 2, 0, 1541636566), 
('pornoplen.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1539566874), 
('stroi-24.ru', 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 0, 1542140402), 
('xn--d1abj0abs9d.in.ua', 16, 0, 0, 0, 3, 1, 5, 3, 0, 0, 4, 0, 0, 1594089837), 
('hit-kino.ru', 7, 2, 1, 3, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1551832266), 
('baikaleminer.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1539288813), 
('vanrise.com.ua', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 1542047990), 
('203.233.19.171', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1539327703), 
('migronis.com', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 1541313446), 
('artclipart.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1542763130), 
('zameskino.ru', 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 3, 0, 1542662874), 
('gcup.ru', 3, 0, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 1592869444), 
('pp-budpostach.com.ua', 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 3, 0, 1541653790), 
('cheappills24h.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1540856808), 
('drugstoreforyou.com', 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 0, 1541390131), 
('google.com.tj', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 1542113162), 
('vykup-avto-krasnodar.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1540955652), 
('sweet.tv', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 1542761797), 
('sta-grand.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1540529692), 
('infra-e.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1541712454), 
('doxysexy.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1540918274), 
('www4.bing.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1540730115), 
('phinist.net', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, 0, 1541257388), 
('s-forum.biz', 13, 3, 0, 0, 0, 5, 0, 0, 0, 0, 0, 5, 0, 1590941622), 
('buyclomidonlaine.com', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1542399287), 
('pornoslave.net', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1542565487), 
('kinostar.online', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1541532502), 
('kinoprinc.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1542113917), 
('jav-fetish.com', 7, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 1575059807), 
('iskussnica.ru', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1541878579), 
('5elementov.ru', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 1542514001), 
('pornobest.su', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1541737926), 
('pornhive.org', 8, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1549826913), 
('ukrtvory.in.ua', 2, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1587149597), 
('rxshop.md', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542295729), 
('videotop.biz', 7, 2, 3, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1551400353), 
('sowhoz.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542600637), 
('rumamba.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542669899), 
('x-lime.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542708463), 
('beauty-lesson.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542782396), 
('smart-way.space', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542864279), 
('bitcoin-ua.top', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1542873926), 
('google.tg', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1544527958), 
('usatoday.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1545240941), 
('engadget.search.aol.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1547223275), 
('drev.biz', 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549260631), 
('french-poetry.com', 5, 1, 1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1589678565), 
('rus-lit.com', 9, 4, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 1588626064), 
('souvenirua.com', 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548376445), 
('fsalas.com', 7, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549433417), 
('123movies.love', 5, 3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552092801), 
('serialsx.ru', 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1547688813), 
('vezdevoz.com.ua', 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1547688813), 
('narosty.com', 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548853965), 
('greenshop.su', 10, 1, 2, 1, 0, 0, 5, 1, 0, 0, 0, 0, 0, 1593803735), 
('deutsche-poesie.com', 4, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1589134087), 
('javcoast.com', 7, 5, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1589722659), 
('onlinewot.ru', 7, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551351339), 
('bin-brokers.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548067270), 
('eurocredit.xyz', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548087171), 
('skazki-rus.ru', 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550152570), 
('porndl.org', 7, 5, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551602484), 
('francaise-poesie.com', 7, 4, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1589411334), 
('seoprofisional.ru', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548219870), 
('psn-card.ru', 11, 2, 8, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551978662), 
('jav-fetish.site', 8, 1, 3, 3, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1590727348), 
('tamada69.com', 10, 5, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552509595), 
('javlibrary.cc', 6, 1, 2, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1591200666), 
('automobile-spec.com', 7, 1, 2, 0, 0, 2, 1, 1, 0, 0, 0, 0, 0, 1593756194), 
('student.belreferatov.net', 8, 1, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549433417), 
('cattyhealth.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548435601), 
('arabic-poetry.com', 10, 3, 0, 0, 0, 6, 1, 0, 0, 0, 0, 0, 0, 1591374227), 
('allvacancy.ru', 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548437805), 
('mydirtystuff.com', 10, 3, 3, 1, 0, 1, 2, 0, 0, 0, 0, 0, 0, 1591518668), 
('gidonline.one', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548511874), 
('mrbojikobi4.biz', 7, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550403636), 
('vseigru.one', 6, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549113376), 
('franshiza.shtaketniki.ru', 9, 1, 7, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552548433), 
('okoshkah.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548634183), 
('kakadu-interior.com.ua', 3, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549707920), 
('inmoll.com', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548712289), 
('rutor.group', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548727001), 
('svensk-poesi.com', 4, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550496124), 
('supermama.top', 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549501141), 
('gelstate.ru', 15, 3, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552365841), 
('su1ufa.ru', 5, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549740122), 
('your-tales.ru', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1548944169), 
('kredit-pod-zalog.mozello.ru', 6, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551292070), 
('panicatack.com', 8, 0, 1, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552460474), 
('vpdr.pl', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549509120), 
('medbrowse.info', 6, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551206973), 
('spain-poetry.com', 4, 0, 1, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1591000889), 
('bestfortraders.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549288229), 
('natali-forex.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549471600), 
('draniki.org', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551140975), 
('top10-online-games.com', 4, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550746176), 
('cc.bingj.com', 4, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1549705785), 
('torrentgamer.net', 6, 0, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552365842), 
('infogame.name', 7, 0, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552523191), 
('php-market.ru', 6, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552234700), 
('burger-tycoon.com', 4, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550575168), 
('xn----btbdvdh4aafrfciljm6k.xn--p1ai', 4, 0, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551676766), 
('sel-hoz.com', 3, 0, 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1586781540), 
('find1friend.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550414281), 
('internet-start.net', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550634516), 
('dobrivikna.com.ua', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550573501), 
('veles.shop', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1550582043), 
('mamylik.ru', 9, 0, 2, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552460474), 
('pro-poly.ru', 5, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552523192), 
('lerporn.com', 4, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552347180), 
('mydoctorok.ru', 7, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552347180), 
('vzubah.com', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551148112), 
('greatdealshop.com', 5, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552535459), 
('uginekologa.com', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551220461), 
('sexuria.net', 13, 0, 0, 12, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1590679737), 
('lalalove.ru', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551706449), 
('naturalpharm.com.ua', 5, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552365841), 
('eropho.com', 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1551900453), 
('velomaster.com.ua', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552027723), 
('grand-chlen.ru', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552043399), 
('supermodni.com.ua', 3, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552127189), 
('piluli.info', 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1552404264), 
('emailmarketingrobot.com', 10, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 1554929853), 
('yandex.com.tr', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1556201813), 
('sogou.com', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1556211591), 
('1.cz', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1556212948), 
('jeffoi.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1558523599), 
('kvasir.no', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1559136371), 
('search.zum.com', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1593157617), 
('search.naver.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1560913060), 
('nexus.gruppofinservice.com', 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1564127176), 
('ecosia.org', 2, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1581736013), 
('google.am', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1568470953), 
('datadepths.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1568570382), 
('progressive-seo.com', 28, 9, 0, 0, 0, 0, 0, 0, 0, 1, 1, 7, 10, 1580436260), 
('u-238.com.ar', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1571882589), 
('pacificair.com', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1573282176), 
('detoxmed24.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1573532245), 
('eropho.net', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1573585452), 
('pavietnam.vn', 10, 2, 0, 2, 0, 2, 2, 0, 0, 0, 0, 2, 0, 1593091633), 
('us.search.yahoo.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574208182), 
('razvratnoe.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574343455), 
('vchulkah.net', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574343559), 
('vietnamsupplychain.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574365863), 
('otopleniedomov.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574717334), 
('tabakur77.top', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1575349084), 
('cwetochki.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574789270), 
('perederni.net', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574808199), 
('linkedin.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574816525), 
('books-top.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1574895828), 
('travel-semantics.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1575231828), 
('gdzkurokam.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1575429067), 
('frankofficial.ru', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1575485918), 
('pshare.biz', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1575497705), 
('studworks.org', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1575710943), 
('1xbet-in.ru', 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1575710943), 
('dogpile.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1576315416), 
('google.com.', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1577670576), 
('andira.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579028684), 
('noctidiurnal.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579028924), 
('tigress.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579030084), 
('interaffiliation.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579032390), 
('monodic.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579037806), 
('undecayed.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579038255), 
('santalin.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579047075), 
('go.mail.ru', 9, 3, 3, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1596572226), 
('unbibulous.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579842619), 
('sorbonical.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579842619), 
('leaky.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579842997), 
('greasehorn.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579843675), 
('voidee.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579850779), 
('chaetetidae.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579850821), 
('orabassu.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579851368), 
('parallelization.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579857432), 
('smashery.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1579858055), 
('promoderationist.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580108026), 
('interrogator.best', 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580116286), 
('exogeny.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580114859), 
('anonang.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580117255), 
('mamie.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580119588), 
('gossipry.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580119797), 
('yardage.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580120846), 
('testudinous.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580121416), 
('monocyclic.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580122680), 
('irreprehensibly.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580367379), 
('kinematograph.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580367631), 
('deceptiveness.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580368206), 
('misdemean.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580370601), 
('charadrine.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580372072), 
('uteritis.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580373084), 
('lateener.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580373130), 
('claustral.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580374311), 
('toccata.best', 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580374557), 
('holoptychiidae.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580895504), 
('cabinda.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580896023), 
('sociably.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580897446), 
('calabrese.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580899353), 
('undramatized.best', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582196511), 
('isethionate.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1580904371), 
('every-lang-seo.com', 4, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582448323), 
('suberize.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581351780), 
('canalization.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581355283), 
('niterbush.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581355322), 
('covassal.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581356269), 
('donought.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581357414), 
('reflexological.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581359652), 
('pulu.best', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581363431), 
('unsuperficial.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581363058), 
('linear.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581363144), 
('iodizer.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581365035), 
('ultracentenarianism.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581368342), 
('counterermine.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581369110), 
('exoner.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581371559), 
('skunkery.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581372555), 
('synartesis.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581372989), 
('chooser.best', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582198041), 
('exactingness.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581374302), 
('unawares.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581376384), 
('unfight.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581378506), 
('nonsacrifice.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581379203), 
('bridgetsimon.top', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1581806018), 
('sulphamino.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582196892), 
('chirping.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582217652), 
('churchiness.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582218441), 
('heeder.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582218509), 
('tinning.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582334411), 
('camorra.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582334638), 
('rhinthonica.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582334700), 
('dobbin.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582335734), 
('ganocephalan.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582336244), 
('pharyngognathous.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582336577), 
('didactician.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582338116), 
('pseudoprofessorial.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582338329), 
('predatoriness.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582339406), 
('warmthless.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582339934), 
('cheilitis.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582340442), 
('molala.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582340908), 
('ruralization.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582341471), 
('ungroomed.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582341965), 
('gastroduodenotomy.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582344187), 
('anemobiagraph.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582346727), 
('otocranial.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582347596), 
('toll.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582349569), 
('surrejoin.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582350933), 
('convocationist.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582352922), 
('wizen.best', 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582404187), 
('houtou.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582355048), 
('garawi.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582357080), 
('birdhouse.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582358385), 
('prosecution.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582359639), 
('cetomorpha.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582360475), 
('quintuplicate.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582360560), 
('scenical.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582361732), 
('tantafflin.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582399875), 
('fiddleheaded.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582400668), 
('wheedle.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582402702), 
('underhorsed.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582405758), 
('immaturely.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582406870), 
('preinfect.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582407635), 
('unmad.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582408044), 
('theraphosidae.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582408506), 
('pseudovolcanic.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582409466), 
('tripodial.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582413409), 
('longicaudal.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582416453), 
('sagy.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582416537), 
('predicament.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582417799), 
('tricksily.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582420653), 
('nonprelatical.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582421689), 
('rutile.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582426392), 
('dampang.best', 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1582427294), 
('mapolas.com', 15, 0, 0, 3, 6, 1, 3, 2, 0, 0, 0, 0, 0, 1594720843), 
('anti-crisis-seo.com', 389, 0, 0, 83, 103, 84, 62, 46, 11, 0, 0, 0, 0, 1596636800), 
('raymark.ru', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1586371998), 
('ecar.az', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1586460320), 
('publichnaya-kadastrovaja-karta.ru', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1586516946), 
('xxxsiterips.xyz', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586165884), 
('cabinet-gosuslugi.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586181735), 
('vulkan-avtomatu.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586196313), 
('olimp-sp.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586196313), 
('goldsoch.info', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586196313), 
('playbox.life', 5, 0, 0, 0, 1, 4, 0, 0, 0, 0, 0, 0, 0, 1589218658), 
('cryptomixer.tech', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586211246), 
('avxdl.site', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1586263865), 
('xn----7sbafcvrd1a5e1e.xn--80adxhks', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1587442484), 
('karavan.az', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1586967813), 
('home-task.com', 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1586967339), 
('erotag.com', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1589194242), 
('stopnarco.ru', 4, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 1586967339), 
('pizdeishn.net', 6, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1588155715), 
('villa-krym.ru', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1587813815), 
('ma.ut.edu.vn', 3, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1590818065), 
('osvita.ukr-lit.com', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1589487955), 
('school-essay.ru', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1586902436), 
('xn--74-jlcepmffs7i6a.xn--p1ai', 4, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 0, 1589932400), 
('avrora-pansion.ru', 6, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0, 0, 0, 1589653803), 
('volcable.ru', 8, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0, 0, 0, 1590302890), 
('krandiagnostika.ru', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1587166583), 
('stavkaprava.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1587237783), 
('tvory.predmety.in.ua', 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 1588164429), 
('pokerdoms-play.ru', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1587363874), 
('dezgorkontrol.ru', 10, 0, 0, 0, 4, 6, 0, 0, 0, 0, 0, 0, 0, 1588626065), 
('en.home-task.com', 6, 0, 0, 0, 2, 4, 0, 0, 0, 0, 0, 0, 0, 1590203151), 
('poesia-portuguesa.com', 3, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 1590220958), 
('schoolessay.ru', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1587460656), 
('virus-schutzmasken.de', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1587471321), 
('glassdeskguide.com', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1587494346), 
('vulkan-platinym24.ru', 5, 0, 0, 0, 1, 4, 0, 0, 0, 0, 0, 0, 0, 1589309882), 
('jp.painting-planet.com', 3, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 1588016341), 
('poesia-espanola.com', 5, 0, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 1589935190), 
('vk.com', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1590670661), 
('biographiya.com', 11, 0, 0, 0, 1, 9, 1, 0, 0, 0, 0, 0, 0, 1591686629), 
('xxxffile.com', 9, 0, 0, 0, 1, 3, 4, 1, 0, 0, 0, 0, 0, 1593832430), 
('bitcoins.menu', 7, 0, 0, 0, 1, 6, 0, 0, 0, 0, 0, 0, 0, 1590838835), 
('trances77.nl', 2, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1588561317), 
('agriculture.sel-hoz.com', 4, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 1589537409), 
('vulkan-klyb.ru', 20, 0, 0, 0, 3, 17, 0, 0, 0, 0, 0, 0, 0, 1590714540), 
('weblibrary.win', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1588097566), 
('web-analytics.date', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1588106934), 
('zonefiles.bid', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1588109503), 
('certifywebsite.win', 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1588112199), 
('jyvopys.com', 9, 0, 0, 0, 2, 7, 0, 0, 0, 0, 0, 0, 0, 1590734104), 
('sexjk.com', 5, 0, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 0, 1590515517), 
('brendof-club.com', 3, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1591915524), 
('paintingplanet.ru', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1588398721), 
('1win-in.ru', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1588549851), 
('7ooo.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1588673554), 
('ukrtvir.com.ua', 5, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 1589738948), 
('turk-siiri.com', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1590743808), 
('fable.in.ua', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1588891713), 
('javstock.com', 7, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 1590289206), 
('kartiny.rus-lit.com', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1589407484), 
('smolray.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1589202310), 
('apbb.ru', 10, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 1590569060), 
('pinup-ok.ru', 8, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 1590128811), 
('servisural.ru', 4, 0, 0, 0, 0, 1, 3, 0, 0, 0, 0, 0, 0, 1593259639), 
('bdjola.com', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1590386267), 
('art.goldsoch.info', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1589735474), 
('zagadki.in.ua', 4, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 1590392751), 
('javlibrary.site', 3, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1590718893), 
('javidol.site', 5, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 1591144329), 
('pt.sel-hoz.com', 4, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 1591059975), 
('vinodelie-online.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1590360975), 
('javxxx18.com', 5, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 1591552980), 
('landofgames.ru', 7, 0, 0, 0, 0, 5, 2, 0, 0, 0, 0, 0, 0, 1592961926), 
('pro-skazki.ru', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1590386352), 
('xn-----6kccaibs5cb8afhjrfmix2n.xn--p1ai', 5, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 0, 1591613438), 
('mp3ka.net', 9, 0, 0, 0, 0, 2, 7, 0, 0, 0, 0, 0, 0, 1593186539), 
('builtwith.com', 2, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1589970636), 
('hacron.ru', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1589998396), 
('se.painting-planet.com', 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1590253531), 
('ukrainian-poetry.com', 3, 0, 0, 0, 0, 1, 0, 2, 0, 0, 0, 0, 0, 1594260236), 
('vsdelke.ru', 7, 0, 0, 0, 0, 3, 4, 0, 0, 0, 0, 0, 0, 1592550306), 
('inten-group.ru', 3, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0, 0, 0, 1595377240), 
('engpoetry.com', 9, 0, 0, 0, 0, 2, 7, 0, 0, 0, 0, 0, 0, 1593058032), 
('youtube.com', 4, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 1593472277), 
('russian-poetry.com', 5, 0, 0, 0, 0, 0, 4, 1, 0, 0, 0, 0, 0, 1593641192), 
('moscow.dengi-pod-zalog-nedvizhimosti.ru', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1591951892), 
('zajm-zalog-krasnodar.ru', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1591247075), 
('xn--80aagddcgkbcqbad7amllnejg6dya.xn--p1ai', 3, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 1594289966), 
('jobgirl24.ru', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1591373121), 
('rulate.ru', 5, 0, 0, 0, 0, 0, 3, 2, 0, 0, 0, 0, 0, 1595635360), 
('sauna-v-ufe.ru', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1593011844), 
('narkomaniya-net.ru', 10, 0, 0, 0, 0, 0, 9, 1, 0, 0, 0, 0, 0, 1593686450), 
('c1helper.com', 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1592454121), 
('bankhelp.org', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1592674289), 
('mangani.ru', 8, 0, 0, 0, 0, 0, 4, 4, 0, 0, 0, 0, 0, 1594157198), 
('dverimegapolis.ru', 8, 0, 0, 0, 0, 0, 7, 1, 0, 0, 0, 0, 0, 1595005106), 
('tinyurl.com', 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1592078532), 
('vanishingveggie.com', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1592434719), 
('rental-power.com.ua', 3, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 1595454467), 
('depression.su', 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 1592494523), 
('modelnayaosnastka.ru', 8, 0, 0, 0, 0, 0, 5, 3, 0, 0, 0, 0, 0, 1593914356), 
('analytics.google.com', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1592397032), 
('zaim-pod-zalog-krasnodar.ru', 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1592615208), 
('akt-skrytyx-rabot.ru', 3, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 1593341040), 
('sexpornotales.org', 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1594455741), 
('vietnam-ship-chandler.com', 3, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 1596612702), 
('vietnamshipchandler.com.vn', 4, 0, 0, 0, 0, 0, 0, 3, 1, 0, 0, 0, 0, 1596328726), 
('ventactive.ru', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1593801868), 
('pozdrawleniya.ru', 3, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 1595844707), 
('gfaq.ru', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1594075289), 
('fresh-casino24.ru', 5, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 1595454469), 
('pansionat-kyiv.com.ua', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1594374249), 
('espanaherb.com', 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1594740077), 
('pandastatus.ru', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1595165338), 
('onlinevocal.pro', 2, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 1595367892), 
('prismlightinggroup.com', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1595330381), 
('detmed.info', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1595854416), 
('mosrif.ru', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1596254869), 
('cherms.website', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1596684698);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_searchkeys`
--

DROP TABLE IF EXISTS `nv4_en_searchkeys`;
CREATE TABLE `nv4_en_searchkeys` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `skey` varchar(255) NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50) NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_siteterms`
--

DROP TABLE IF EXISTS `nv4_en_siteterms`;
CREATE TABLE `nv4_en_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT '',
  `imagealt` varchar(255) DEFAULT '',
  `description` text,
  `bodytext` mediumtext NOT NULL,
  `keywords` text,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255) DEFAULT '',
  `layout_func` varchar(100) DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_siteterms`
--

INSERT INTO `nv4_en_siteterms` VALUES
(1, 'Terms & Conditions', 'Terms-Conditions', '', '', '', '<h2><strong>Term no</strong><strong> 1: Collect information</strong></h2><strong>1.1. Collecting information automatically.</strong><br  />Like the other modern websites, Websites will collect IP address and some information of the standard website like: browser, pages that you access to websites for process using services by desktop, laptop, computer and network devices, etc. It aims to analyze information for privacy and keeping safe mode the system.<br  /><strong>1.2. Collecting your information through an account.</strong><br  />All information of your account (creating a new account, contacting to us, and so on) will be stored in profile for caring customer services later.<br  /><strong>1.3. Collecting information through setting up cookies.</strong><br  />Like the other modern websites, when you access to websites, we (or monitoring tools; or the statistics of website activities that provided by partners ) will create some profiles that named Cookies on hard-disk or memory of your computer. One of some Cookies may be exist with the long time to become convenient process using. For example, saving your email in login page to avoid login again, ect.<br  /><strong>1.4. Collecting and storing information in the last.</strong><h3>You can change the private information any time, however, we will save in all information that changed to prevent the erase traces of illegal activities.</h3><h2><br  /><strong>Term no</strong><strong> 2: Storing and protecting information.</strong></h2>Almost collected information will be stored in us database system.<br  />We protect personal information by using some tools as password, firewall, encryption, and with some other tools that is license for accessing and suitable for data management process. For example, you and staffs must be responsibility for information processing through identifying steps in private information.<h2><br  /><strong>Term no</strong><strong> 3: Using information</strong></h2>Collected information will be used to:<ul>	<li>Supplying support services &amp; customer care.</li>	<li>Transaction payment and Payment Notifications will send when a new payment is created</li>	<li>Handling complaints, charges &amp; Troubleshooting.</li>	<li>Stopping any forbidden or illegal act and must guarantee to follow the policies in &quot;User agreement”</li>	<li><a name=\"_GoBack\"></a> Measurement, upgrading &amp; improving services, content and form of the website.</li>	<li>Sending information to user about Marketing&#039;s Programs, announcements and promotional programs.</li>	<li>Comparison of the accuracy of your personal information in the process of checking with third parties.</li></ul><h2><br  /><strong>Term no 4: Receiving information from partners</strong></h2>When using payment and transactions tools via the internet, we can receive more information about you such as your username address, email, bank account number ... We check that information with our user database to confirm whether you are the customer of us or not in order to enable the implementation of the service is convenient for you.<br  />The received information will be secured as the information that we collected directly from you.<h2><br  /><strong>Term no 5: Sharing information with the third party</strong></h2>We will not share your personal information, financial information... for the 3rd party, unless we have your consent or when we are forced to comply with the law or in case of having the requests from government agencies having jurisdiction.<h2><br  /><strong>Term no 6: Changing the privacy policy</strong></h2>This Privacy Policy may change from time to time. We will not reduce your rights under this Privacy Policy without your explicit consent. We will post any changes to this Privacy Policy on this website and if the changes are significant, we will provide a more prominent notice (including information email message about the change of the Privacy Policy for certain services).<br  /><br  />&nbsp;<div style=\"text-align: right;\">Tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a><br />&nbsp;</div>', '', 0, '4', '', 0, 1, 1, 1439973638, 1439973638, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_siteterms_config`
--

DROP TABLE IF EXISTS `nv4_en_siteterms_config`;
CREATE TABLE `nv4_en_siteterms_config` (
  `config_name` varchar(30) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_siteterms_config`
--

INSERT INTO `nv4_en_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_1`
--

DROP TABLE IF EXISTS `nv4_en_slider_1`;
CREATE TABLE `nv4_en_slider_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `admin_id` (`admin_id`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=36  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_slider_1`
--

INSERT INTO `nv4_en_slider_1` VALUES
(1, 1, '1', 1, 1439987696, 1443519093, 1, 1439987696, 0, 2, 'banner-1', '', '', '2015_09/vietnam-ship-supply-banner-1.jpg', 1, 0), 
(2, 1, '1', 1, 1439987728, 1443519108, 1, 1439987728, 0, 2, 'banner-2', '', '', '2015_09/vietnam-ship-supply-banner-2.jpg', 1, 0), 
(3, 1, '1', 1, 1439987744, 1443519127, 1, 1439987744, 0, 2, 'banner-3', '', '', '2015_09/vietnam-ship-supply-banner-3.jpg', 1, 0), 
(4, 1, '1', 1, 1439987759, 1443519144, 1, 1439987759, 0, 2, 'banner-4', '', '', '2015_09/vietnam-ship-supply-banner-5.jpg', 1, 0), 
(5, 1, '1', 1, 1439987778, 1443519155, 1, 1439987778, 0, 2, 'banner-5', '', '', '2015_09/vietnam-ship-supply-banner-4.jpg', 1, 0), 
(12, 1, '1', 2, 1440945047, 1443519167, 1, 1440945047, 0, 2, 'banner-6', '', '', '2015_09/vietnam-ship-supply-banner-6.jpg', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_2`
--

DROP TABLE IF EXISTS `nv4_en_slider_2`;
CREATE TABLE `nv4_en_slider_2` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `admin_id` (`admin_id`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=33  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_slider_2`
--

INSERT INTO `nv4_en_slider_2` VALUES
(6, 2, '2', 1, 1439995531, 1440951060, 1, 1439995531, 0, 2, 'logo-brands-1', '', '', '2015_08/blue-ocean-logo-1.jpg', 1, 0), 
(7, 2, '2', 1, 1439995547, 1440951080, 1, 1439995547, 0, 2, 'logo-brands-2', '', '', '2015_08/blue-ocean-logo-2.jpg', 1, 0), 
(8, 2, '2', 1, 1439995558, 1440951098, 1, 1439995558, 0, 2, 'logo-brands-3', '', '', '2015_08/blue-ocean-logo-3.jpg', 1, 0), 
(9, 2, '2', 1, 1439995569, 1440951121, 1, 1439995569, 0, 2, 'logo-brands-4', '', '', '2015_08/blue-ocean-logo-4.jpg', 1, 0), 
(10, 2, '2', 1, 1439995581, 1440951138, 1, 1439995581, 0, 2, 'logo-brands-5', '', '', '2015_08/blue-ocean-logo-5.jpg', 1, 0), 
(11, 2, '2', 1, 1439995594, 1440951160, 1, 1439995594, 0, 2, 'logo-brands-6', '', '', '2015_08/blue-ocean-logo-6.jpg', 1, 0), 
(14, 2, '2', 2, 1440951180, 1440951180, 1, 1440951180, 0, 2, 'logo-brands-7', '', '', '2015_08/blue-ocean-logo-7.jpg', 1, 0), 
(15, 2, '2', 2, 1440951269, 1440951269, 1, 1440951269, 0, 2, 'logo-brands-8', '', '', '2015_08/blue-ocean-logo-8.jpg', 1, 0), 
(16, 2, '2', 2, 1440951295, 1440951295, 1, 1440951295, 0, 2, 'logo-brands-9', '', '', '2015_08/blue-ocean-logo-9.jpg', 1, 0), 
(17, 2, '2', 2, 1440951317, 1440951317, 1, 1440951317, 0, 2, 'logo-brands-10', '', '', '2015_08/blue-ocean-logo-10.jpg', 1, 0), 
(18, 2, '2', 2, 1440951343, 1440951343, 1, 1440951343, 0, 2, 'logo-brands-11', '', '', '2015_08/blue-ocean-logo-11.jpg', 1, 0), 
(19, 2, '2', 2, 1440951366, 1440951366, 1, 1440951366, 0, 2, 'logo-brands-12', '', '', '2015_08/blue-ocean-logo-12.jpg', 1, 0), 
(20, 2, '2', 2, 1440954107, 1440954107, 1, 1440954107, 0, 2, 'logo-brands-13', '', '', '2015_08/blue-ocean-logo-13.jpg', 1, 0), 
(21, 2, '2', 2, 1440954200, 1440954200, 1, 1440954200, 0, 2, 'logo-brands-14', '', '', '2015_08/blue-ocean-logo-14.jpg', 1, 0), 
(22, 2, '2', 2, 1440954238, 1440954238, 1, 1440954238, 0, 2, 'logo-brands-15', '', '', '2015_08/blue-ocean-logo-15.jpg', 1, 0), 
(23, 2, '2', 2, 1440954245, 1440954245, 1, 1440954245, 0, 2, 'logo-brands-16', '', '', '2015_08/blue-ocean-logo-16.jpg', 1, 0), 
(24, 2, '2', 2, 1440954252, 1440954252, 1, 1440954252, 0, 2, 'logo-brands-17', '', '', '2015_08/blue-ocean-logo-17.jpg', 1, 0), 
(25, 2, '2', 2, 1440954260, 1440954260, 1, 1440954260, 0, 2, 'logo-brands-18', '', '', '2015_08/blue-ocean-logo-18.jpg', 1, 0), 
(26, 2, '2', 2, 1440954267, 1440954267, 1, 1440954267, 0, 2, 'logo-brands-19', '', '', '2015_08/blue-ocean-logo-19.jpg', 1, 0), 
(27, 2, '2', 2, 1440954289, 1440954289, 1, 1440954289, 0, 2, 'logo-brands-20', '', '', '2015_08/blue-ocean-logo-20.jpg', 1, 0), 
(28, 2, '2', 2, 1440954295, 1440954295, 1, 1440954295, 0, 2, 'logo-brands-21', '', '', '2015_08/blue-ocean-logo-21.jpg', 1, 0), 
(29, 2, '2', 2, 1440954301, 1440954301, 1, 1440954301, 0, 2, 'logo-brands-22', '', '', '2015_08/blue-ocean-logo-22.jpg', 1, 0), 
(30, 2, '2', 2, 1440954307, 1440954307, 1, 1440954307, 0, 2, 'logo-brands-23', '', '', '2015_08/blue-ocean-logo-23.jpg', 1, 0), 
(31, 2, '2', 2, 1440954316, 1440954316, 1, 1440954316, 0, 2, 'logo-brands-24', '', '', '2015_08/blue-ocean-logo-24.jpg', 1, 0), 
(32, 2, '2', 2, 1440954323, 1440954323, 1, 1440954323, 0, 2, 'logo-brands-25', '', '', '2015_08/blue-ocean-logo-25.jpg', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_admins`
--

DROP TABLE IF EXISTS `nv4_en_slider_admins`;
CREATE TABLE `nv4_en_slider_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_cat`
--

DROP TABLE IF EXISTS `nv4_en_slider_cat`;
CREATE TABLE `nv4_en_slider_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_slider_cat`
--

INSERT INTO `nv4_en_slider_cat` VALUES
(1, 0, 'Banner', 'Banner', 1, 1, 0, 'viewcat_page_new', 0, '', 1, '', 1439987593, 1439987593, '6'), 
(2, 0, 'Đối tác', 'Doi-tac', 2, 2, 0, 'viewcat_page_new', 0, '', 1, '', 1439995468, 1439995468, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_config_post`
--

DROP TABLE IF EXISTS `nv4_en_slider_config_post`;
CREATE TABLE `nv4_en_slider_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_slider_config_post`
--

INSERT INTO `nv4_en_slider_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(5, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_slider_rows`
--

DROP TABLE IF EXISTS `nv4_en_slider_rows`;
CREATE TABLE `nv4_en_slider_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `admin_id` (`admin_id`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=36  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_slider_rows`
--

INSERT INTO `nv4_en_slider_rows` VALUES
(1, 1, '1', 1, 1439987696, 1443519093, 1, 1439987696, 0, 2, 'banner-1', '', '', '2015_09/vietnam-ship-supply-banner-1.jpg', 1, 0), 
(2, 1, '1', 1, 1439987728, 1443519108, 1, 1439987728, 0, 2, 'banner-2', '', '', '2015_09/vietnam-ship-supply-banner-2.jpg', 1, 0), 
(3, 1, '1', 1, 1439987744, 1443519127, 1, 1439987744, 0, 2, 'banner-3', '', '', '2015_09/vietnam-ship-supply-banner-3.jpg', 1, 0), 
(4, 1, '1', 1, 1439987759, 1443519144, 1, 1439987759, 0, 2, 'banner-4', '', '', '2015_09/vietnam-ship-supply-banner-5.jpg', 1, 0), 
(5, 1, '1', 1, 1439987778, 1443519155, 1, 1439987778, 0, 2, 'banner-5', '', '', '2015_09/vietnam-ship-supply-banner-4.jpg', 1, 0), 
(6, 2, '2', 1, 1439995531, 1440951060, 1, 1439995531, 0, 2, 'logo-brands-1', '', '', '2015_08/blue-ocean-logo-1.jpg', 1, 0), 
(7, 2, '2', 1, 1439995547, 1440951080, 1, 1439995547, 0, 2, 'logo-brands-2', '', '', '2015_08/blue-ocean-logo-2.jpg', 1, 0), 
(8, 2, '2', 1, 1439995558, 1440951098, 1, 1439995558, 0, 2, 'logo-brands-3', '', '', '2015_08/blue-ocean-logo-3.jpg', 1, 0), 
(9, 2, '2', 1, 1439995569, 1440951121, 1, 1439995569, 0, 2, 'logo-brands-4', '', '', '2015_08/blue-ocean-logo-4.jpg', 1, 0), 
(10, 2, '2', 1, 1439995581, 1440951138, 1, 1439995581, 0, 2, 'logo-brands-5', '', '', '2015_08/blue-ocean-logo-5.jpg', 1, 0), 
(11, 2, '2', 1, 1439995594, 1440951160, 1, 1439995594, 0, 2, 'logo-brands-6', '', '', '2015_08/blue-ocean-logo-6.jpg', 1, 0), 
(12, 1, '1', 2, 1440945047, 1443519167, 1, 1440945047, 0, 2, 'banner-6', '', '', '2015_09/vietnam-ship-supply-banner-6.jpg', 1, 0), 
(14, 2, '2', 2, 1440951180, 1440951180, 1, 1440951180, 0, 2, 'logo-brands-7', '', '', '2015_08/blue-ocean-logo-7.jpg', 1, 0), 
(15, 2, '2', 2, 1440951269, 1440951269, 1, 1440951269, 0, 2, 'logo-brands-8', '', '', '2015_08/blue-ocean-logo-8.jpg', 1, 0), 
(16, 2, '2', 2, 1440951295, 1440951295, 1, 1440951295, 0, 2, 'logo-brands-9', '', '', '2015_08/blue-ocean-logo-9.jpg', 1, 0), 
(17, 2, '2', 2, 1440951317, 1440951317, 1, 1440951317, 0, 2, 'logo-brands-10', '', '', '2015_08/blue-ocean-logo-10.jpg', 1, 0), 
(18, 2, '2', 2, 1440951343, 1440951343, 1, 1440951343, 0, 2, 'logo-brands-11', '', '', '2015_08/blue-ocean-logo-11.jpg', 1, 0), 
(19, 2, '2', 2, 1440951366, 1440951366, 1, 1440951366, 0, 2, 'logo-brands-12', '', '', '2015_08/blue-ocean-logo-12.jpg', 1, 0), 
(20, 2, '2', 2, 1440954107, 1440954107, 1, 1440954107, 0, 2, 'logo-brands-13', '', '', '2015_08/blue-ocean-logo-13.jpg', 1, 0), 
(21, 2, '2', 2, 1440954200, 1440954200, 1, 1440954200, 0, 2, 'logo-brands-14', '', '', '2015_08/blue-ocean-logo-14.jpg', 1, 0), 
(22, 2, '2', 2, 1440954238, 1440954238, 1, 1440954238, 0, 2, 'logo-brands-15', '', '', '2015_08/blue-ocean-logo-15.jpg', 1, 0), 
(23, 2, '2', 2, 1440954245, 1440954245, 1, 1440954245, 0, 2, 'logo-brands-16', '', '', '2015_08/blue-ocean-logo-16.jpg', 1, 0), 
(24, 2, '2', 2, 1440954252, 1440954252, 1, 1440954252, 0, 2, 'logo-brands-17', '', '', '2015_08/blue-ocean-logo-17.jpg', 1, 0), 
(25, 2, '2', 2, 1440954260, 1440954260, 1, 1440954260, 0, 2, 'logo-brands-18', '', '', '2015_08/blue-ocean-logo-18.jpg', 1, 0), 
(26, 2, '2', 2, 1440954267, 1440954267, 1, 1440954267, 0, 2, 'logo-brands-19', '', '', '2015_08/blue-ocean-logo-19.jpg', 1, 0), 
(27, 2, '2', 2, 1440954289, 1440954289, 1, 1440954289, 0, 2, 'logo-brands-20', '', '', '2015_08/blue-ocean-logo-20.jpg', 1, 0), 
(28, 2, '2', 2, 1440954295, 1440954295, 1, 1440954295, 0, 2, 'logo-brands-21', '', '', '2015_08/blue-ocean-logo-21.jpg', 1, 0), 
(29, 2, '2', 2, 1440954301, 1440954301, 1, 1440954301, 0, 2, 'logo-brands-22', '', '', '2015_08/blue-ocean-logo-22.jpg', 1, 0), 
(30, 2, '2', 2, 1440954307, 1440954307, 1, 1440954307, 0, 2, 'logo-brands-23', '', '', '2015_08/blue-ocean-logo-23.jpg', 1, 0), 
(31, 2, '2', 2, 1440954316, 1440954316, 1, 1440954316, 0, 2, 'logo-brands-24', '', '', '2015_08/blue-ocean-logo-24.jpg', 1, 0), 
(32, 2, '2', 2, 1440954323, 1440954323, 1, 1440954323, 0, 2, 'logo-brands-25', '', '', '2015_08/blue-ocean-logo-25.jpg', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_1`
--

DROP TABLE IF EXISTS `nv4_en_supplies_1`;
CREATE TABLE `nv4_en_supplies_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=30  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_1`
--

INSERT INTO `nv4_en_supplies_1` VALUES
(16, 1, '1,7', 0, 2, '', 0, 1441353158, 1442977318, 6, 1441353060, 0, 2, 'Jis air pipe vent heads', 'jis-air-pipe-vent-heads', '', 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-1.jpg', '', 2, 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-2.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-3.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-4.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-5.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-6.jpg', 1, '4', 1, 24, 0, 0, 0), 
(18, 7, '1,7', 0, 2, '', 0, 1441353513, 1564822145, 1, 1442634600, 0, 2, 'Bridge Store', 'bridge', '', 'bridge/ship-supply-charts-publications-10.jpg', '', 1, 'bridge/ship-supply-charts-publications-9.jpg|bridge/ship-supply-charts-publications-7.jpg|bridge/ship-supply-charts-publications-6.jpg|bridge/ship-supply-charts-publications-8.jpg|bridge/ship-supply-charts-publications-1.jpg|bridge/ship-supply-charts-publications-5.jpg|bridge/ship-supply-charts-publications-3.jpg|bridge/ship-supply-charts-publications-4.jpg|bridge/ship-supply-charts-publications-2.jpg', 1, '4', 1, 3420, 0, 0, 0), 
(26, 7, '1,7', 0, 2, '', 0, 1442635112, 1564821924, 1, 1442634840, 0, 2, 'Cabin Store', 'cabin-stores', '', 'cabin-stores/ship-supply-cabin-stores-1.jpg', '', 1, 'cabin-stores/ship-supply-cabin-stores-2.jpg|cabin-stores/ship-supply-cabin-stores-3.jpg|cabin-stores/ship-supply-cabin-stores-4.jpg|cabin-stores/ship-supply-cabin-stores-5.jpg|cabin-stores/ship-supply-cabin-stores-6.jpg|cabin-stores/ship-supply-cabin-stores-7.jpg|cabin-stores/ship-supply-cabin-stores-8.jpg|cabin-stores/ship-supply-cabin-stores-9.jpg|cabin-stores/ship-supply-cabin-stores-10.jpg|cabin-stores/ship-supply-cabin-stores-11.jpg|cabin-stores/ship-supply-cabin-stores-12.jpg', 1, '4', 1, 3586, 0, 0, 0), 
(24, 7, '1,7', 0, 2, '', 0, 1442138730, 1564822359, 1, 1442634540, 0, 2, 'Galley Store', 'galley-stores', '', 'galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 1, 'galley-stores/ship-supply-cabin-and-galley-store-2.jpg|galley-stores/ship-supply-cabin-and-galley-store-3.jpg|galley-stores/ship-supply-cabin-and-galley-store-4.jpg|galley-stores/ship-supply-cabin-and-galley-store-5.jpg|galley-stores/ship-supply-cabin-and-galley-store-6.jpg|galley-stores/ship-supply-cabin-and-galley-store-7.jpg|galley-stores/ship-supply-cabin-and-galley-store-8.jpg|galley-stores/ship-supply-cabin-and-galley-store-9.jpg|galley-stores/ship-supply-cabin-and-galley-store-10.jpg|galley-stores/ship-supply-cabin-and-galley-store-11.jpg|galley-stores/ship-supply-cabin-and-galley-store-12.jpg|galley-stores/ship-supply-cabin-and-galley-store-13.jpg|galley-stores/ship-supply-cabin-and-galley-store-14.jpg|galley-stores/ship-supply-cabin-and-galley-store-15.jpg|galley-stores/ship-supply-cabin-and-galley-store-16.jpg', 1, '4', 1, 3576, 0, 0, 0), 
(27, 7, '1,7', 0, 2, '', 0, 1442635584, 1564822525, 1, 1442634420, 0, 2, 'Deck Store', 'deck-stores', '', 'deck-stores/ship-supply-deck-stores-2.jpg', 'ship supply deck stores &#40;2&#41;', 1, 'deck-stores/ship-supply-deck-stores-3.jpg|deck-stores/ship-supply-deck-stores-4.jpg|deck-stores/ship-supply-deck-stores-5.jpg|deck-stores/ship-supply-deck-stores-6.jpg|deck-stores/ship-supply-deck-stores-7.jpg|deck-stores/ship-supply-deck-stores-8.jpg|deck-stores/ship-supply-deck-stores-9.jpg|deck-stores/ship-supply-deck-stores-10.jpg|deck-stores/ship-supply-deck-stores-11.jpg|deck-stores/ship-supply-deck-stores-12.jpg|deck-stores/ship-supply-deck-stores-13.jpg|deck-stores/ship-supply-deck-stores-14.jpg|deck-stores/ship-supply-deck-stores-15.jpg|deck-stores/ship-supply-deck-stores-16.jpg|deck-stores/ship-supply-deck-stores-17.jpg|deck-stores/ship-supply-deck-stores-18.jpg|deck-stores/ship-supply-deck-stores-19.jpg|deck-stores/ship-supply-deck-stores-20.jpg|deck-stores/ship-supply-deck-stores-21.jpg|deck-stores/ship-supply-deck-stores-22.jpg|deck-stores/ship-supply-deck-stores-23.jpg', 1, '4', 1, 3652, 0, 0, 0), 
(20, 7, '1,7', 0, 2, '', 0, 1441353895, 1564822620, 1, 1442634000, 0, 2, 'Paints &amp; Chemicals Store', 'marine-paints-chemicals', '', 'marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', 'ship supply paints chemicals &#40;1&#41;', 1, 'marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', 1, '4', 1, 4277, 0, 0, 0), 
(17, 7, '1,7', 0, 2, '', 0, 1441353381, 1564822845, 1, 1442633700, 0, 2, 'Safety &amp; Anti-Piracy Store', 'safety-stores-anti-piracy-items', '', 'safety-stores/ship-supply-safety-equipment-1.jpg', 'ship supply safety equipment &#40;1&#41;', 1, 'safety-stores/ship-supply-safety-equipment-2.jpg|safety-stores/ship-supply-safety-equipment-3.jpg|safety-stores/ship-supply-safety-equipment-4.jpg|safety-stores/ship-supply-safety-equipment-5.jpg|safety-stores/ship-supply-safety-equipment-6.jpg|safety-stores/ship-supply-safety-equipment-7.jpg|safety-stores/ship-supply-safety-equipment-8.jpg|safety-stores/ship-supply-safety-equipment-9.jpg|safety-stores/ship-supply-safety-equipment-10.jpg|safety-stores/ship-supply-safety-equipment-11.jpg|safety-stores/ship-supply-safety-equipment-12.jpg|safety-stores/ship-supply-safety-equipment-13.jpg|safety-stores/ship-supply-safety-equipment-14.jpg|safety-stores/ship-supply-safety-equipment-15.jpg', 1, '4', 1, 3450, 0, 0, 0), 
(13, 7, '1,7', 0, 2, '', 0, 1441352419, 1564822923, 1, 1442633400, 0, 2, 'Electrics Store', 'electrical-stores', '', 'electrical-stores/ship-supply-electrical-stores-1.jpg', 'ship supply electrical stores &#40;2&#41;', 1, 'electrical-stores/ship-supply-electrical-stores-2.jpg|electrical-stores/ship-supply-electrical-stores-3.jpg|electrical-stores/ship-supply-electrical-stores-4.jpg|electrical-stores/ship-supply-electrical-stores-5.jpg|electrical-stores/ship-supply-electrical-stores-6.jpg|electrical-stores/ship-supply-electrical-stores-7.jpg|electrical-stores/ship-supply-electrical-stores-8.jpg|electrical-stores/ship-supply-electrical-stores-9.jpg|electrical-stores/ship-supply-electrical-stores-10.jpg|electrical-stores/ship-supply-electrical-stores-11.jpg|electrical-stores/ship-supply-electrical-stores-12.jpg|electrical-stores/ship-supply-electrical-stores-13.jpg|electrical-stores/ship-supply-electrical-stores-14.jpg|electrical-stores/ship-supply-electrical-stores-15.jpg', 1, '4', 1, 3459, 0, 0, 0), 
(25, 7, '1,7', 0, 2, '', 0, 1442552579, 1564823028, 1, 1442552280, 0, 2, 'Engine Store', 'engine-stores', '', 'engine-stores/ship-supply-engineer-store-1.jpg', '', 1, 'engine-stores/ship-supply-engineer-store-2.jpg|engine-stores/ship-supply-engineer-store-3.jpg|engine-stores/ship-supply-engineer-store-4.jpg|engine-stores/ship-supply-engineer-store-5.jpg|engine-stores/ship-supply-engineer-store-6.jpg|engine-stores/ship-supply-engineer-store-7.jpg|engine-stores/ship-supply-engineer-store-8.jpg|engine-stores/ship-supply-engineer-store-9.jpg|engine-stores/ship-supply-engineer-store-11.jpg|engine-stores/ship-supply-engineer-store-12.jpg|engine-stores/ship-supply-engineer-store-13.jpg|engine-stores/ship-supply-engineer-store-14.jpg|engine-stores/ship-supply-engineer-store-15.jpg', 1, '4', 1, 3358, 0, 0, 0), 
(19, 7, '1,7', 0, 2, '', 0, 1441353649, 1442977304, 6, 1441353480, 0, 2, 'Oils - Lubricants', 'oils-lubricants', '', 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-1.jpg', '', 2, 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-2.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-3.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-4.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-5.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-6.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-7.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-8.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-9.jpg', 1, '4', 1, 28, 0, 0, 0), 
(28, 1, '1', 0, 2, '', 0, 1442636458, 1457755035, 1, 1442635800, 0, 2, 'Supply Provision', 'supplier', '', 'provision/ship-supply-provision-1.jpg', '', 1, 'provision/ship-supply-provision-2.jpg|provision/ship-supply-provision-3.jpg|provision/ship-supply-provision-4.jpg|provision/ship-supply-provision-5.jpg|provision/ship-supply-provision-6.jpg|provision/ship-supply-provision-7.jpg|provision/ship-supply-provision-8.jpg|provision/ship-supply-provision-9.jpg|provision/ship-supply-provision-10.jpg|provision/ship-supply-provision-11.jpg|provision/ship-supply-provision-12.jpg|provision/ship-supply-provision-13.jpg|provision/ship-supply-provision-14.jpg|provision/ship-supply-provision-15.jpg|provision/ship-supply-provision-16.jpg|provision/ship-supply-provision-17.jpg|provision/ship-supply-provision-18.jpg', 1, '4', 1, 2777, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_5`
--

DROP TABLE IF EXISTS `nv4_en_supplies_5`;
CREATE TABLE `nv4_en_supplies_5` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_5`
--

INSERT INTO `nv4_en_supplies_5` VALUES
(14, 5, '5', 0, 2, '', 0, 1441352664, 1442977328, 6, 1441352520, 0, 2, 'Rubber packing', 'rubber-packing', '', 'rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-1.jpg', '', 2, 'rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-2.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-3.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-4.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-5.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-6.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-7.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-8.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-9.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-10.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-11.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-12.jpg', 1, '4', 1, 33, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_6`
--

DROP TABLE IF EXISTS `nv4_en_supplies_6`;
CREATE TABLE `nv4_en_supplies_6` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_7`
--

DROP TABLE IF EXISTS `nv4_en_supplies_7`;
CREATE TABLE `nv4_en_supplies_7` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=29  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_7`
--

INSERT INTO `nv4_en_supplies_7` VALUES
(24, 7, '1,7', 0, 2, '', 0, 1442138730, 1564822359, 1, 1442634540, 0, 2, 'Galley Store', 'galley-stores', '', 'galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 1, 'galley-stores/ship-supply-cabin-and-galley-store-2.jpg|galley-stores/ship-supply-cabin-and-galley-store-3.jpg|galley-stores/ship-supply-cabin-and-galley-store-4.jpg|galley-stores/ship-supply-cabin-and-galley-store-5.jpg|galley-stores/ship-supply-cabin-and-galley-store-6.jpg|galley-stores/ship-supply-cabin-and-galley-store-7.jpg|galley-stores/ship-supply-cabin-and-galley-store-8.jpg|galley-stores/ship-supply-cabin-and-galley-store-9.jpg|galley-stores/ship-supply-cabin-and-galley-store-10.jpg|galley-stores/ship-supply-cabin-and-galley-store-11.jpg|galley-stores/ship-supply-cabin-and-galley-store-12.jpg|galley-stores/ship-supply-cabin-and-galley-store-13.jpg|galley-stores/ship-supply-cabin-and-galley-store-14.jpg|galley-stores/ship-supply-cabin-and-galley-store-15.jpg|galley-stores/ship-supply-cabin-and-galley-store-16.jpg', 1, '4', 1, 3576, 0, 0, 0), 
(27, 7, '1,7', 0, 2, '', 0, 1442635584, 1564822525, 1, 1442634420, 0, 2, 'Deck Store', 'deck-stores', '', 'deck-stores/ship-supply-deck-stores-2.jpg', 'ship supply deck stores &#40;2&#41;', 1, 'deck-stores/ship-supply-deck-stores-3.jpg|deck-stores/ship-supply-deck-stores-4.jpg|deck-stores/ship-supply-deck-stores-5.jpg|deck-stores/ship-supply-deck-stores-6.jpg|deck-stores/ship-supply-deck-stores-7.jpg|deck-stores/ship-supply-deck-stores-8.jpg|deck-stores/ship-supply-deck-stores-9.jpg|deck-stores/ship-supply-deck-stores-10.jpg|deck-stores/ship-supply-deck-stores-11.jpg|deck-stores/ship-supply-deck-stores-12.jpg|deck-stores/ship-supply-deck-stores-13.jpg|deck-stores/ship-supply-deck-stores-14.jpg|deck-stores/ship-supply-deck-stores-15.jpg|deck-stores/ship-supply-deck-stores-16.jpg|deck-stores/ship-supply-deck-stores-17.jpg|deck-stores/ship-supply-deck-stores-18.jpg|deck-stores/ship-supply-deck-stores-19.jpg|deck-stores/ship-supply-deck-stores-20.jpg|deck-stores/ship-supply-deck-stores-21.jpg|deck-stores/ship-supply-deck-stores-22.jpg|deck-stores/ship-supply-deck-stores-23.jpg', 1, '4', 1, 3652, 0, 0, 0), 
(25, 7, '1,7', 0, 2, '', 0, 1442552579, 1564823028, 1, 1442552280, 0, 2, 'Engine Store', 'engine-stores', '', 'engine-stores/ship-supply-engineer-store-1.jpg', '', 1, 'engine-stores/ship-supply-engineer-store-2.jpg|engine-stores/ship-supply-engineer-store-3.jpg|engine-stores/ship-supply-engineer-store-4.jpg|engine-stores/ship-supply-engineer-store-5.jpg|engine-stores/ship-supply-engineer-store-6.jpg|engine-stores/ship-supply-engineer-store-7.jpg|engine-stores/ship-supply-engineer-store-8.jpg|engine-stores/ship-supply-engineer-store-9.jpg|engine-stores/ship-supply-engineer-store-11.jpg|engine-stores/ship-supply-engineer-store-12.jpg|engine-stores/ship-supply-engineer-store-13.jpg|engine-stores/ship-supply-engineer-store-14.jpg|engine-stores/ship-supply-engineer-store-15.jpg', 1, '4', 1, 3358, 0, 0, 0), 
(20, 7, '1,7', 0, 2, '', 0, 1441353895, 1564822620, 1, 1442634000, 0, 2, 'Paints &amp; Chemicals Store', 'marine-paints-chemicals', '', 'marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', 'ship supply paints chemicals &#40;1&#41;', 1, 'marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', 1, '4', 1, 4277, 0, 0, 0), 
(19, 7, '1,7', 0, 2, '', 0, 1441353649, 1442977304, 6, 1441353480, 0, 2, 'Oils - Lubricants', 'oils-lubricants', '', 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-1.jpg', '', 2, 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-2.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-3.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-4.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-5.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-6.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-7.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-8.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-9.jpg', 1, '4', 1, 28, 0, 0, 0), 
(13, 7, '1,7', 0, 2, '', 0, 1441352419, 1564822923, 1, 1442633400, 0, 2, 'Electrics Store', 'electrical-stores', '', 'electrical-stores/ship-supply-electrical-stores-1.jpg', 'ship supply electrical stores &#40;2&#41;', 1, 'electrical-stores/ship-supply-electrical-stores-2.jpg|electrical-stores/ship-supply-electrical-stores-3.jpg|electrical-stores/ship-supply-electrical-stores-4.jpg|electrical-stores/ship-supply-electrical-stores-5.jpg|electrical-stores/ship-supply-electrical-stores-6.jpg|electrical-stores/ship-supply-electrical-stores-7.jpg|electrical-stores/ship-supply-electrical-stores-8.jpg|electrical-stores/ship-supply-electrical-stores-9.jpg|electrical-stores/ship-supply-electrical-stores-10.jpg|electrical-stores/ship-supply-electrical-stores-11.jpg|electrical-stores/ship-supply-electrical-stores-12.jpg|electrical-stores/ship-supply-electrical-stores-13.jpg|electrical-stores/ship-supply-electrical-stores-14.jpg|electrical-stores/ship-supply-electrical-stores-15.jpg', 1, '4', 1, 3459, 0, 0, 0), 
(17, 7, '1,7', 0, 2, '', 0, 1441353381, 1564822845, 1, 1442633700, 0, 2, 'Safety &amp; Anti-Piracy Store', 'safety-stores-anti-piracy-items', '', 'safety-stores/ship-supply-safety-equipment-1.jpg', 'ship supply safety equipment &#40;1&#41;', 1, 'safety-stores/ship-supply-safety-equipment-2.jpg|safety-stores/ship-supply-safety-equipment-3.jpg|safety-stores/ship-supply-safety-equipment-4.jpg|safety-stores/ship-supply-safety-equipment-5.jpg|safety-stores/ship-supply-safety-equipment-6.jpg|safety-stores/ship-supply-safety-equipment-7.jpg|safety-stores/ship-supply-safety-equipment-8.jpg|safety-stores/ship-supply-safety-equipment-9.jpg|safety-stores/ship-supply-safety-equipment-10.jpg|safety-stores/ship-supply-safety-equipment-11.jpg|safety-stores/ship-supply-safety-equipment-12.jpg|safety-stores/ship-supply-safety-equipment-13.jpg|safety-stores/ship-supply-safety-equipment-14.jpg|safety-stores/ship-supply-safety-equipment-15.jpg', 1, '4', 1, 3450, 0, 0, 0), 
(16, 1, '1,7', 0, 2, '', 0, 1441353158, 1442977318, 6, 1441353060, 0, 2, 'Jis air pipe vent heads', 'jis-air-pipe-vent-heads', '', 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-1.jpg', '', 2, 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-2.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-3.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-4.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-5.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-6.jpg', 1, '4', 1, 24, 0, 0, 0), 
(26, 7, '1,7', 0, 2, '', 0, 1442635112, 1564821924, 1, 1442634840, 0, 2, 'Cabin Store', 'cabin-stores', '', 'cabin-stores/ship-supply-cabin-stores-1.jpg', '', 1, 'cabin-stores/ship-supply-cabin-stores-2.jpg|cabin-stores/ship-supply-cabin-stores-3.jpg|cabin-stores/ship-supply-cabin-stores-4.jpg|cabin-stores/ship-supply-cabin-stores-5.jpg|cabin-stores/ship-supply-cabin-stores-6.jpg|cabin-stores/ship-supply-cabin-stores-7.jpg|cabin-stores/ship-supply-cabin-stores-8.jpg|cabin-stores/ship-supply-cabin-stores-9.jpg|cabin-stores/ship-supply-cabin-stores-10.jpg|cabin-stores/ship-supply-cabin-stores-11.jpg|cabin-stores/ship-supply-cabin-stores-12.jpg', 1, '4', 1, 3586, 0, 0, 0), 
(18, 7, '1,7', 0, 2, '', 0, 1441353513, 1564822145, 1, 1442634600, 0, 2, 'Bridge Store', 'bridge', '', 'bridge/ship-supply-charts-publications-10.jpg', '', 1, 'bridge/ship-supply-charts-publications-9.jpg|bridge/ship-supply-charts-publications-7.jpg|bridge/ship-supply-charts-publications-6.jpg|bridge/ship-supply-charts-publications-8.jpg|bridge/ship-supply-charts-publications-1.jpg|bridge/ship-supply-charts-publications-5.jpg|bridge/ship-supply-charts-publications-3.jpg|bridge/ship-supply-charts-publications-4.jpg|bridge/ship-supply-charts-publications-2.jpg', 1, '4', 1, 3420, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_admins`
--

DROP TABLE IF EXISTS `nv4_en_supplies_admins`;
CREATE TABLE `nv4_en_supplies_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_block`
--

DROP TABLE IF EXISTS `nv4_en_supplies_block`;
CREATE TABLE `nv4_en_supplies_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_block_cat`
--

DROP TABLE IF EXISTS `nv4_en_supplies_block_cat`;
CREATE TABLE `nv4_en_supplies_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_bodyhtml_1`
--

DROP TABLE IF EXISTS `nv4_en_supplies_bodyhtml_1`;
CREATE TABLE `nv4_en_supplies_bodyhtml_1` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext NOT NULL,
  `sourcetext` varchar(255) DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_bodyhtml_1`
--

INSERT INTO `nv4_en_supplies_bodyhtml_1` VALUES
(25, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply engineer store (1)\" src=\"/uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\"><p style=\"margin-bottom:6.75pt;line-height:normal\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">We provide </span></span><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">h</span><span style=\"color: rgb(51, 51, 51);\"><span style=\"font-family:arial,helvetica,sans-serif;\">o</span>ses, couplings, bearings, electrical &amp; hydraulic tools, hand &amp; cutting tools, steel &amp; metal items, lubricants &amp; cleaning products, packing &amp; jointing items and welding materials.</span></span></p></div></div>', '', 0, 0, 1, 1, 1, 0), 
(26, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply cabin stores 1\" src=\"/uploads/supplies/cabin-stores/ship-supply-cabin-stores-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\">We provide linens, beddings and a wide range of cleaning products. We also sell a variety of every-day items on request &nbsp;(e.g. TVs, shavers or shirts).<div><div><div id=\"_com_1\">&nbsp;</div></div></div></div></div>', '', 0, 0, 1, 1, 1, 0), 
(24, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply cabin and galley store (1)\" src=\"/uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\"><p style=\"margin-bottom:6.75pt;line-height:normal\"><span style=\"font-size:11.5pt;font-family:&#039;Roboto&#039;,serif;color:rgb(51, 51, 51);\"><span style=\"font-family:arial,helvetica,sans-serif;\">We sell various cleaning products, kitchen utensils, dishes and cutleries, bar items and buffet wares.</span></span></p></div></div>', '', 0, 0, 1, 1, 1, 0), 
(27, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply deck stores (2)\" src=\"/uploads/supplies/deck-stores/ship-supply-deck-stores-2.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">We deliver<span style=\"line-height: 107%;\"> lifting &amp; lashing equipment, wires ropes &amp; hawsers, anchors, chains, piping materials and tapes.</span></span></span></div></div>', '', 0, 0, 1, 1, 1, 0), 
(13, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply electrical stores 1\" src=\"/uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\"><p style=\"margin-bottom:6.75pt;line-height:normal\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">We sell l<span style=\"color: rgb(51, 51, 51);\">amps, cables and a variety of other spare parts.</span></span></span></p></div></div>', '', 0, 0, 1, 1, 1, 0), 
(14, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"blue ocean marine service ship supply rubber packing 1\" src=\"/uploads/our-business/rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom:15px\"><ul style=\"list-style: inherit;\">	<li style=\"margin-bottom: 2px; text-align: justify\">Water or oil resistance rubber packing (three skins or four skins);</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Oil resistance rubber packing (four skins);</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Straight angle joint;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Vertical angle joint;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Vertical angle joint;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Double folding angle joint;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">End pieces;</li></ul></div></div>', '', 0, 0, 1, 1, 1, 0), 
(16, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"blue ocean marine service ship supply jis air pipe vent heads 1\" src=\"/uploads/our-business/jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\">Air pipe heads and air vent heads are used for water, oil tank and air: fireproof and waterproof.</div></div>', '', 0, 0, 1, 1, 1, 0), 
(17, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply safety equipment (1)\" src=\"/uploads/supplies/safety-stores/ship-supply-safety-equipment-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom:15px\"><ul style=\"list-style: inherit;\">	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-family:; font-size: 11.5pt; font-style: normal; font-weight: 400; margin-bottom: 1.5pt;\"><span style=\"&#039;&#039;font-size:11.5pt;font-family:&#039;&amp;quot&#039;,serif; mso-fareast-font-family:&#039;Times New Roman&#039;;mso-bidi-font-family:&#039;Times New Roman&#039;; mso-fareast-language:EN-GB&#039;&#039;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Gas analysers</span></span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400; margin-bottom: 1.5pt;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Life buoys, life jackets andimmersion suits</span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400; margin-bottom: 1.5pt;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Fire hoses, fire extinguishers, fire-fighting suits</span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400; margin-bottom: 1.5pt;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Life rafts, rescue boats andemergency lights</span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Pilot and embarkation ladders</span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Oil sorbents</span></span></li>	<li style=\"text-align: justify; color: rgb(51, 51, 51); line-height: normal; font-size: 11.5pt; font-style: normal; font-weight: 400;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">Life jacket lights (approved by USCG, Lloyds’ Register, Russian Maritime Register)</span></span></li></ul></div></div>', '', 0, 0, 1, 1, 1, 0), 
(18, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply charts publications 10\" src=\"/uploads/supplies/bridge/ship-supply-charts-publications-10.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\"><span style=\"font-size:14px;\"><span style=\"font-family:arial,helvetica,sans-serif;\">We are selling <span style=\"color: rgb(51, 51, 51);\">BA charts &amp; publications as well as a wide range of stationery.</span></span></span><br  />&nbsp;</div></div>', '', 0, 0, 1, 1, 1, 0), 
(19, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"blue ocean marine service ship supply oils lubricants 1\" src=\"/uploads/our-business/oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 10px; text-align: justify;\">Profesional service and fast delivery of Shell oil, Neste, Castrol, Mobil, British Petroleum products to all ships.</div><div style=\"margin-bottom:15px\"><ul style=\"list-style: inherit;\">	<li style=\"margin-bottom: 2px; text-align: justify\">Antiseize assembly compounds;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Flaw &amp; Crack detector set;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Open gear lubricants;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Multi - purpose and liquid greases;</li>	<li style=\"margin-bottom: 2px; text-align: justify\">Insulators against corrosion &amp; rust.</li></ul></div></div>', '', 0, 0, 1, 1, 1, 0), 
(20, '<div class=\"col-xs-24 col-sm-12 col-md-12\"><figure class=\"image\" style=\"float:left\"><img alt=\"ship supply paints chemicals (1)\" src=\"/uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg\" style=\"width: 100%;\" /><figcaption></figcaption></figure></div><div class=\"col-xs-24 col-sm-12 col-md-12\"><div style=\"margin-bottom: 5px; text-align: justify;\"><p style=\"&#039;margin-bottom:3.75pt;text-align:justify;line-height:normal&#039;\"><span style=\"font-size:12px;\"><span style=\"font-family:arial,helvetica,sans-serif;\"><span style=\"color: rgb(51, 51, 51);\">We sell marine paints and coatings from Jotun, International, Hempel and Sigma (among others). Our main brands for marine chemicals are Unitor, Marisol and Marichem.</span></span></span></p></div></div>', '', 0, 0, 1, 1, 1, 0), 
(28, '<div class=\"col-xs-24 col-sm-12 col-md-12\">We offer a wide range of fresh, frozen and dry provision to meet the expectation of quality for all vessel and offshore industries.<br  /><br  />&nbsp;</div>', '', 0, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_bodytext`
--

DROP TABLE IF EXISTS `nv4_en_supplies_bodytext`;
CREATE TABLE `nv4_en_supplies_bodytext` (
  `id` int(11) unsigned NOT NULL,
  `bodytext` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_bodytext`
--

INSERT INTO `nv4_en_supplies_bodytext` VALUES
(25, '  /uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg ship supply engineer store (1)       We provide hoses, couplings, bearings, electrical &amp; hydraulic tools, hand &amp; cutting tools, steel &amp; metal items, lubricants &amp; cleaning products, packing &amp; jointing items and welding materials.  '), 
(28, 'We offer a wide range of fresh, frozen and dry provision to meet the expectation of quality for all vessel and offshore industries.   '), 
(26, '  /uploads/supplies/cabin-stores/ship-supply-cabin-stores-1.jpg ship supply cabin stores 1      We provide linens, beddings and a wide range of cleaning products. We also sell a variety of every-day items on request (e.g. TVs, shavers or shirts).        '), 
(13, '  /uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg ship supply electrical stores 1       We sell lamps, cables and a variety of other spare parts.  '), 
(14, '  /uploads/our-business/rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-1.jpg blue ocean marine service ship supply rubber packing 1        	Water or oil resistance rubber packing (three skins or four skins); 	Oil resistance rubber packing (four skins); 	Straight angle joint; 	Vertical angle joint; 	Vertical angle joint; 	Double folding angle joint; 	End pieces;   '), 
(16, '  /uploads/our-business/jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-1.jpg blue ocean marine service ship supply jis air pipe vent heads 1      Air pipe heads and air vent heads are used for water, oil tank and air: fireproof and waterproof. '), 
(17, '  /uploads/supplies/safety-stores/ship-supply-safety-equipment-1.jpg ship supply safety equipment (1)        	Gas analysers 	Life buoys, life jackets andimmersion suits 	Fire hoses, fire extinguishers, fire-fighting suits 	Life rafts, rescue boats andemergency lights 	Pilot and embarkation ladders 	Oil sorbents 	Life jacket lights (approved by USCG, Lloyds’ Register, Russian Maritime Register)   '), 
(18, '  /uploads/supplies/bridge/ship-supply-charts-publications-10.jpg ship supply charts publications 10      We are selling BA charts &amp; publications as well as a wide range of stationery.   '), 
(19, '  /uploads/our-business/oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-1.jpg blue ocean marine service ship supply oils lubricants 1      Profesional service and fast delivery of Shell oil, Neste, Castrol, Mobil, British Petroleum products to all ships.    	Antiseize assembly compounds; 	Flaw &amp; Crack detector set; 	Open gear lubricants; 	Multi - purpose and liquid greases; 	Insulators against corrosion &amp; rust.   '), 
(20, '  /uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg ship supply paints chemicals (1)       We sell marine paints and coatings from Jotun, International, Hempel and Sigma (among others). Our main brands for marine chemicals are Unitor, Marisol and Marichem.  '), 
(24, '  /uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg ship supply cabin and galley store (1)       We sell various cleaning products, kitchen utensils, dishes and cutleries, bar items and buffet wares.  '), 
(27, '  /uploads/supplies/deck-stores/ship-supply-deck-stores-2.jpg ship supply deck stores (2)      We deliver lifting &amp; lashing equipment, wires ropes &amp; hawsers, anchors, chains, piping materials and tapes. ');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_cat`
--

DROP TABLE IF EXISTS `nv4_en_supplies_cat`;
CREATE TABLE `nv4_en_supplies_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `titlesite` varchar(255) DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `descriptionhtml` text,
  `image` varchar(255) DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50) NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255) DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `keywords` text,
  `admins` text,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_cat`
--

INSERT INTO `nv4_en_supplies_cat` VALUES
(1, 0, 'Supplies', '', 'supplies-1', 'We providing the entire range of Provisions, Cabin, Bonded, Safety, Deck, Engine stores, Galley stores, Marine Chemicals, BA charts, Stationary... and specialize in supply stores for new building vessel.<br /> <br />All of our supplied equipment, materials, spares to the vessel is asbestos -free as per requirements of SOLAS Edition 2011 Ch.II-1&#x002F;Reg3-5&#x002F; MSC.1&#x002F;Circ.1426', '<div style=\"margin-bottom: 5px; text-align: justify;\">We providing the entire range of Provisions, Cabin, Bonded, Safety, Deck, Engine stores, Galley stores, Marine Chemicals, BA charts, Stationary... and specialize in supply stores for new building vessel.<br  />
&nbsp;<br  />
All of our supplied equipment, materials, spares to the vessel is asbestos -free as per requirements of SOLAS Edition 2011 Ch.II-1/Reg3-5/ MSC.1/Circ.1426</div>', 'ship_supply.png', 0, 1, 1, 0, 'viewcat_page_new', 1, '7', 1, 20, 0, 0, 'Ship supply', '', 1441076537, 1457755629, '6'), 
(5, 0, 'General repairs', '', 'general-repairs', '', '<div style=\"margin-bottom: 5px; text-align: justify;\">We repair and make arrangements for:</div>

<div style=\"margin-bottom:15px\">
<ul style=\"list-style: inherit;\">
	<li style=\"margin-bottom: 2px; text-align: justify\">Main Engine , Generator, Boiler, Pumps, Valves, Air compressor, Crane, Winch, Motor rewind, Refrigeration system,Radar, Gyro compass, Gps, Gmdss, Imasat, Vhf , Echo Sounder, Outfitting work, Under water work, Anchor and chain replacement.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Cargo holds cleaning, FO, sewage, sludge tank cleaning, oil spill recollection and gas freeing.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Dry docking attendance and daily service.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\"><img alt=\"1\" height=\"1120\" src=\"/uploads/supplies/1.jpg\" width=\"840\" /></li>
</ul>
</div>', '', 0, 2, 3, 0, 'viewcat_page_new', 0, '', 1, 20, 0, 0, '', '', 1442551665, 1496198013, '6'), 
(6, 0, 'Other services', '', 'other-services', '', '<div style=\"margin-bottom: 5px; text-align: justify;\">We also provide other services such as:</div>

<div style=\"margin-bottom:15px\">
<ul style=\"list-style: inherit;\">
	<li style=\"margin-bottom: 2px; text-align: justify\">Dry dock &amp; survey facilities.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">LSA &amp; FFE inspection &amp; calibration services.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Load test service.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Fresh water supply services.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Garbage &amp; sludge removal services.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\">Underwater survey and cleaning services.</li>
	<li style=\"margin-bottom: 2px; text-align: justify\"><img alt=\"2\" height=\"1120\" src=\"/uploads/supplies/2.jpg\" width=\"840\" /></li>
</ul>
</div>', '', 0, 3, 4, 0, 'viewcat_page_new', 0, '', 1, 20, 0, 0, '', '', 1442551929, 1457751156, '6'), 
(7, 1, 'Technical supply', '', 'technical-supply', '', '<div style=\"margin-bottom: 5px; text-align: justify;\">We put on stock and supply various qualities of cabin, deck and engine stores and spare parts, suitable to the budget of managers and owners.<br  />
<br  />
<i>All of our supplied equipment, materials, spares to the vessel is asbestos -free as per requirements of SOLAS Edition 2011 Ch.II-1/Reg3-5/ MSC.1/Circ.1426</i>.</div>', '', 0, 1, 2, 1, 'viewcat_page_new', 0, '', 1, 20, 0, 0, '', '', 1442633666, 1457755534, '6');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_config_post`
--

DROP TABLE IF EXISTS `nv4_en_supplies_config_post`;
CREATE TABLE `nv4_en_supplies_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_config_post`
--

INSERT INTO `nv4_en_supplies_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(5, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_logs`
--

DROP TABLE IF EXISTS `nv4_en_supplies_logs`;
CREATE TABLE `nv4_en_supplies_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_rows`
--

DROP TABLE IF EXISTS `nv4_en_supplies_rows`;
CREATE TABLE `nv4_en_supplies_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255) NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `hometext` text NOT NULL,
  `homeimgfile` varchar(255) DEFAULT '',
  `homeimgalt` varchar(255) DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `otherimage` text,
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255) DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=30  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_rows`
--

INSERT INTO `nv4_en_supplies_rows` VALUES
(13, 7, '1,7', 0, 2, '', 0, 1441352419, 1564822923, 1, 1442633400, 0, 2, 'Electrics Store', 'electrical-stores', '', 'electrical-stores/ship-supply-electrical-stores-1.jpg', 'ship supply electrical stores &#40;2&#41;', 1, 'electrical-stores/ship-supply-electrical-stores-2.jpg|electrical-stores/ship-supply-electrical-stores-3.jpg|electrical-stores/ship-supply-electrical-stores-4.jpg|electrical-stores/ship-supply-electrical-stores-5.jpg|electrical-stores/ship-supply-electrical-stores-6.jpg|electrical-stores/ship-supply-electrical-stores-7.jpg|electrical-stores/ship-supply-electrical-stores-8.jpg|electrical-stores/ship-supply-electrical-stores-9.jpg|electrical-stores/ship-supply-electrical-stores-10.jpg|electrical-stores/ship-supply-electrical-stores-11.jpg|electrical-stores/ship-supply-electrical-stores-12.jpg|electrical-stores/ship-supply-electrical-stores-13.jpg|electrical-stores/ship-supply-electrical-stores-14.jpg|electrical-stores/ship-supply-electrical-stores-15.jpg', 1, '4', 1, 3459, 0, 0, 0), 
(14, 5, '5', 0, 2, '', 0, 1441352664, 1442977328, 6, 1441352520, 0, 2, 'Rubber packing', 'rubber-packing', '', 'rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-1.jpg', '', 2, 'rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-2.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-3.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-4.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-5.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-6.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-7.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-8.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-9.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-10.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-11.jpg|rubber-packing/blue-ocean-marine-service-ship-supply-rubber-packing-12.jpg', 1, '4', 1, 33, 0, 0, 0), 
(26, 7, '1,7', 0, 2, '', 0, 1442635112, 1564821924, 1, 1442634840, 0, 2, 'Cabin Store', 'cabin-stores', '', 'cabin-stores/ship-supply-cabin-stores-1.jpg', '', 1, 'cabin-stores/ship-supply-cabin-stores-2.jpg|cabin-stores/ship-supply-cabin-stores-3.jpg|cabin-stores/ship-supply-cabin-stores-4.jpg|cabin-stores/ship-supply-cabin-stores-5.jpg|cabin-stores/ship-supply-cabin-stores-6.jpg|cabin-stores/ship-supply-cabin-stores-7.jpg|cabin-stores/ship-supply-cabin-stores-8.jpg|cabin-stores/ship-supply-cabin-stores-9.jpg|cabin-stores/ship-supply-cabin-stores-10.jpg|cabin-stores/ship-supply-cabin-stores-11.jpg|cabin-stores/ship-supply-cabin-stores-12.jpg', 1, '4', 1, 3586, 0, 0, 0), 
(27, 7, '1,7', 0, 2, '', 0, 1442635584, 1564822525, 1, 1442634420, 0, 2, 'Deck Store', 'deck-stores', '', 'deck-stores/ship-supply-deck-stores-2.jpg', 'ship supply deck stores &#40;2&#41;', 1, 'deck-stores/ship-supply-deck-stores-3.jpg|deck-stores/ship-supply-deck-stores-4.jpg|deck-stores/ship-supply-deck-stores-5.jpg|deck-stores/ship-supply-deck-stores-6.jpg|deck-stores/ship-supply-deck-stores-7.jpg|deck-stores/ship-supply-deck-stores-8.jpg|deck-stores/ship-supply-deck-stores-9.jpg|deck-stores/ship-supply-deck-stores-10.jpg|deck-stores/ship-supply-deck-stores-11.jpg|deck-stores/ship-supply-deck-stores-12.jpg|deck-stores/ship-supply-deck-stores-13.jpg|deck-stores/ship-supply-deck-stores-14.jpg|deck-stores/ship-supply-deck-stores-15.jpg|deck-stores/ship-supply-deck-stores-16.jpg|deck-stores/ship-supply-deck-stores-17.jpg|deck-stores/ship-supply-deck-stores-18.jpg|deck-stores/ship-supply-deck-stores-19.jpg|deck-stores/ship-supply-deck-stores-20.jpg|deck-stores/ship-supply-deck-stores-21.jpg|deck-stores/ship-supply-deck-stores-22.jpg|deck-stores/ship-supply-deck-stores-23.jpg', 1, '4', 1, 3652, 0, 0, 0), 
(25, 7, '1,7', 0, 2, '', 0, 1442552579, 1564823028, 1, 1442552280, 0, 2, 'Engine Store', 'engine-stores', '', 'engine-stores/ship-supply-engineer-store-1.jpg', '', 1, 'engine-stores/ship-supply-engineer-store-2.jpg|engine-stores/ship-supply-engineer-store-3.jpg|engine-stores/ship-supply-engineer-store-4.jpg|engine-stores/ship-supply-engineer-store-5.jpg|engine-stores/ship-supply-engineer-store-6.jpg|engine-stores/ship-supply-engineer-store-7.jpg|engine-stores/ship-supply-engineer-store-8.jpg|engine-stores/ship-supply-engineer-store-9.jpg|engine-stores/ship-supply-engineer-store-11.jpg|engine-stores/ship-supply-engineer-store-12.jpg|engine-stores/ship-supply-engineer-store-13.jpg|engine-stores/ship-supply-engineer-store-14.jpg|engine-stores/ship-supply-engineer-store-15.jpg', 1, '4', 1, 3358, 0, 0, 0), 
(16, 1, '1,7', 0, 2, '', 0, 1441353158, 1442977318, 6, 1441353060, 0, 2, 'Jis air pipe vent heads', 'jis-air-pipe-vent-heads', '', 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-1.jpg', '', 2, 'jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-2.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-3.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-4.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-5.jpg|jis-air-pipe-vent-heads/blue-ocean-marine-service-ship-supply-jis-air-pipe-vent-heads-6.jpg', 1, '4', 1, 24, 0, 0, 0), 
(17, 7, '1,7', 0, 2, '', 0, 1441353381, 1564822845, 1, 1442633700, 0, 2, 'Safety &amp; Anti-Piracy Store', 'safety-stores-anti-piracy-items', '', 'safety-stores/ship-supply-safety-equipment-1.jpg', 'ship supply safety equipment &#40;1&#41;', 1, 'safety-stores/ship-supply-safety-equipment-2.jpg|safety-stores/ship-supply-safety-equipment-3.jpg|safety-stores/ship-supply-safety-equipment-4.jpg|safety-stores/ship-supply-safety-equipment-5.jpg|safety-stores/ship-supply-safety-equipment-6.jpg|safety-stores/ship-supply-safety-equipment-7.jpg|safety-stores/ship-supply-safety-equipment-8.jpg|safety-stores/ship-supply-safety-equipment-9.jpg|safety-stores/ship-supply-safety-equipment-10.jpg|safety-stores/ship-supply-safety-equipment-11.jpg|safety-stores/ship-supply-safety-equipment-12.jpg|safety-stores/ship-supply-safety-equipment-13.jpg|safety-stores/ship-supply-safety-equipment-14.jpg|safety-stores/ship-supply-safety-equipment-15.jpg', 1, '4', 1, 3450, 0, 0, 0), 
(18, 7, '1,7', 0, 2, '', 0, 1441353513, 1564822145, 1, 1442634600, 0, 2, 'Bridge Store', 'bridge', '', 'bridge/ship-supply-charts-publications-10.jpg', '', 1, 'bridge/ship-supply-charts-publications-9.jpg|bridge/ship-supply-charts-publications-7.jpg|bridge/ship-supply-charts-publications-6.jpg|bridge/ship-supply-charts-publications-8.jpg|bridge/ship-supply-charts-publications-1.jpg|bridge/ship-supply-charts-publications-5.jpg|bridge/ship-supply-charts-publications-3.jpg|bridge/ship-supply-charts-publications-4.jpg|bridge/ship-supply-charts-publications-2.jpg', 1, '4', 1, 3420, 0, 0, 0), 
(19, 7, '1,7', 0, 2, '', 0, 1441353649, 1442977304, 6, 1441353480, 0, 2, 'Oils - Lubricants', 'oils-lubricants', '', 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-1.jpg', '', 2, 'oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-2.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-3.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-4.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-5.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-6.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-7.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-8.jpg|oils-lubricants/blue-ocean-marine-service-ship-supply-oils-lubricants-9.jpg', 1, '4', 1, 28, 0, 0, 0), 
(20, 7, '1,7', 0, 2, '', 0, 1441353895, 1564822620, 1, 1442634000, 0, 2, 'Paints &amp; Chemicals Store', 'marine-paints-chemicals', '', 'marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', 'ship supply paints chemicals &#40;1&#41;', 1, 'marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg|marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', 1, '4', 1, 4277, 0, 0, 0), 
(28, 1, '1', 0, 2, '', 0, 1442636458, 1457755035, 1, 1442635800, 0, 2, 'Supply Provision', 'supplier', '', 'provision/ship-supply-provision-1.jpg', '', 1, 'provision/ship-supply-provision-2.jpg|provision/ship-supply-provision-3.jpg|provision/ship-supply-provision-4.jpg|provision/ship-supply-provision-5.jpg|provision/ship-supply-provision-6.jpg|provision/ship-supply-provision-7.jpg|provision/ship-supply-provision-8.jpg|provision/ship-supply-provision-9.jpg|provision/ship-supply-provision-10.jpg|provision/ship-supply-provision-11.jpg|provision/ship-supply-provision-12.jpg|provision/ship-supply-provision-13.jpg|provision/ship-supply-provision-14.jpg|provision/ship-supply-provision-15.jpg|provision/ship-supply-provision-16.jpg|provision/ship-supply-provision-17.jpg|provision/ship-supply-provision-18.jpg', 1, '4', 1, 2777, 0, 0, 0), 
(24, 7, '1,7', 0, 2, '', 0, 1442138730, 1564822359, 1, 1442634540, 0, 2, 'Galley Store', 'galley-stores', '', 'galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 1, 'galley-stores/ship-supply-cabin-and-galley-store-2.jpg|galley-stores/ship-supply-cabin-and-galley-store-3.jpg|galley-stores/ship-supply-cabin-and-galley-store-4.jpg|galley-stores/ship-supply-cabin-and-galley-store-5.jpg|galley-stores/ship-supply-cabin-and-galley-store-6.jpg|galley-stores/ship-supply-cabin-and-galley-store-7.jpg|galley-stores/ship-supply-cabin-and-galley-store-8.jpg|galley-stores/ship-supply-cabin-and-galley-store-9.jpg|galley-stores/ship-supply-cabin-and-galley-store-10.jpg|galley-stores/ship-supply-cabin-and-galley-store-11.jpg|galley-stores/ship-supply-cabin-and-galley-store-12.jpg|galley-stores/ship-supply-cabin-and-galley-store-13.jpg|galley-stores/ship-supply-cabin-and-galley-store-14.jpg|galley-stores/ship-supply-cabin-and-galley-store-15.jpg|galley-stores/ship-supply-cabin-and-galley-store-16.jpg', 1, '4', 1, 3576, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_sources`
--

DROP TABLE IF EXISTS `nv4_en_supplies_sources`;
CREATE TABLE `nv4_en_supplies_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` varchar(255) DEFAULT '',
  `logo` varchar(255) DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_tags`
--

DROP TABLE IF EXISTS `nv4_en_supplies_tags`;
CREATE TABLE `nv4_en_supplies_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` text,
  `keywords` varchar(255) DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_supplies_tags`
--

INSERT INTO `nv4_en_supplies_tags` VALUES
(1, 0, 'trung-nghia', '', '', 'trung nghia'), 
(2, 0, 'màn-sáo', '', '', 'màn sáo'), 
(3, 0, 'electrical-store', '', '', 'Electrical store'), 
(4, 0, 'ship-supply', '', '', 'ship supply'), 
(5, 0, 'blue-ocean', '', '', 'blue ocean');


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_tags_id`
--

DROP TABLE IF EXISTS `nv4_en_supplies_tags_id`;
CREATE TABLE `nv4_en_supplies_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65) NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_supplies_topics`
--

DROP TABLE IF EXISTS `nv4_en_supplies_topics`;
CREATE TABLE `nv4_en_supplies_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) DEFAULT '',
  `description` varchar(255) DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_en_support`
--

DROP TABLE IF EXISTS `nv4_en_support`;
CREATE TABLE `nv4_en_support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idgroup` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `skype_item` varchar(100) NOT NULL,
  `skype_type` varchar(100) NOT NULL,
  `yahoo_item` varchar(100) NOT NULL,
  `yahoo_type` varchar(2) NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_support`
--

INSERT INTO `nv4_en_support` VALUES
(4, '1', 'Philip Huynh', '+84 8 6667 9502', 'tech@vietnamshipsupply.com', '', 'balloon', '', '0', 1), 
(5, '2', 'Simone Thien An', '+84 8 6667 9502', 'supply@vietnamshipsupply.com', '', 'balloon', '', '0', 2);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_support_group`
--

DROP TABLE IF EXISTS `nv4_en_support_group`;
CREATE TABLE `nv4_en_support_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_support_group`
--

INSERT INTO `nv4_en_support_group` VALUES
(1, 'Technical Dept.', 3), 
(2, 'Purchasing Dept.', 4);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_voting`
--

DROP TABLE IF EXISTS `nv4_en_voting`;
CREATE TABLE `nv4_en_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255) DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_voting`
--

INSERT INTO `nv4_en_voting` VALUES
(2, 'Do you know about Nukeviet 3?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'What are you interested in open source?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_en_voting_rows`
--

DROP TABLE IF EXISTS `nv4_en_voting_rows`;
CREATE TABLE `nv4_en_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_en_voting_rows`
--

INSERT INTO `nv4_en_voting_rows` VALUES
(5, 2, 'A whole new sourcecode for the web.', '', 0), 
(6, 2, 'Open source, free to use.', '', 0), 
(7, 2, 'Use of xHTML, CSS and Ajax support', '', 0), 
(8, 2, 'All the comments on', '', 0), 
(9, 3, 'constantly improved, modified by the whole world.', '', 0), 
(10, 3, 'To use the free of charge.', '', 0), 
(11, 3, 'The freedom to explore, modify at will.', '', 0), 
(12, 3, 'Match to learning and research because the freedom to modify at will.', '', 0), 
(13, 3, 'All comments on', '', 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_extension_files`
--

DROP TABLE IF EXISTS `nv4_extension_files`;
CREATE TABLE `nv4_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_googleplus`
--

DROP TABLE IF EXISTS `nv4_googleplus`;
CREATE TABLE `nv4_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `idprofile` varchar(25) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_groups`
--

DROP TABLE IF EXISTS `nv4_groups`;
CREATE TABLE `nv4_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text,
  `content` text,
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `publics` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups`
--

INSERT INTO `nv4_groups` VALUES
(1, 'Super admin', 'Super Admin', '', 1439973638, 0, 0, 1, 1, 0, 1, 0), 
(2, 'General admin', 'General Admin', '', 1439973638, 0, 0, 2, 1, 0, 1, 0), 
(3, 'Module admin', 'Module Admin', '', 1439973638, 0, 0, 3, 1, 0, 0, 0), 
(4, 'Users', 'Users', '', 1439973638, 0, 0, 4, 1, 0, 3, 0), 
(5, 'Guest', 'Guest', '', 1439973638, 0, 0, 5, 1, 0, 0, 0), 
(6, 'All', 'All', '', 1439973638, 0, 0, 6, 1, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_groups_users`
--

DROP TABLE IF EXISTS `nv4_groups_users`;
CREATE TABLE `nv4_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_groups_users`
--

INSERT INTO `nv4_groups_users` VALUES
(1, 1, '0'), 
(2, 3, '0');


-- ---------------------------------------


--
-- Table structure for table `nv4_language`
--

DROP TABLE IF EXISTS `nv4_language`;
CREATE TABLE `nv4_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_language_file`
--

DROP TABLE IF EXISTS `nv4_language_file`;
CREATE TABLE `nv4_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50) NOT NULL,
  `admin_file` varchar(255) NOT NULL DEFAULT '0',
  `langtype` varchar(50) NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_logs`
--

DROP TABLE IF EXISTS `nv4_logs`;
CREATE TABLE `nv4_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10) NOT NULL,
  `module_name` varchar(150) NOT NULL,
  `name_key` varchar(255) NOT NULL,
  `note_action` text NOT NULL,
  `link_acess` varchar(255) DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=1568  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_logs`
--

INSERT INTO `nv4_logs` VALUES
(1, 'en', 'login', '[trungnghiack@gmail.com] Login', ' Client IP:::1', '', 0, 1439973735), 
(2, 'en', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1439973893), 
(3, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1439975651), 
(4, 'en', 'modules', 'Add virtual module our_business', '', '', 1, 1439977178), 
(5, 'en', 'modules', 'Setup new module our-business', '', '', 1, 1439977190), 
(6, 'en', 'modules', 'Edit modules &ldquo;our-business&rdquo;', '', '', 1, 1439977230), 
(7, 'en', 'modules', 'Setup new module home', '', '', 1, 1439977336), 
(8, 'en', 'modules', 'Edit modules &ldquo;home&rdquo;', '', '', 1, 1439977350), 
(9, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1439977546), 
(10, 'en', 'modules', 'Order module: home', '16 -> 1', '', 1, 1439977585), 
(11, 'en', 'modules', 'Order module: our-business', '16 -> 3', '', 1, 1439977597), 
(12, 'en', 'modules', 'Order module: contact', '16 -> 5', '', 1, 1439977606), 
(13, 'en', 'modules', 'Setup new module slider', '', '', 1, 1439987546), 
(14, 'en', 'modules', 'Edit modules &ldquo;slider&rdquo;', '', '', 1, 1439987564), 
(15, 'en', 'slider', 'Add categories', 'Banner', '', 1, 1439987593), 
(16, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-1.jpg', '', 1, 1439987675), 
(17, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-2.jpg', '', 1, 1439987676), 
(18, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-3.jpg', '', 1, 1439987677), 
(19, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-4.jpg', '', 1, 1439987678), 
(20, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-5.jpg', '', 1, 1439987680), 
(21, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-6.jpg', '', 1, 1439987681), 
(22, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-7.jpg', '', 1, 1439987682), 
(23, 'en', 'themes', 'Edit block', 'Name : Banner', '', 1, 1439987935), 
(24, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 1, 1439988913), 
(25, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 1, 1439989440), 
(26, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1439989833), 
(27, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_repair.png', '', 1, 1439990255), 
(28, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_service.png', '', 1, 1439990256), 
(29, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_supply.png', '', 1, 1439990256), 
(30, 'en', 'our-business', 'Add categories', 'Ship supply', '', 1, 1439990275), 
(31, 'en', 'our-business', 'Add categories', 'Ship repair', '', 1, 1439990340), 
(32, 'en', 'our-business', 'Add categories', 'Ship service', '', 1, 1439990370), 
(33, 'en', 'themes', 'Edit block', 'Name : Our business', '', 1, 1439990629), 
(34, 'en', 'about', 'Delete', 'ID: 1', '', 1, 1439993098), 
(35, 'en', 'about', 'Delete', 'ID: 2', '', 1, 1439993101), 
(36, 'en', 'upload', 'Upload file', 'uploads/about/70105290-126322sm.jpg', '', 1, 1439993267), 
(37, 'en', 'upload', 'Upload file', 'uploads/about/sci.jpg', '', 1, 1439993484), 
(38, 'en', 'about', 'Add', ' ', '', 1, 1439993578), 
(39, 'en', 'themes', 'Edit block', 'Name : About us', '', 1, 1439993647), 
(40, 'en', 'about', 'Edit', 'ID: 3', '', 1, 1439994622), 
(41, 'en', 'slider', 'Add categories', 'Đối tác', '', 1, 1439995468), 
(42, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt1.png', '', 1, 1439995521), 
(43, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt2.png', '', 1, 1439995521), 
(44, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt3.png', '', 1, 1439995521), 
(45, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt4.png', '', 1, 1439995522), 
(46, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt5.png', '', 1, 1439995522), 
(47, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/dt6.png', '', 1, 1439995522), 
(48, 'en', 'themes', 'Add block', 'Name : We are the Distributor of the following brands', '', 1, 1439995727), 
(49, 'en', 'themes', 'Edit block', 'Name : Main categories', '', 1, 1439997096), 
(50, 'en', 'themes', 'Edit block', 'Name : Our business', '', 1, 1439997327), 
(51, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 1, 1439999776), 
(52, 'en', 'modules', 'Setup new module support', '', '', 1, 1440001506), 
(53, 'en', 'modules', 'Edit modules &ldquo;support&rdquo;', '', '', 1, 1440001521), 
(54, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440002171), 
(55, 'en', 'support', 'Sửa nhóm nhân viên', 'nsupportid 1', '', 1, 1440002211), 
(56, 'en', 'support', 'Thêm nhân viên', ' ', '', 1, 1440002249), 
(57, 'en', 'themes', 'Edit block', 'Name : Support Online', '', 1, 1440002324), 
(58, 'en', 'themes', 'Edit block', 'Name : Support Online', '', 1, 1440002355), 
(59, 'en', 'login', '[admin] Login', ' Client IP:::1', '', 0, 1440010083), 
(60, 'en', 'our-business', 'Add categories', 'Provision', '', 1, 1440011001), 
(61, 'en', 'our-business', 'Add categories', 'Pipe Valve', '', 1, 1440011023), 
(62, 'en', 'our-business', 'Add categories', 'Electrical store', '', 1, 1440011038), 
(63, 'en', 'our-business', 'Add categories', 'Rubber Packing', '', 1, 1440011055), 
(64, 'en', 'our-business', 'Add categories', 'Deck Enginer Store', '', 1, 1440011069), 
(65, 'en', 'our-business', 'Add categories', 'JIS air pipe vent heads', '', 1, 1440011085), 
(66, 'en', 'our-business', 'Add categories', 'Safety Equipment', '', 1, 1440011097), 
(67, 'en', 'our-business', 'Add categories', 'Charts Publications', '', 1, 1440011130), 
(68, 'en', 'our-business', 'Add categories', 'Oils, lubricants', '', 1, 1440011150), 
(69, 'en', 'our-business', 'Add categories', 'Paints and Chemicals', '', 1, 1440011164), 
(70, 'en', 'our-business', 'Add categories', 'Repair', '', 1, 1440011199), 
(71, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/6-14115440817.jpg', '', 1, 1440011381), 
(72, 'en', 'our-business', 'Add a new article', 'Provision', '', 1, 1440011432), 
(73, 'en', 'our-business', 'Edit article', 'Provision', '', 1, 1440011770), 
(74, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1440012969), 
(75, 'en', 'themes', 'Add block', 'Name : Menu Business', '', 1, 1440013095), 
(76, 'en', 'themes', 'Edit block', 'Name : Our Business', '', 1, 1440015819), 
(77, 'en', 'themes', 'Update position of block', 'reset position all block', '', 1, 1440016008), 
(78, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1440017147), 
(79, 'en', 'login', '[admin] Login', ' Client IP:::1', '', 0, 1440021283), 
(80, 'en', 'our-business', 'Delete topics and articles', 'Repair', '', 1, 1440021902), 
(81, 'en', 'our-business', 'Delete topics and articles', 'Oils, lubricants', '', 1, 1440021919), 
(82, 'en', 'our-business', 'Delete topics and articles', 'Charts Publications', '', 1, 1440021922), 
(83, 'en', 'our-business', 'Delete topics and articles', 'Safety Equipment', '', 1, 1440021924), 
(84, 'en', 'our-business', 'Delete topics and articles', 'JIS air pipe vent heads', '', 1, 1440021927), 
(85, 'en', 'our-business', 'Delete topics and articles', 'Deck Enginer Store', '', 1, 1440021929), 
(86, 'en', 'our-business', 'Delete topics and articles', 'Rubber Packing', '', 1, 1440021930), 
(87, 'en', 'our-business', 'Delete topics and articles', 'Electrical store', '', 1, 1440021932), 
(88, 'en', 'our-business', 'Delete topics and articles', 'Pipe Valve', '', 1, 1440021934), 
(89, 'en', 'our-business', 'Delete topics and articles', 'Paints and Chemicals', '', 1, 1440021940), 
(90, 'en', 'our-business', 'Edit article', 'Provision', '', 1, 1440021972), 
(91, 'en', 'our-business', 'Delete topics and articles', 'Provision', '', 1, 1440021984), 
(92, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/1-141154394130-1.jpg', '', 1, 1440022067), 
(93, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/1-141154394130.jpg', '', 1, 1440022068), 
(94, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/3-141154394152.jpg', '', 1, 1440022068), 
(95, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/4-141154394153.jpg', '', 1, 1440022069), 
(96, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/5-141154394144-1.jpg', '', 1, 1440022069), 
(97, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/5-141154394144.jpg', '', 1, 1440022070), 
(98, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/6-14115440817_1.jpg', '', 1, 1440022070), 
(99, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/6-141154400540.jpg', '', 1, 1440022071), 
(100, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/egg-141154400572.jpg', '', 1, 1440022072), 
(101, 'en', 'our-business', 'Add a new article', 'Pipe Valve', '', 1, 1440022115), 
(102, 'en', 'our-business', 'Add a new article', 'Electrical store', '', 1, 1440022182), 
(103, 'en', 'our-business', 'Add a new article', 'Rubber Packing', '', 1, 1440022221), 
(104, 'en', 'our-business', 'Add a new article', 'Deck Enginer Store', '', 1, 1440022265), 
(105, 'en', 'our-business', 'Add a new article', 'JIS air pipe vent heads', '', 1, 1440022327), 
(106, 'en', 'our-business', 'Add a new article', 'Repair', '', 1, 1440022407), 
(107, 'en', 'our-business', 'Edit article', 'JIS air pipe vent heads', '', 1, 1440032055), 
(108, 'en', 'themes', 'Edit block', 'Name : We are the Distributor of the following brands', '', 1, 1440032884), 
(109, 'en', 'login', '[admin] Leave Administration', ' Client IP:::1', '', 0, 1440033123), 
(110, 'en', 'login', '[admin] Login', ' Client IP:::1', '', 0, 1440033385), 
(111, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440033394), 
(112, 'en', 'login', '[admin] Leave Administration', ' Client IP:::1', '', 0, 1440034200), 
(113, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1440747715), 
(114, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440747745), 
(115, 'en', 'users', 'log_add_user', 'userid 2', '', 1, 1440747988), 
(116, 'en', 'authors', 'Add an Administrator', 'Username: hoangnhan', '', 1, 1440748015), 
(117, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440750436), 
(118, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440751184), 
(119, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_08/moi.jpg', '', 1, 1440753023), 
(120, 'en', 'our-business', 'Add a new article', 'trung nghia', '', 1, 1440754353), 
(121, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440754453), 
(122, 'en', 'our-business', 'Add a new article', 'trung nghia', '', 1, 1440754485), 
(123, 'en', 'our-business', 'Add a new article', 'trung nghia', '', 1, 1440754907), 
(124, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440754928), 
(125, 'en', 'our-business', 'Add a new article', 'k hieu', '', 1, 1440755047), 
(126, 'en', 'our-business', 'Delete article', 'Sdf', '', 1, 1440755296), 
(127, 'en', 'our-business', 'Delete article', 'k hieu', '', 1, 1440755325), 
(128, 'en', 'our-business', 'Delete article', 'trung nghia', '', 1, 1440755364), 
(129, 'en', 'news', 'Delete article', 'NukeViet 3.0 - New CMS for News site', '', 1, 1440755399), 
(130, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/1-141154394130-1.jpg', '', 1, 1440755442), 
(131, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/1-141154394130.jpg', '', 1, 1440755442), 
(132, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/3-141154394152.jpg', '', 1, 1440755442), 
(133, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/4-141154394153.jpg', '', 1, 1440755443), 
(134, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/5-141154394144-1.jpg', '', 1, 1440755443), 
(135, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/5-141154394144.jpg', '', 1, 1440755444), 
(136, 'en', 'upload', 'Upload file', 'uploads/news/2015_08/6-14115440817.jpg', '', 1, 1440755444), 
(137, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440755792), 
(138, 'en', 'our-business', 'Delete article', 'trung nghia', '', 1, 1440755800), 
(139, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440756066), 
(140, 'en', 'our-business', 'Delete article', 'trung nghia', '', 1, 1440756074), 
(141, 'en', 'our-business', 'Add a new article', 'Provisionfdf', '', 1, 1440756097), 
(142, 'en', 'our-business', 'Delete article', 'Provisionfdf', '', 1, 1440756127), 
(143, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1440756155), 
(144, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1440756161), 
(145, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440756308), 
(146, 'en', 'our-business', 'Add a new article', 'sfda', '', 1, 1440756329), 
(147, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1440756469), 
(148, 'en', 'our-business', 'Add a new article', 'sds', '', 1, 1440756583), 
(149, 'en', 'our-business', 'Delete article', 'sds', '', 1, 1440756589), 
(150, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1440756592), 
(151, 'en', 'our-business', 'Delete article', 'sfda', '', 1, 1440756595), 
(152, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440756918), 
(153, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440757038), 
(154, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1440757405), 
(155, 'en', 'our-business', 'Add a new article', 'trung nghia', '', 1, 1440758079), 
(156, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1440758158), 
(157, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1440758162), 
(158, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1440812169), 
(159, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440812181), 
(160, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1440812195), 
(161, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1440812205), 
(162, 'en', 'our-business', 'Add a new article', 'hiihi', '', 1, 1440812277), 
(163, 'en', 'our-business', 'Add a new article', 'hiihi', '', 1, 1440812281), 
(164, 'en', 'our-business', 'Delete article', 'hiihi', '', 1, 1440812297), 
(165, 'en', 'our-business', 'Delete article', 'hiihi', '', 1, 1440812300), 
(166, 'en', 'login', '[hoangnhan] Login', ' Client IP:14.169.129.151', '', 0, 1440819381), 
(167, 'en', 'users', 'log_edit_user', 'userid 2', '', 2, 1440819424), 
(168, 'en', 'login', '[nhannh] Leave Administration', ' Client IP:14.169.129.151', '', 0, 1440819434), 
(169, 'en', 'login', '[nhannh] Login', ' Client IP:14.169.129.151', '', 0, 1440819446), 
(170, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 2, 1440820007), 
(171, 'en', 'news', 'Add a new article', 'sdf', '', 1, 1440823332), 
(172, 'en', 'news', 'Add a new article', 'sdf', '', 1, 1440823340), 
(173, 'en', 'news', 'Add a new article', 'sdf', '', 1, 1440823343), 
(174, 'en', 'news', 'Delete article', 'sdf', '', 1, 1440823360), 
(175, 'en', 'news', 'Delete article', 'sdf', '', 1, 1440823368), 
(176, 'en', 'news', 'Delete article', 'sdf', '', 1, 1440823376), 
(177, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.246.16', '', 0, 1440907977), 
(178, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.246.16', '', 0, 1440924745), 
(179, 'en', 'login', '[nhannh] Leave Administration', ' Client IP:116.102.246.16', '', 0, 1440924901), 
(180, 'en', 'login', '[admin] Login', ' Client IP:116.102.246.16', '', 0, 1440924920), 
(181, 'en', 'login', '[admin] Leave Administration', ' Client IP:116.102.246.16', '', 0, 1440925026), 
(182, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.246.16', '', 0, 1440925040), 
(183, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-7.jpg', '', 2, 1440925065), 
(184, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-6.jpg', '', 2, 1440925065), 
(185, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-5.jpg', '', 2, 1440925065), 
(186, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-4.jpg', '', 2, 1440925065), 
(187, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-3.jpg', '', 2, 1440925065), 
(188, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-2.jpg', '', 2, 1440925065), 
(189, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/vat-tu-hang-hai-banner-1.jpg', '', 2, 1440925065), 
(190, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-1.jpg', '', 2, 1440925076), 
(191, 'en', 'slider', 'Edit categories', 'banner-1', '', 2, 1440925081), 
(192, 'en', 'slider', 'Edit categories', 'banner-2', '', 2, 1440925134), 
(193, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1440925148), 
(194, 'en', 'slider', 'Edit categories', 'banner-4', '', 2, 1440925187), 
(195, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1440925203), 
(196, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1440925220), 
(197, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-2.jpg', '', 2, 1440927719), 
(198, 'en', 'slider', 'Edit categories', 'banner-2', '', 2, 1440927724), 
(199, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-3.jpg', '', 2, 1440929348), 
(200, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1440929352), 
(201, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.246.16', '', 0, 1440942142), 
(202, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-4.jpg', '', 2, 1440945002), 
(203, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-5.jpg', '', 2, 1440945002), 
(204, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-6.jpg', '', 2, 1440945003), 
(205, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-7.jpg', '', 2, 1440945004), 
(206, 'en', 'slider', 'Edit categories', 'banner-4', '', 2, 1440945022), 
(207, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1440945076), 
(208, 'en', 'slider', 'Edit categories', 'banner-1', '', 2, 1440945138), 
(209, 'en', 'themes', 'Edit block', 'Name : Banner', '', 2, 1440945192), 
(210, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1440945248), 
(211, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1440945260), 
(212, 'en', 'slider', 'Edit categories', 'banner-6', '', 2, 1440945276), 
(213, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1440945306), 
(214, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/blue-ocean-banner-6.jpg', '', 2, 1440945474), 
(215, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-banner-6.jpg', '', 2, 1440945481), 
(216, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1440945486), 
(217, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt3.png', '', 2, 1440951032), 
(218, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt4.png', '', 2, 1440951032), 
(219, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt5.png', '', 2, 1440951032), 
(220, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt6.png', '', 2, 1440951032), 
(221, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt1.png', '', 2, 1440951032), 
(222, 'en', 'upload', 'Delete file', 'uploads/slider/2015_08/dt2.png', '', 2, 1440951032), 
(223, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-1.jpg', '', 2, 1440951042), 
(224, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-2.jpg', '', 2, 1440951042), 
(225, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-3.jpg', '', 2, 1440951042), 
(226, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-4.jpg', '', 2, 1440951043), 
(227, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-5.jpg', '', 2, 1440951043), 
(228, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-6.jpg', '', 2, 1440951043), 
(229, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-7.jpg', '', 2, 1440951043), 
(230, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-8.jpg', '', 2, 1440951043), 
(231, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-9.jpg', '', 2, 1440951043), 
(232, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-10.jpg', '', 2, 1440951043), 
(233, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-11.jpg', '', 2, 1440951043), 
(234, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-12.jpg', '', 2, 1440951043), 
(235, 'en', 'slider', 'Edit categories', 'logo-brands-1', '', 2, 1440951060), 
(236, 'en', 'slider', 'Edit categories', 'logo-brands-2', '', 2, 1440951080), 
(237, 'en', 'slider', 'Edit categories', 'logo-brands-3', '', 2, 1440951098), 
(238, 'en', 'slider', 'Edit categories', 'logo-brands-4', '', 2, 1440951121), 
(239, 'en', 'slider', 'Edit categories', 'logo-brands-5', '', 2, 1440951138), 
(240, 'en', 'slider', 'Edit categories', 'logo-brands-6', '', 2, 1440951160), 
(241, 'en', 'themes', 'Edit block', 'Name : We are the Distributor of the following brands', '', 2, 1440951416), 
(242, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-13.jpg', '', 2, 1440954062), 
(243, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-14.jpg', '', 2, 1440954062), 
(244, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-15.jpg', '', 2, 1440954062), 
(245, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-16.jpg', '', 2, 1440954062), 
(246, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-17.jpg', '', 2, 1440954063), 
(247, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-18.jpg', '', 2, 1440954063), 
(248, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-19.jpg', '', 2, 1440954063), 
(249, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-20.jpg', '', 2, 1440954063), 
(250, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-21.jpg', '', 2, 1440954174), 
(251, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-22.jpg', '', 2, 1440954189), 
(252, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-23.jpg', '', 2, 1440954189), 
(253, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-24.jpg', '', 2, 1440954189), 
(254, 'en', 'upload', 'Upload file', 'uploads/slider/2015_08/blue-ocean-logo-25.jpg', '', 2, 1440954189), 
(255, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1440984496), 
(256, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440984508), 
(257, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 1, 1440985195), 
(258, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440986881), 
(259, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1440989299), 
(260, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 1, 1440989607), 
(261, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1440990199), 
(262, 'en', 'modules', 'Delete module \"about\"', '', '', 1, 1440992807), 
(263, 'en', 'modules', 'Add virtual module about', '', '', 1, 1440992819), 
(264, 'en', 'modules', 'Setup new module about', '', '', 1, 1440992824), 
(265, 'en', 'modules', 'Edit modules &ldquo;about&rdquo;', '', '', 1, 1440992837), 
(266, 'en', 'upload', 'Upload file', 'uploads/about/70105290-126322sm.jpg', '', 1, 1440992905), 
(267, 'en', 'about', 'Add', ' ', '', 1, 1440992972), 
(268, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1440993005), 
(269, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440993033), 
(270, 'en', 'page', 'Add', ' ', '', 1, 1440993302), 
(271, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440993407), 
(272, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440993411), 
(273, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440994886), 
(274, 'en', 'modules', 'Delete module \"about\"', '', '', 1, 1440994909), 
(275, 'en', 'modules', 'Reinstall module \"page\"', '', '', 1, 1440994921), 
(276, 'en', 'page', 'Add', ' ', '', 1, 1440994936), 
(277, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1440995904), 
(278, 'en', 'modules', 'Reinstall module \"page\"', '', '', 1, 1440995919), 
(279, 'en', 'page', 'Add', ' ', '', 1, 1440995940), 
(280, 'en', 'modules', 'Reinstall module \"page\"', '', '', 1, 1440996055), 
(281, 'en', 'page', 'Add', ' ', '', 1, 1440996088), 
(282, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1441003399), 
(283, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441004017), 
(284, 'en', 'page', 'Delete', 'ID: 1', '', 1, 1441004485), 
(285, 'en', 'modules', 'Add virtual module about', '', '', 1, 1441004505), 
(286, 'en', 'modules', 'Setup new module about', '', '', 1, 1441004509), 
(287, 'en', 'modules', 'Edit modules &ldquo;about&rdquo;', '', '', 1, 1441004522), 
(288, 'en', 'upload', 'Upload file', 'uploads/about/70105290-126322sm.jpg', '', 1, 1441004602), 
(289, 'en', 'about', 'Add', ' ', '', 1, 1441004637), 
(290, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1441004659), 
(291, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441004722), 
(292, 'en', 'themes', 'Add block', 'Name : About', '', 1, 1441004873), 
(293, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441005521), 
(294, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441005607), 
(295, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441005660), 
(296, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441005749), 
(297, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441005871), 
(298, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441006039), 
(299, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441006095), 
(300, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441006115), 
(301, 'en', 'themes', 'Edit block', 'Name : Menu Business', '', 1, 1441006306), 
(302, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1441008004), 
(303, 'en', 'modules', 'Order module: about', '18 -> 2', '', 1, 1441008051), 
(304, 'en', 'themes', 'Edit block', 'Name : Banner', '', 1, 1441008409), 
(305, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 1, 1441008435), 
(306, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1441009953), 
(307, 'en', 'our-business', 'Delete article', 'trung nghia', '', 1, 1441009964), 
(308, 'en', 'our-business', 'Edit article', 'Repair', '', 1, 1441011076), 
(309, 'en', 'themes', 'Add block', 'Name : Support', '', 1, 1441013372), 
(310, 'en', 'themes', 'Add block', 'Name : Address contact', '', 1, 1441013680), 
(311, 'en', 'themes', 'Edit block', 'Name : Support', '', 1, 1441013836), 
(312, 'en', 'themes', 'Edit block', 'Name : Address contact', '', 1, 1441013855), 
(313, 'en', 'themes', 'Edit block', 'Name : Support', '', 1, 1441013897), 
(314, 'en', 'themes', 'Edit block', 'Name : Address contact', '', 1, 1441014005), 
(315, 'en', 'contact', 'log_edit_row', 'id: 1 Consumer Care Division', '', 1, 1441014128), 
(316, 'en', 'upload', 'Delete file', 'uploads/logo.png', '', 1, 1441014428), 
(317, 'en', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1441014435), 
(318, 'en', 'themes', 'Edit block', 'Name : Our Business', '', 1, 1441015257), 
(319, 'en', 'our-business', 'Add a new article', 'sfs', '', 1, 1441017306), 
(320, 'en', 'our-business', 'Delete article', 'sfs', '', 1, 1441017318), 
(321, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441070458), 
(322, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441071800), 
(323, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441073604), 
(324, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441074047), 
(325, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441074441), 
(326, 'en', 'modules', 'Delete module \"our-business\"', '', '', 1, 1441075107), 
(327, 'en', 'modules', 'Reinstall module \"news\"', '', '', 1, 1441075132), 
(328, 'en', 'modules', 'Reinstall module \"news\"', '', '', 1, 1441075222), 
(329, 'en', 'news', 'Add categories', 'Tin giải trí', '', 1, 1441075254), 
(330, 'en', 'news', 'Add categories', 'Tin công ty', '', 1, 1441075265), 
(331, 'en', 'news', 'Add categories', 'Tin tổng hợp', '', 1, 1441075277), 
(332, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/dong-nhi9.jpg', '', 1, 1441075651), 
(333, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/hinh-anh-hot-girl-tam-tit-2.jpg', '', 1, 1441075651), 
(334, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/images-1.jpg', '', 1, 1441075652), 
(335, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/images.jpg', '', 1, 1441075653), 
(336, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/img-4193-1371951689294.jpg', '', 1, 1441075653), 
(337, 'en', 'news', 'Add a new article', 'Lập trình viên Lê Thúc Vinh kết duyên cùng hotgirl Tâm Tít', '', 1, 1441075761), 
(338, 'en', 'modules', 'Add virtual module our_business', '', '', 1, 1441075825), 
(339, 'en', 'modules', 'Setup new module our-business', '', '', 1, 1441075829), 
(340, 'en', 'modules', 'Edit modules &ldquo;our-business&rdquo;', '', '', 1, 1441075851), 
(341, 'en', 'news', 'Edit article', 'Hotgirl Tâm Tít vạn người mê', '', 1, 1441076359), 
(342, 'en', 'upload', 'Upload file', 'uploads/our-business/images397497_ship_03.jpg', '', 1, 1441076484), 
(343, 'en', 'upload', 'Upload file', 'uploads/our-business/nguyen-nhan-tau-thuyen-bi-ha.jpg', '', 1, 1441076485), 
(344, 'en', 'upload', 'Upload file', 'uploads/our-business/tau.jpg', '', 1, 1441076485), 
(345, 'en', 'our-business', 'Add categories', 'Ship supply', '', 1, 1441076537), 
(346, 'en', 'our-business', 'Add categories', 'Ship repair', '', 1, 1441076583), 
(347, 'en', 'our-business', 'Add categories', 'Ship service', '', 1, 1441076607), 
(348, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/1-141154394130.jpg', '', 1, 1441076802), 
(349, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/3-141154394152.jpg', '', 1, 1441076803), 
(350, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/4-141154394153.jpg', '', 1, 1441076803), 
(351, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/6-14115440817.jpg', '', 1, 1441076803), 
(352, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/8-14137854309.jpg', '', 1, 1441076804), 
(353, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/cap-hang-phao-2-14133477251.jpg', '', 1, 1441076805), 
(354, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/dsc03333-14138747252.jpg', '', 1, 1441076806), 
(355, 'en', 'upload', 'Upload file', 'uploads/our-business/2015_09/moi.jpg', '', 1, 1441076806), 
(356, 'en', 'our-business', 'Add a new article', 'Provision', '', 1, 1441076858), 
(357, 'en', 'themes', 'Add block', 'Name : Our-business', '', 1, 1441076946), 
(358, 'en', 'themes', 'Add block', 'Name : Menu Our business', '', 1, 1441077012), 
(359, 'en', 'themes', 'Update position of block', 'reset position all block', '', 1, 1441077095), 
(360, 'en', 'upload', 'Delete file', 'uploads/our-business/images397497_ship_03.jpg', '', 1, 1441077592), 
(361, 'en', 'upload', 'Delete file', 'uploads/our-business/nguyen-nhan-tau-thuyen-bi-ha.jpg', '', 1, 1441077592), 
(362, 'en', 'upload', 'Delete file', 'uploads/our-business/tau.jpg', '', 1, 1441077600), 
(363, 'en', 'upload', 'Upload file', 'uploads/our-business/untitled-1.png', '', 1, 1441077619), 
(364, 'en', 'upload', 'Upload file', 'uploads/our-business/untitled-31.png', '', 1, 1441077619), 
(365, 'en', 'upload', 'Upload file', 'uploads/our-business/untitleeed-1.png', '', 1, 1441077619), 
(366, 'en', 'upload', 'Delete file', 'uploads/our-business/untitleeed-1.png', '', 1, 1441077732), 
(367, 'en', 'upload', 'Upload file', 'uploads/our-business/untitlessdd-1.png', '', 1, 1441077742), 
(368, 'en', 'our-business', 'Add a new article', 'trung nghĩa www', '', 1, 1441078122), 
(369, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441079189), 
(370, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441080993), 
(371, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441082797), 
(372, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441082925), 
(373, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441089486), 
(374, 'en', 'news', 'Add a new article', 'Hotgirl vạn người mê Tâm Tít', '', 1, 1441092399), 
(375, 'en', 'news', 'Delete article', 'Hotgirl Tâm Tít vạn người mê', '', 1, 1441092418), 
(376, 'en', 'modules', 'Order module: our-business', '18 -> 3', '', 1, 1441095260), 
(377, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_repair.png', '', 1, 1441095296), 
(378, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_service.png', '', 1, 1441095297), 
(379, 'en', 'upload', 'Upload file', 'uploads/our-business/ship_supply.png', '', 1, 1441095297), 
(380, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441100265), 
(381, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441102069), 
(382, 'en', 'upload', 'Delete file', 'uploads/logo.png', '', 1, 1441103604), 
(383, 'en', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1441103642), 
(384, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441103652), 
(385, 'en', 'login', '[nhannh] Login', ' Client IP:14.169.129.151', '', 0, 1441103961), 
(386, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441105454), 
(387, 'en', 'login', '[nhannh] Leave Administration', ' Client IP:14.169.129.151', '', 0, 1441106555), 
(388, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441106569), 
(389, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441106584), 
(390, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441107228), 
(391, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.230.61', '', 0, 1441154850), 
(392, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.230.61', '', 0, 1441176972), 
(393, 'en', 'themes', 'Edit block', 'Name : INFORMATION', '', 2, 1441177284), 
(394, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441177514), 
(395, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441177566), 
(396, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441178033), 
(397, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441179352), 
(398, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441186825), 
(399, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441186903), 
(400, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441187114), 
(401, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441187287), 
(402, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441187403), 
(403, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441187468), 
(404, 'en', 'themes', 'Edit block', 'Name : Contact now', '', 2, 1441187560), 
(405, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441188658), 
(406, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441188719), 
(407, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441189936), 
(408, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441190022), 
(409, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441190161), 
(410, 'en', 'upload', 'Upload file', 'uploads/call60.png', '', 2, 1441191297), 
(411, 'en', 'upload', 'Upload file', 'uploads/email103.png', '', 2, 1441191297), 
(412, 'en', 'upload', 'Upload file', 'uploads/home173.png', '', 2, 1441191298), 
(413, 'en', 'upload', 'Upload file', 'uploads/iphone26.png', '', 2, 1441191298), 
(414, 'en', 'upload', 'Upload file', 'uploads/paper6.png', '', 2, 1441191298), 
(415, 'en', 'upload', 'Upload file', 'uploads/pin66.png', '', 2, 1441191298), 
(416, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191306), 
(417, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191342), 
(418, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191499), 
(419, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191547), 
(420, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191756), 
(421, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191790), 
(422, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441191948), 
(423, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441192073), 
(424, 'en', 'upload', 'Upload file', 'uploads/web58.png', '', 2, 1441192273), 
(425, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441192679), 
(426, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441192994), 
(427, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441193220), 
(428, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441193386), 
(429, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441193843), 
(430, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441193886), 
(431, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441193926), 
(432, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441194379), 
(433, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.230.61', '', 0, 1441205410), 
(434, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441205610), 
(435, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 2, 1441206039), 
(436, 'en', 'login', '[admin] Login', ' Client IP:183.80.72.91', '', 0, 1441206283), 
(437, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441206389), 
(438, 'en', 'support', 'Sửa nhân viên', 'supportid 1', '', 2, 1441206736), 
(439, 'en', 'support', 'Sửa nhân viên', 'supportid 1', '', 2, 1441206793), 
(440, 'en', 'support', 'Sửa nhân viên', 'supportid 2', '', 2, 1441206867), 
(441, 'en', 'support', 'Sửa nhóm nhân viên', 'nsupportid 1', '', 2, 1441206887), 
(442, 'en', 'support', 'Thêm nhóm nhân viên', ' ', '', 2, 1441206900), 
(443, 'en', 'support', 'Thêm nhân viên', ' ', '', 2, 1441206960), 
(444, 'en', 'support', 'Sửa nhân viên', 'supportid 2', '', 2, 1441206971), 
(445, 'en', 'support', 'Sửa nhân viên', 'supportid 2', '', 2, 1441207090), 
(446, 'en', 'support', 'Sửa nhân viên', 'supportid 3', '', 2, 1441207100), 
(447, 'en', 'news', 'Delete topics and articles', 'Tin giải trí', '', 2, 1441207330), 
(448, 'en', 'news', 'Delete topics and articles', 'Tin tổng hợp', '', 2, 1441207333), 
(449, 'en', 'news', 'Delete topics and articles', 'Tin công ty', '', 2, 1441207336), 
(450, 'en', 'news', 'Add categories', 'News', '', 2, 1441207346), 
(451, 'en', 'our-business', 'Delete article', 'trung nghĩa www', '', 2, 1441207384), 
(452, 'en', 'our-business', 'Delete article', 'Provision', '', 2, 1441207386), 
(453, 'en', 'our-business', 'Add a new article', 'trung nghĩa - cấm xoá Nhân e.hehe', '', 1, 1441207527), 
(454, 'en', 'our-business', 'Add a new article', 'Provision', '', 2, 1441207605), 
(455, 'en', 'our-business', 'Edit article', 'trung nghĩa - cấm xoá Nhân e.hehe', '', 1, 1441207673), 
(456, 'en', 'our-business', 'Edit article', 'Provision', '', 2, 1441208649), 
(457, 'en', 'our-business', 'Edit article', 'Provision', '', 2, 1441208702), 
(458, 'en', 'our-business', 'Add a new article', 'Electrical store', '', 2, 1441208857), 
(459, 'en', 'news', 'Add categories', 'Events', '', 2, 1441208947), 
(460, 'en', 'our-business', 'Add a new article', 'sdfs', '', 1, 1441209015), 
(461, 'en', 'our-business', 'Delete article', 'sdfs', '', 1, 1441209047), 
(462, 'en', 'our-business', 'Add a new article', 'dfsdf', '', 1, 1441209432), 
(463, 'en', 'our-business', 'Delete article', 'dfsdf', '', 1, 1441209451), 
(464, 'en', 'our-business', 'Add a new article', 'sdfs', '', 1, 1441209525), 
(465, 'en', 'our-business', 'Delete article', 'sdfs', '', 1, 1441209532), 
(466, 'en', 'our-business', 'Delete article', 'trung nghĩa - cấm xoá Nhân e.hehe', '', 1, 1441209610), 
(467, 'en', 'upload', 'Delete file', 'uploads/news/2015_09/img-4193-1371951689294.jpg', '', 2, 1441209792), 
(468, 'en', 'upload', 'Delete file', 'uploads/news/2015_09/images.jpg', '', 2, 1441209792), 
(469, 'en', 'upload', 'Delete file', 'uploads/news/2015_09/images-1.jpg', '', 2, 1441209792), 
(470, 'en', 'upload', 'Delete file', 'uploads/news/2015_09/hinh-anh-hot-girl-tam-tit-2.jpg', '', 2, 1441209792), 
(471, 'en', 'upload', 'Delete file', 'uploads/news/2015_09/dong-nhi9.jpg', '', 2, 1441209792), 
(472, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/viking-pic-300x199.jpg', '', 2, 1441209799), 
(473, 'en', 'news', 'Add a new article', 'VIKING Moves to Expand Australasian Activities', '', 2, 1441209833), 
(474, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/viking-300x200.jpg', '', 2, 1441209917), 
(475, 'en', 'news', 'Add a new article', 'Viking acquires hook retrofit leader', '', 2, 1441209938), 
(476, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/paper-ships-300x199.jpg', '', 2, 1441209974), 
(477, 'en', 'news', 'Add a new article', 'Nautilus comments on research that says people who work longer hours are at risk of stroke', '', 2, 1441210036), 
(478, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441244592), 
(479, 'en', 'themes', 'Add block', 'Name : ho tro', '', 1, 1441246929), 
(480, 'en', 'our-business', 'Edit article', 'Electrical store', '', 1, 1441248792), 
(481, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441254804), 
(482, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441262745), 
(483, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441262795), 
(484, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441264598), 
(485, 'en', 'contact', 'log_edit_row', 'id: 1 Consumer Care Division', '', 1, 1441266124), 
(486, 'en', 'contact', 'log_edit_row', 'id: 2 Technical Department', '', 1, 1441266556), 
(487, 'en', 'login', '[nhannh] Login', ' Client IP:14.169.129.151', '', 0, 1441271436), 
(488, 'en', 'our-business', 'Edit article', 'Electrical store', '', 2, 1441272221), 
(489, 'en', 'our-business', 'Edit article', 'Electrical store', '', 1, 1441274523), 
(490, 'en', 'our-business', 'Edit article', 'Electrical store', '', 1, 1441275157), 
(491, 'en', 'our-business', 'Edit article', 'Provision', '', 1, 1441275169), 
(492, 'en', 'our-business', 'Add a new article', 'sdfsd', '', 1, 1441277299), 
(493, 'en', 'our-business', 'Delete article', 'sdfsd', '', 1, 1441277314), 
(494, 'en', 'our-business', 'Edit article', 'Electrical store', '', 1, 1441277345), 
(495, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.230.61', '', 0, 1441288806), 
(496, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441288941), 
(497, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441288993), 
(498, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1441289308), 
(499, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441291083), 
(500, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441291519), 
(501, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441291803), 
(502, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441291986), 
(503, 'en', 'login', '[admin] Login', ' Client IP:183.80.72.91', '', 0, 1441295670), 
(504, 'en', 'our-business', 'Edit article', 'Provision', '', 1, 1441298454), 
(505, 'en', 'our-business', 'Edit article', 'Provision', '', 1, 1441298495), 
(506, 'en', 'login', '[admin] Login', ' Client IP:::1', '', 0, 1441315967), 
(507, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441315982), 
(508, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 1, 1441316733), 
(509, 'en', 'themes', 'Add block', 'Name : Contact Header', '', 1, 1441318309), 
(510, 'en', 'upload', 'Delete file', 'uploads/logo.png', '', 1, 1441318988), 
(511, 'en', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1441319008), 
(512, 'en', 'themes', 'Edit block', 'Name : Welcom', '', 1, 1441321601), 
(513, 'en', 'themes', 'Edit block', 'Name : Welcom', '', 1, 1441322075), 
(514, 'en', 'modules', 'Delete module \"our-business\"', '', '', 1, 1441323560), 
(515, 'en', 'modules', 'Add virtual module supplies', '', '', 1, 1441323651), 
(516, 'en', 'modules', 'Setup new module supplies', '', '', 1, 1441323656), 
(517, 'en', 'modules', 'Edit modules &ldquo;supplies&rdquo;', '', '', 1, 1441323672), 
(518, 'en', 'supplies', 'Add categories', 'Supplies', '', 1, 1441323693), 
(519, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/1-141154394130.jpg', '', 1, 1441324016), 
(520, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/3-141154394152.jpg', '', 1, 1441324016), 
(521, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/4-141154394153.jpg', '', 1, 1441324017), 
(522, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/5-141154394144.jpg', '', 1, 1441324017), 
(523, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/6-14137853959.jpg', '', 1, 1441324018), 
(524, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/6-141154400540.jpg', '', 1, 1441324018), 
(525, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/7-14137854142.jpg', '', 1, 1441324019), 
(526, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/8-14137854309.jpg', '', 1, 1441324019), 
(527, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/cap-hang-phao-2-14133477251.jpg', '', 1, 1441324022), 
(528, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/dsc03333-14138747252.jpg', '', 1, 1441324024), 
(529, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/moi.jpg', '', 1, 1441324025), 
(530, 'en', 'supplies', 'Add a new article', 'Provision', '', 1, 1441324131), 
(531, 'en', 'supplies', 'Add a new article', 'Pipe Valve', '', 1, 1441324177), 
(532, 'en', 'supplies', 'Add a new article', 'Electrical store', '', 1, 1441324206), 
(533, 'en', 'supplies', 'Add a new article', 'Rubber Packing', '', 1, 1441324237), 
(534, 'en', 'supplies', 'Add a new article', 'Deck Enginer Store', '', 1, 1441324266), 
(535, 'en', 'supplies', 'Add a new article', 'JIS air pipe vent heads', '', 1, 1441324291), 
(536, 'en', 'supplies', 'Add a new article', 'Safety Equipment', '', 1, 1441324317), 
(537, 'en', 'supplies', 'Add a new article', 'Safety Equipment', '', 1, 1441324414), 
(538, 'en', 'supplies', 'Delete article', 'Safety Equipment', '', 1, 1441324427), 
(539, 'en', 'supplies', 'Add a new article', 'Charts Publications', '', 1, 1441324454), 
(540, 'en', 'supplies', 'Add a new article', 'Oils, lubricants', '', 1, 1441324477), 
(541, 'en', 'supplies', 'Add a new article', 'Paints and Chemicals', '', 1, 1441324501), 
(542, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441324567), 
(543, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1441324590), 
(544, 'en', 'modules', 'Order module: supplies', '18 -> 3', '', 1, 1441324601), 
(545, 'en', 'themes', 'Add block', 'Name : Supplies', '', 1, 1441324728), 
(546, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441332504), 
(547, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/moi.jpg', '', 1, 1441334174), 
(548, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/dsc03333-14138747252.jpg', '', 1, 1441334174), 
(549, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/cap-hang-phao-2-14133477251.jpg', '', 1, 1441334174), 
(550, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/8-14137854309.jpg', '', 1, 1441334174), 
(551, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/7-14137854142.jpg', '', 1, 1441334174), 
(552, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/6-141154400540.jpg', '', 1, 1441334174), 
(553, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/6-14137853959.jpg', '', 1, 1441334174), 
(554, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/5-141154394144.jpg', '', 1, 1441334174), 
(555, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/3-141154394152.jpg', '', 1, 1441334174), 
(556, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/4-141154394153.jpg', '', 1, 1441334174), 
(557, 'en', 'upload', 'Delete file', 'uploads/supplies/2015_09/1-141154394130.jpg', '', 1, 1441334174), 
(558, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/1-141154394130-1.jpg', '', 1, 1441334222), 
(559, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/500x300_spirit.jpeg', '', 1, 1441334222), 
(560, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/anh.jpg', '', 1, 1441334223), 
(561, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/images.jpg', '', 1, 1441334223), 
(562, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/leisure.jpg', '', 1, 1441334223), 
(563, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/moi.jpg', '', 1, 1441334224), 
(564, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/images-3.jpg', '', 1, 1441334308), 
(565, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/leisure_1.jpg', '', 1, 1441334308), 
(566, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/ship.jpg', '', 1, 1441334308), 
(567, 'en', 'supplies', 'Edit article', 'Oils, lubricants', '', 1, 1441334354), 
(568, 'en', 'supplies', 'Edit article', 'Paints and Chemicals', '', 1, 1441334369), 
(569, 'en', 'supplies', 'Edit article', 'Charts Publications', '', 1, 1441334380), 
(570, 'en', 'supplies', 'Edit article', 'Safety Equipment', '', 1, 1441334393), 
(571, 'en', 'supplies', 'Edit article', 'Rubber Packing', '', 1, 1441334409), 
(572, 'en', 'supplies', 'Edit article', 'Electrical store', '', 1, 1441334423), 
(573, 'en', 'supplies', 'Edit article', 'Pipe Valve', '', 1, 1441334436), 
(574, 'en', 'supplies', 'Edit article', 'Provision', '', 1, 1441334452), 
(575, 'en', 'supplies', 'Edit article', 'JIS air pipe vent heads', '', 1, 1441334478), 
(576, 'en', 'supplies', 'Edit article', 'Electrical store', '', 1, 1441334513), 
(577, 'en', 'supplies', 'Edit article', 'Deck Enginer Store', '', 1, 1441334539), 
(578, 'en', 'news', 'log_add_blockcat', ' ', '', 1, 1441335074), 
(579, 'en', 'news', 'Edit article', 'Nautilus comments on research that says people who work longer hours are at risk of stroke', '', 1, 1441335135), 
(580, 'en', 'news', 'Edit article', 'Viking acquires hook retrofit leader', '', 1, 1441335153), 
(581, 'en', 'news', 'Edit article', 'Nautilus comments on research that says people who work longer hours are at risk of stroke', '', 1, 1441335186), 
(582, 'en', 'news', 'Edit article', 'VIKING Moves to Expand Australasian Activities', '', 1, 1441335197), 
(583, 'en', 'upload', 'Upload file', 'uploads/news/2015_09/_85358853_85358852.jpg', '', 1, 1441335302), 
(584, 'en', 'news', 'Add a new article', 'Hungary migrant stand-off continues', '', 1, 1441335327), 
(585, 'en', 'themes', 'Add block', 'Name : News', '', 1, 1441335475), 
(586, 'en', 'themes', 'Edit block', 'Name : Our business', '', 1, 1441343943), 
(587, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441344384), 
(588, 'en', 'login', '[admin] Login', ' Client IP:::1', '', 0, 1441357574), 
(589, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441357600), 
(590, 'en', 'supplies', 'Edit article', 'Oils, lubricants', '', 1, 1441358432), 
(591, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1441365383), 
(592, 'en', 'themes', 'Add block', 'Name : Supplies', '', 1, 1441365911), 
(593, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441366750), 
(594, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 1, 1441368165), 
(595, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441431560), 
(596, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 1, 1441431715), 
(597, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441590167), 
(598, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441590180), 
(599, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441590750), 
(600, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441590797), 
(601, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441590842), 
(602, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441591171), 
(603, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441591323), 
(604, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441591356), 
(605, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/2-14137853315.jpg', '', 1, 1441592929), 
(606, 'en', 'login', '[nhannh] Login', ' Client IP:14.169.129.151', '', 0, 1441597950), 
(607, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441600078), 
(608, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441600327), 
(609, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1441600347), 
(610, 'en', 'supplies', 'Edit article', 'Provision', '', 2, 1441600952), 
(611, 'en', 'login', '[admin] Login', ' Client IP:14.169.129.151', '', 0, 1441607705), 
(612, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441609829), 
(613, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441611632), 
(614, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441613436), 
(615, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441615240), 
(616, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441617045), 
(617, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441617484), 
(618, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441618433), 
(619, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441620236), 
(620, 'en', 'login', '[admin] Login', ' Client IP:14.169.249.37', '', 0, 1441860299), 
(621, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441860310), 
(622, 'en', 'about', 'Edit', 'ID: 1', '', 1, 1441860644), 
(623, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441861972), 
(624, 'en', 'login', '[admin] Login', ' Client IP:14.169.249.37', '', 0, 1441935675), 
(625, 'en', 'themes', 'Add block', 'Name : Statistics', '', 1, 1441935863), 
(626, 'en', 'themes', 'Edit block', 'Name : Statistics', '', 1, 1441936038), 
(627, 'en', 'themes', 'Add block', 'Name : Support contact', '', 1, 1441937084), 
(628, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 1, 1441937164), 
(629, 'en', 'supplies', 'Add categories', 'Ship repair', '', 1, 1441939233), 
(630, 'en', 'supplies', 'Add categories', 'Ship service', '', 1, 1441939256), 
(631, 'en', 'supplies', 'Add categories', 'Deck store', '', 1, 1441943090), 
(632, 'en', 'supplies', 'Add a new article', 'Pipe', '', 1, 1441943121), 
(633, 'en', 'supplies', 'Add a new article', 'Valve', '', 1, 1441943135), 
(634, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1441943454), 
(635, 'en', 'themes', 'Edit block', 'Name : Menu Supplies', '', 1, 1441943537), 
(636, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1441943546), 
(637, 'en', 'login', '[admin] Login', ' Client IP:14.169.249.37', '', 0, 1441945020), 
(638, 'en', 'supplies', 'Add a new article', 'Dfs', '', 1, 1441945038), 
(639, 'en', 'supplies', 'Delete article', 'Dfs', '', 1, 1441945052), 
(640, 'en', 'login', '[nhannh] Login', ' Client IP:14.169.249.37', '', 0, 1442024313), 
(641, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/ship-supply-banner-1.jpg', '', 2, 1442024748), 
(642, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/ship-supply-banner-2.jpg', '', 2, 1442024749), 
(643, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/ship-supply-banner-3.jpg', '', 2, 1442024749), 
(644, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/ship-supply-banner-4.jpg', '', 2, 1442024749), 
(645, 'en', 'slider', 'Edit categories', 'banner-4', '', 2, 1442024760), 
(646, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1442024774), 
(647, 'en', 'slider', 'Edit categories', 'banner-2', '', 2, 1442024785), 
(648, 'en', 'slider', 'Edit categories', 'banner-1', '', 2, 1442024794), 
(649, 'en', 'slider', 'Edit categories', 'banner-7', '', 2, 1442024891), 
(650, 'en', 'slider', 'Edit categories', 'banner-6', '', 2, 1442024908), 
(651, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1442024917), 
(652, 'en', 'login', '[admin] Login', ' Client IP:14.169.249.37', '', 0, 1442119190), 
(653, 'en', 'login', '[nhannh] Login', ' Client IP:116.102.244.65', '', 0, 1442155889), 
(654, 'en', 'users', 'log_edit_user', 'userid 2', '', 2, 1442155952), 
(655, 'en', 'login', '[web24] Leave Administration', ' Client IP:116.102.244.65', '', 0, 1442155956), 
(656, 'en', 'login', '[web24] Login', ' Client IP:116.102.244.65', '', 0, 1442155970), 
(657, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 2, 1442157166), 
(658, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 2, 1442157301), 
(659, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 2, 1442157388), 
(660, 'en', 'login', '[web24] Login', ' Client IP:14.169.249.37', '', 0, 1442194747), 
(661, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442194777), 
(662, 'en', 'upload', 'Upload file', 'uploads/about/blue-ocean-about-1.jpg', '', 2, 1442194862), 
(663, 'en', 'upload', 'Upload file', 'uploads/about/blue-ocean-about-2.jpg', '', 2, 1442194862), 
(664, 'en', 'upload', 'Upload file', 'uploads/about/blue-ocean-about-3.jpg', '', 2, 1442194863), 
(665, 'en', 'upload', 'Upload file', 'uploads/about/blue-ocean-about-4.jpg', '', 2, 1442194863), 
(666, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442194878), 
(667, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442194922), 
(668, 'en', 'login', '[admin] Login', ' Client IP:14.169.249.37', '', 0, 1442197408), 
(669, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442197420), 
(670, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442197992), 
(671, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442198150), 
(672, 'en', 'supplies', 'Delete topics and articles', 'Ship service', '', 2, 1442201899), 
(673, 'en', 'supplies', 'Delete topics and articles', 'Ship repair', '', 2, 1442201913), 
(674, 'en', 'login', '[admin] Leave Administration', ' Client IP:14.169.249.37', '', 0, 1442203477), 
(675, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442204182), 
(676, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442204281), 
(677, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442204656), 
(678, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442204783), 
(679, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1442204826), 
(680, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442392783), 
(681, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442549962), 
(682, 'en', 'users', 'log_edit_user', 'userid 2', '', 2, 1442549983), 
(683, 'en', 'supplies', 'Add categories', 'General repairs', '', 2, 1442551665), 
(684, 'en', 'supplies', 'Add categories', 'Other services', '', 2, 1442551929), 
(685, 'en', 'supplies', 'Add a new article', 'Deck &amp; engine store', '', 2, 1442552579), 
(686, 'en', 'supplies', 'Delete article', 'Pipe', '', 2, 1442552623), 
(687, 'en', 'supplies', 'Delete article', 'Valve', '', 2, 1442552627), 
(688, 'en', 'supplies', 'Delete topics and articles', 'Deck store', '', 2, 1442552633), 
(689, 'en', 'supplies', 'Edit article', 'Deck &amp; engine store', '', 2, 1442552712), 
(690, 'en', 'supplies', 'Edit article', 'Deck &amp; engine store', '', 2, 1442552737), 
(691, 'en', 'supplies', 'Edit article', 'Deck &amp; engine store', '', 2, 1442552800), 
(692, 'en', 'supplies', 'Edit article', 'Deck &amp; engine store', '', 2, 1442552841), 
(693, 'en', 'supplies', 'Delete article', 'Engineer store', '', 2, 1442552853), 
(694, 'en', 'supplies', 'Edit article', 'Oils - Lubricants', '', 2, 1442553157), 
(695, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442558808), 
(696, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442630879), 
(697, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442631015), 
(698, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/ship-supply-general-repairs.jpg', '', 2, 1442632681), 
(699, 'en', 'upload', 'Upload file', 'uploads/supplies/2015_09/ship-supply-other-services.jpg', '', 2, 1442632681), 
(700, 'en', 'supplies', 'Add categories', 'Technical supply', '', 2, 1442633666), 
(701, 'en', 'supplies', 'Edit article', 'Cabin and galley store', '', 2, 1442633976), 
(702, 'en', 'supplies', 'Edit article', 'Charts Publications', '', 2, 1442634001), 
(703, 'en', 'supplies', 'Edit article', 'Deck &amp; engine store', '', 2, 1442634165), 
(704, 'en', 'supplies', 'Edit article', 'Cabin and galley store', '', 2, 1442634180), 
(705, 'en', 'supplies', 'Edit article', 'Charts Publications', '', 2, 1442634193), 
(706, 'en', 'supplies', 'Edit article', 'Paints - Chemicals', '', 2, 1442634251), 
(707, 'en', 'supplies', 'Edit article', 'Oils - Lubricants', '', 2, 1442634275), 
(708, 'en', 'supplies', 'Edit article', 'Electrical store', '', 2, 1442634290), 
(709, 'en', 'supplies', 'Edit article', 'Safety Equipment', '', 2, 1442634333), 
(710, 'en', 'supplies', 'Add a new article', 'Cabin Stores', '', 2, 1442635112), 
(711, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1442635215), 
(712, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1442635259), 
(713, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1442635319), 
(714, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1442635377), 
(715, 'en', 'supplies', 'Edit article', 'Galley Stores', '', 2, 1442635432), 
(716, 'en', 'supplies', 'Edit article', 'Galley Stores', '', 2, 1442635468), 
(717, 'en', 'supplies', 'Add a new article', 'Deck Stores', '', 2, 1442635584), 
(718, 'en', 'supplies', 'Edit article', 'Deck Stores', '', 2, 1442635603), 
(719, 'en', 'supplies', 'Edit article', 'Marine Paints &amp; Chemicals', '', 2, 1442635692), 
(720, 'en', 'supplies', 'Edit article', 'Safety Stores &amp; Anti-Piracy Items', '', 2, 1442635758), 
(721, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1442635823), 
(722, 'en', 'supplies', 'Edit article', 'Engine Stores', '', 2, 1442635876), 
(723, 'en', 'supplies', 'log_declined_content', 'listid: 14, 16, 19', '', 2, 1442635942), 
(724, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442635974), 
(725, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636310), 
(726, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636361), 
(727, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636386), 
(728, 'en', 'supplies', 'Add a new article', 'Provision supply', '', 2, 1442636458), 
(729, 'en', 'supplies', 'Delete article', 'Provision supply', '', 2, 1442636475), 
(730, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636495), 
(731, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636512), 
(732, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442636622), 
(733, 'en', 'modules', 'Add virtual module port_we_serv', '', '', 2, 1442638004), 
(734, 'en', 'modules', 'Setup new module port-we-serv', '', '', 2, 1442638033), 
(735, 'en', 'modules', 'Edit modules &ldquo;port-we-serv&rdquo;', '', '', 2, 1442638081), 
(736, 'en', 'modules', 'Order module: port-we-serv', '19 -> 4', '', 2, 1442638095), 
(737, 'en', 'modules', 'Edit modules &ldquo;port-we-serv&rdquo;', '', '', 2, 1442638213), 
(738, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 2, 1442638302), 
(739, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442638336), 
(740, 'en', 'port-we-serv', 'Add', ' ', '', 2, 1442638343), 
(741, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442638345), 
(742, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 2, 1442638358), 
(743, 'en', 'modules', 'Delete module \"port-we-serv\"', '', '', 2, 1442638822), 
(744, 'en', 'modules', 'Add virtual module port_we_serv', '', '', 2, 1442638839), 
(745, 'en', 'modules', 'Setup new module port-we-serv', '', '', 2, 1442638842), 
(746, 'en', 'modules', 'Edit modules &ldquo;port-we-serv&rdquo;', '', '', 2, 1442638858), 
(747, 'en', 'modules', 'Order module: port-we-serv', '19 -> 4', '', 2, 1442638864), 
(748, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 2, 1442638874), 
(749, 'en', 'port-we-serv', 'Add', ' ', '', 2, 1442638892), 
(750, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442639481), 
(751, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442639817), 
(752, 'en', 'login', '[admin] Login', ' Client IP:1.52.208.94', '', 0, 1442731576), 
(753, 'en', 'upload', 'Upload file', 'uploads/logo_1.png', '', 1, 1442731857), 
(754, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 1, 1442731958), 
(755, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442810300), 
(756, 'en', 'upload', 'Upload file', 'uploads/logo_moi.png', '', 1, 1442810378), 
(757, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 1, 1442810566), 
(758, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 1, 1442811265), 
(759, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1442811563), 
(760, 'en', 'about', 'Edit', 'ID: 1', '', 1, 1442812561), 
(761, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442820378), 
(762, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 1, 1442822717), 
(763, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1442824198), 
(764, 'en', 'themes', 'Edit block', 'Name : Menu Site', '', 1, 1442824881), 
(765, 'en', 'modules', 'Order module: port-we-serv', '19 -> 3', '', 1, 1442824910), 
(766, 'en', 'modules', 'Order module: port-we-serv', '19 -> 4', '', 1, 1442824926), 
(767, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442827244), 
(768, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1442827362), 
(769, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 1, 1442827448), 
(770, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442827589), 
(771, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442827615), 
(772, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442827724), 
(773, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442827759), 
(774, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442828107), 
(775, 'en', 'supplies', 'Edit article', 'Rubber packing', '', 1, 1442828221), 
(776, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442829650), 
(777, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442894437), 
(778, 'en', 'supplies', 'log_declined_content', 'listid: 14', '', 2, 1442894460), 
(779, 'en', 'upload', 'Create', 'uploads/supplies/provision', '', 2, 1442894879), 
(780, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-1.jpg', '', 2, 1442894899), 
(781, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-2.jpg', '', 2, 1442894899), 
(782, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-3.jpg', '', 2, 1442894899), 
(783, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-4.jpg', '', 2, 1442894900), 
(784, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-5.jpg', '', 2, 1442894900), 
(785, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-6.jpg', '', 2, 1442894900), 
(786, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-7.jpg', '', 2, 1442894900), 
(787, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-8.jpg', '', 2, 1442894901), 
(788, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-9.jpg', '', 2, 1442894902), 
(789, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-10.jpg', '', 2, 1442894902), 
(790, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-11.jpg', '', 2, 1442894903), 
(791, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-12.jpg', '', 2, 1442894904), 
(792, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-13.jpg', '', 2, 1442894904), 
(793, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-14.jpg', '', 2, 1442894904), 
(794, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-14.jpg', '', 2, 1442895044), 
(795, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-12.jpg', '', 2, 1442895044), 
(796, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-13.jpg', '', 2, 1442895044), 
(797, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-10.jpg', '', 2, 1442895044), 
(798, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-11.jpg', '', 2, 1442895044), 
(799, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-8.jpg', '', 2, 1442895044), 
(800, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-9.jpg', '', 2, 1442895044), 
(801, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-7.jpg', '', 2, 1442895044), 
(802, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-3.jpg', '', 2, 1442895044), 
(803, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-4.jpg', '', 2, 1442895044), 
(804, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-5.jpg', '', 2, 1442895044), 
(805, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-6.jpg', '', 2, 1442895044), 
(806, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-1.jpg', '', 2, 1442895044), 
(807, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/blue-ocean-marine-service-ship-supply-provision-2.jpg', '', 2, 1442895044), 
(808, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-1.jpg', '', 2, 1442895049), 
(809, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-2.jpg', '', 2, 1442895049), 
(810, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-3.jpg', '', 2, 1442895050), 
(811, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-4.jpg', '', 2, 1442895050), 
(812, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-5.jpg', '', 2, 1442895050), 
(813, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-6.jpg', '', 2, 1442895050), 
(814, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-7.jpg', '', 2, 1442895050), 
(815, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-8.jpg', '', 2, 1442895051), 
(816, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-9.jpg', '', 2, 1442895051), 
(817, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-10.jpg', '', 2, 1442895051), 
(818, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-11.jpg', '', 2, 1442895051), 
(819, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-12.jpg', '', 2, 1442895052), 
(820, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-13.jpg', '', 2, 1442895052), 
(821, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-14.jpg', '', 2, 1442895053), 
(822, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442895181), 
(823, 'en', 'upload', 'Create', 'uploads/supplies/bridge', '', 2, 1442895394), 
(824, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-1.jpg', '', 2, 1442895405), 
(825, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-2.jpg', '', 2, 1442895405), 
(826, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-3.jpg', '', 2, 1442895406), 
(827, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-4.jpg', '', 2, 1442895406), 
(828, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-5.jpg', '', 2, 1442895407), 
(829, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-6.jpg', '', 2, 1442895407), 
(830, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-7.jpg', '', 2, 1442895407), 
(831, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-8.jpg', '', 2, 1442895408), 
(832, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-9.jpg', '', 2, 1442895408), 
(833, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1442895475), 
(834, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442895503), 
(835, 'en', 'upload', 'Create', 'uploads/supplies/cabin-stores', '', 2, 1442898239), 
(836, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-1.jpg', '', 2, 1442898250), 
(837, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-2.jpg', '', 2, 1442898251), 
(838, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-3.jpg', '', 2, 1442898251), 
(839, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-4.jpg', '', 2, 1442898252), 
(840, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-5.jpg', '', 2, 1442898252), 
(841, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-6.jpg', '', 2, 1442898253), 
(842, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-7.jpg', '', 2, 1442898253), 
(843, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-8.jpg', '', 2, 1442898254), 
(844, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-9.jpg', '', 2, 1442898255), 
(845, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-10.jpg', '', 2, 1442898255), 
(846, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-11.jpg', '', 2, 1442898256), 
(847, 'en', 'upload', 'Upload file', 'uploads/supplies/cabin-stores/ship-supply-cabin-stores-12.jpg', '', 2, 1442898256), 
(848, 'en', 'supplies', 'Edit article', 'Cabin Stores', '', 2, 1442898324), 
(849, 'en', 'supplies', 'Edit article', 'Cabin Stores', '', 2, 1442898350), 
(850, 'en', 'supplies', 'Edit article', 'Marine Paints &amp; Chemicals', '', 2, 1442898489), 
(851, 'en', 'upload', 'Create', 'uploads/supplies/galley-stores', '', 2, 1442898607), 
(852, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 2, 1442898620), 
(853, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-2.jpg', '', 2, 1442898621), 
(854, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-3.jpg', '', 2, 1442898621), 
(855, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-4.jpg', '', 2, 1442898621), 
(856, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-5.jpg', '', 2, 1442898621), 
(857, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-6.jpg', '', 2, 1442898621), 
(858, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-7.jpg', '', 2, 1442898622), 
(859, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-8.jpg', '', 2, 1442898622), 
(860, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-9.jpg', '', 2, 1442898622), 
(861, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-10.jpg', '', 2, 1442898622), 
(862, 'en', 'supplies', 'Edit article', 'Galley Stores', '', 2, 1442898692), 
(863, 'en', 'upload', 'Create', 'uploads/supplies/marine-paints-chemicals', '', 2, 1442899008), 
(864, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', '', 2, 1442899020), 
(865, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg', '', 2, 1442899020), 
(866, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg', '', 2, 1442899021), 
(867, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg', '', 2, 1442899021), 
(868, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg', '', 2, 1442899021), 
(869, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg', '', 2, 1442899021), 
(870, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg', '', 2, 1442899021), 
(871, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg', '', 2, 1442899022), 
(872, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg', '', 2, 1442899022), 
(873, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg', '', 2, 1442899022), 
(874, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg', '', 2, 1442899022), 
(875, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', '', 2, 1442899022), 
(876, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-13.jpg', '', 2, 1442899022), 
(877, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-14.jpg', '', 2, 1442899023), 
(878, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-15.jpg', '', 2, 1442899023), 
(879, 'en', 'supplies', 'Edit article', 'Marine Paints &amp; Chemicals', '', 2, 1442899118), 
(880, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442900990), 
(881, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901312), 
(882, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901373), 
(883, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901426), 
(884, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901448), 
(885, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901464), 
(886, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901590), 
(887, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901692), 
(888, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901712), 
(889, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901821), 
(890, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442901973), 
(891, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442902085), 
(892, 'en', 'upload', 'Upload file', 'uploads/port-we-serv/ship-supply-port-we-serv.jpg', '', 2, 1442902121), 
(893, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442902145), 
(894, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442902217), 
(895, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 2, 1442902234), 
(896, 'en', 'upload', 'Create', 'uploads/supplies/electrical-stores', '', 2, 1442904122), 
(897, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1442904131), 
(898, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1442904132), 
(899, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1442904132), 
(900, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1442904132), 
(901, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1442904132), 
(902, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1442904132), 
(903, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1442904133), 
(904, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1442904133), 
(905, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1442904133), 
(906, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1442904133), 
(907, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1442904133), 
(908, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1442904133), 
(909, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', '', 2, 1442904134), 
(910, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-14.jpg', '', 2, 1442904134), 
(911, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-15.jpg', '', 2, 1442904134), 
(912, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-16.jpg', '', 2, 1442904134), 
(913, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-17.jpg', '', 2, 1442904134), 
(914, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-18.jpg', '', 2, 1442904134), 
(915, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-19.jpg', '', 2, 1442904135), 
(916, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-20.jpg', '', 2, 1442904135), 
(917, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-21.jpg', '', 2, 1442904135), 
(918, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-22.jpg', '', 2, 1442904135), 
(919, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-23.jpg', '', 2, 1442904135), 
(920, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-24.jpg', '', 2, 1442904136), 
(921, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1442904307), 
(922, 'en', 'upload', 'Create', 'uploads/supplies/safety-stores', '', 2, 1442904634), 
(923, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-1.jpg', '', 2, 1442904645), 
(924, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-2.jpg', '', 2, 1442904645), 
(925, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-3.jpg', '', 2, 1442904646), 
(926, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-4.jpg', '', 2, 1442904646), 
(927, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-5.jpg', '', 2, 1442904647), 
(928, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-6.jpg', '', 2, 1442904647), 
(929, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-7.jpg', '', 2, 1442904647), 
(930, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-8.jpg', '', 2, 1442904647), 
(931, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-9.jpg', '', 2, 1442904648), 
(932, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-10.jpg', '', 2, 1442904648), 
(933, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-11.jpg', '', 2, 1442904648), 
(934, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-12.jpg', '', 2, 1442904649), 
(935, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-13.jpg', '', 2, 1442904649), 
(936, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-14.jpg', '', 2, 1442904649), 
(937, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-15.jpg', '', 2, 1442904651), 
(938, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-16.jpg', '', 2, 1442904651), 
(939, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-18.jpg', '', 2, 1442904652), 
(940, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-19.jpg', '', 2, 1442904653), 
(941, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-20.jpg', '', 2, 1442904653), 
(942, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-21.jpg', '', 2, 1442904654), 
(943, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-22.jpg', '', 2, 1442904654), 
(944, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-23.jpg', '', 2, 1442904654), 
(945, 'en', 'supplies', 'Edit article', 'Safety Stores &amp; Anti-Piracy Items', '', 2, 1442904806), 
(946, 'en', 'upload', 'Create', 'uploads/supplies/engine-stores', '', 2, 1442905357), 
(947, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg', '', 2, 1442905368), 
(948, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-2.jpg', '', 2, 1442905368), 
(949, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-3.jpg', '', 2, 1442905369), 
(950, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-4.jpg', '', 2, 1442905369), 
(951, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-5.jpg', '', 2, 1442905369), 
(952, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-6.jpg', '', 2, 1442905370), 
(953, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-7.jpg', '', 2, 1442905370), 
(954, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-8.jpg', '', 2, 1442905370), 
(955, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-9.jpg', '', 2, 1442905371), 
(956, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-10.jpg', '', 2, 1442905371), 
(957, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-11.jpg', '', 2, 1442905372), 
(958, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-12.jpg', '', 2, 1442905372), 
(959, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-13.jpg', '', 2, 1442905372), 
(960, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-14.jpg', '', 2, 1442905373), 
(961, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-15.jpg', '', 2, 1442905373), 
(962, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-16.jpg', '', 2, 1442905373), 
(963, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-17.jpg', '', 2, 1442905374), 
(964, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-18.jpg', '', 2, 1442905374), 
(965, 'en', 'supplies', 'Edit article', 'Engine Stores', '', 2, 1442905515), 
(966, 'en', 'upload', 'Create', 'uploads/supplies/deck-stores', '', 2, 1442909017), 
(967, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-2.jpg', '', 2, 1442909023), 
(968, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-3.jpg', '', 2, 1442909024), 
(969, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-4.jpg', '', 2, 1442909025), 
(970, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-5.jpg', '', 2, 1442909025), 
(971, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-6.jpg', '', 2, 1442909026), 
(972, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-7.jpg', '', 2, 1442909026), 
(973, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-8.jpg', '', 2, 1442909026), 
(974, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-9.jpg', '', 2, 1442909026), 
(975, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-10.jpg', '', 2, 1442909027), 
(976, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-11.jpg', '', 2, 1442909027), 
(977, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-12.jpg', '', 2, 1442909027), 
(978, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-13.jpg', '', 2, 1442909028), 
(979, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-14.jpg', '', 2, 1442909028), 
(980, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-15.jpg', '', 2, 1442909028), 
(981, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-16.jpg', '', 2, 1442909029), 
(982, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-17.jpg', '', 2, 1442909029), 
(983, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-18.jpg', '', 2, 1442909029), 
(984, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-19.jpg', '', 2, 1442909030), 
(985, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-20.jpg', '', 2, 1442909030), 
(986, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-21.jpg', '', 2, 1442909031), 
(987, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-22.jpg', '', 2, 1442909031), 
(988, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-23.jpg', '', 2, 1442909031), 
(989, 'en', 'supplies', 'Edit article', 'Deck Stores', '', 2, 1442909151), 
(990, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg', '', 2, 1442909289), 
(991, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg', '', 2, 1442909298), 
(992, 'en', 'supplies', 'Edit article', 'Engine Stores', '', 2, 1442909313), 
(993, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442974557), 
(994, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442974567), 
(995, 'en', 'supplies', 'Edit article', 'Provision supply', '', 1, 1442977175), 
(996, 'en', 'supplies', 'Edit article', 'Cabin Stores', '', 1, 1442977186), 
(997, 'en', 'supplies', 'Edit article', 'Bridge', '', 1, 1442977195), 
(998, 'en', 'supplies', 'Edit article', 'Galley Stores', '', 1, 1442977206), 
(999, 'en', 'supplies', 'Edit article', 'Deck Stores', '', 1, 1442977218), 
(1000, 'en', 'supplies', 'Edit article', 'Marine Paints &amp; Chemicals', '', 1, 1442977230), 
(1001, 'en', 'supplies', 'Edit article', 'Safety Stores &amp; Anti-Piracy Items', '', 1, 1442977243), 
(1002, 'en', 'supplies', 'Edit article', 'Safety Stores &amp; Anti-Piracy Items', '', 1, 1442977255), 
(1003, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 1, 1442977282), 
(1004, 'en', 'supplies', 'Edit article', 'Engine Stores', '', 1, 1442977292), 
(1005, 'en', 'supplies', 'Edit article', 'Oils - Lubricants', '', 1, 1442977304), 
(1006, 'en', 'supplies', 'Edit article', 'Jis air pipe vent heads', '', 1, 1442977318), 
(1007, 'en', 'supplies', 'Edit article', 'Rubber packing', '', 1, 1442977328), 
(1008, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442977589), 
(1009, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1442978000), 
(1010, 'en', 'supplies', 'log_declined_content', 'listid: 14, 16, 19', '', 2, 1442978039), 
(1011, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 2, 1442978840), 
(1012, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 1, 1442979682), 
(1013, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979757), 
(1014, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979768), 
(1015, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979806), 
(1016, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979883), 
(1017, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979912), 
(1018, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442979945), 
(1019, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442980070), 
(1020, 'en', 'themes', 'Edit block', 'Name : --', '', 1, 1442980235), 
(1021, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 2, 1442980570), 
(1022, 'en', 'themes', 'Edit block', 'Name : Supplies', '', 2, 1442980604), 
(1023, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442996223), 
(1024, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1442996302), 
(1025, 'en', 'login', '[admin] Leave Administration', ' Client IP:14.169.191.67', '', 0, 1442996384), 
(1026, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442996508), 
(1027, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442996640), 
(1028, 'en', 'login', '[admin] Leave Administration', ' Client IP:14.169.191.67', '', 0, 1442996654), 
(1029, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442996663), 
(1030, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 2, 1442996986), 
(1031, 'en', 'themes', 'Edit block', 'Name : BLUE OCEAN MARINE SERVICE CO., LTD', '', 2, 1442997068), 
(1032, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1442997138), 
(1033, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1442997222), 
(1034, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1442997319), 
(1035, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 2, 1442997371), 
(1036, 'en', 'login', '[web24] Leave Administration', ' Client IP:14.169.191.67', '', 0, 1442997765), 
(1037, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1442997784), 
(1038, 'en', 'users', 'log_add_user', 'userid 3', '', 1, 1442997838), 
(1039, 'en', 'authors', 'Add an Administrator', 'Username: shipsupply', '', 1, 1442997867), 
(1040, 'en', 'login', '[admin] Leave Administration', ' Client IP:14.169.191.67', '', 0, 1442997873), 
(1041, 'en', 'login', '[shipsupply] Login', ' Client IP:14.169.191.67', '', 0, 1442997889), 
(1042, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:14.169.191.67', '', 0, 1442997894), 
(1043, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1442998077), 
(1044, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1442998200), 
(1045, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1443057822), 
(1046, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1443083330), 
(1047, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 2, 1443083377), 
(1048, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 2, 1443083861), 
(1049, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1443084156), 
(1050, 'en', 'themes', 'Edit block', 'Name : Support', '', 2, 1443084287), 
(1051, 'en', 'themes', 'Edit block', 'Name : Address contact', '', 2, 1443084327), 
(1052, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1443084656), 
(1053, 'en', 'support', 'Sửa nhóm nhân viên', 'nsupportid 2', '', 2, 1443086121), 
(1054, 'en', 'support', 'Thêm nhân viên', ' ', '', 2, 1443086159), 
(1055, 'en', 'support', 'Thêm nhân viên', ' ', '', 2, 1443086212), 
(1056, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 2, 1443086260), 
(1057, 'en', 'login', '[admin] Login', ' Client IP:14.169.191.67', '', 0, 1443232281), 
(1058, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 1, 1443232542), 
(1059, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 1, 1443232603), 
(1060, 'en', 'themes', 'Edit block', 'Name : INFORMATION', '', 1, 1443232703), 
(1061, 'en', 'themes', 'Edit block', 'Name : INFORMATION', '', 1, 1443232720), 
(1062, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 1, 1443233717), 
(1063, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 1, 1443233999), 
(1064, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1443234481), 
(1065, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1443234705), 
(1066, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1443234712), 
(1067, 'en', 'themes', 'Layout setup theme: \"default\"', '', '', 1, 1443234984), 
(1068, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443235008), 
(1069, 'en', 'themes', 'Edit block', 'Name : global html', '', 1, 1443235548), 
(1070, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1443235675), 
(1071, 'en', 'themes', 'Edit block', 'Name : Support contact', '', 1, 1443235820), 
(1072, 'en', 'themes', 'Add block', 'Name : global html', '', 1, 1443236334), 
(1073, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443236811), 
(1074, 'en', 'themes', 'Add block', 'Name : Managing Director', '', 1, 1443236812), 
(1075, 'en', 'themes', 'Add block', 'Name : Deputy Manager', '', 1, 1443236953), 
(1076, 'en', 'themes', 'Add block', 'Name : Purchasing Manager', '', 1, 1443237075), 
(1077, 'en', 'themes', 'Add block', 'Name : Technical Manager', '', 1, 1443237193), 
(1078, 'en', 'themes', 'Add block', 'Name : Chief Account', '', 1, 1443237281), 
(1079, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443238615), 
(1080, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-14.jpg', '', 2, 1443239699), 
(1081, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-11.jpg', '', 2, 1443239699), 
(1082, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-12.jpg', '', 2, 1443239699), 
(1083, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-13.jpg', '', 2, 1443239699), 
(1084, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-7.jpg', '', 2, 1443239699), 
(1085, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-8.jpg', '', 2, 1443239699), 
(1086, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-9.jpg', '', 2, 1443239699), 
(1087, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-10.jpg', '', 2, 1443239699), 
(1088, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-3.jpg', '', 2, 1443239699), 
(1089, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-4.jpg', '', 2, 1443239699), 
(1090, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-5.jpg', '', 2, 1443239699), 
(1091, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-6.jpg', '', 2, 1443239699), 
(1092, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-1.jpg', '', 2, 1443239699), 
(1093, 'en', 'upload', 'Delete file', 'uploads/supplies/provision/ship-supply-provision-2.jpg', '', 2, 1443239699), 
(1094, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-1.jpg', '', 2, 1443239746), 
(1095, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-2.jpg', '', 2, 1443239750), 
(1096, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-3.jpg', '', 2, 1443239752), 
(1097, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-4.jpg', '', 2, 1443239753), 
(1098, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-5.jpg', '', 2, 1443239755), 
(1099, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-6.jpg', '', 2, 1443239756), 
(1100, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-7.jpg', '', 2, 1443239757), 
(1101, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-8.jpg', '', 2, 1443239758), 
(1102, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-9.jpg', '', 2, 1443239759), 
(1103, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-10.jpg', '', 2, 1443239761), 
(1104, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-11.jpg', '', 2, 1443239762), 
(1105, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-12.jpg', '', 2, 1443239763), 
(1106, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-13.jpg', '', 2, 1443239763), 
(1107, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-14.jpg', '', 2, 1443239764), 
(1108, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-15.jpg', '', 2, 1443239765), 
(1109, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-16.jpg', '', 2, 1443239766), 
(1110, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-17.jpg', '', 2, 1443240163), 
(1111, 'en', 'upload', 'Upload file', 'uploads/supplies/provision/ship-supply-provision-18.jpg', '', 2, 1443240164), 
(1112, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1443240185), 
(1113, 'en', 'supplies', 'Edit article', 'Provision supply', '', 2, 1443240374), 
(1114, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443240419), 
(1115, 'en', 'login', '[web24] Login', ' Client IP:14.169.191.67', '', 0, 1443241036), 
(1116, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1443241099), 
(1117, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1443241246), 
(1118, 'en', 'upload', 'Delete file', 'uploads/logo_moi.png', '', 2, 1443241477), 
(1119, 'en', 'upload', 'Delete file', 'uploads/logo_1.png', '', 2, 1443241477), 
(1120, 'en', 'upload', 'Delete file', 'uploads/logo.png', '', 2, 1443241477), 
(1121, 'en', 'upload', 'Upload file', 'uploads/ship-supply.png', '', 2, 1443241486), 
(1122, 'en', 'login', '[web24] Login', ' Client IP:14.169.176.36', '', 0, 1443404970), 
(1123, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-7.jpg', '', 2, 1443405003), 
(1124, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-8.jpg', '', 2, 1443405003), 
(1125, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-9.jpg', '', 2, 1443405003), 
(1126, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-5.jpg', '', 2, 1443405003), 
(1127, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-6.jpg', '', 2, 1443405003), 
(1128, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-4.jpg', '', 2, 1443405003), 
(1129, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-3.jpg', '', 2, 1443405003), 
(1130, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-1.jpg', '', 2, 1443405003), 
(1131, 'en', 'upload', 'Delete file', 'uploads/supplies/bridge/ship-supply-charts-publications-2.jpg', '', 2, 1443405003), 
(1132, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-1.jpg', '', 2, 1443405010), 
(1133, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-2.jpg', '', 2, 1443405011), 
(1134, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-3.jpg', '', 2, 1443405011), 
(1135, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-4.jpg', '', 2, 1443405012), 
(1136, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-5.jpg', '', 2, 1443405013), 
(1137, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-6.jpg', '', 2, 1443405013), 
(1138, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-7.jpg', '', 2, 1443405014), 
(1139, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-8.jpg', '', 2, 1443405014), 
(1140, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-9.jpg', '', 2, 1443405015), 
(1141, 'en', 'upload', 'Upload file', 'uploads/supplies/bridge/ship-supply-charts-publications-10.jpg', '', 2, 1443405016), 
(1142, 'en', 'supplies', 'Edit article', 'Bridge', '', 2, 1443405122), 
(1143, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-7.jpg', '', 2, 1443410238), 
(1144, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-8.jpg', '', 2, 1443410238), 
(1145, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-9.jpg', '', 2, 1443410238), 
(1146, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-10.jpg', '', 2, 1443410238), 
(1147, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 2, 1443410238), 
(1148, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-2.jpg', '', 2, 1443410238), 
(1149, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-3.jpg', '', 2, 1443410238), 
(1150, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-4.jpg', '', 2, 1443410238), 
(1151, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-5.jpg', '', 2, 1443410238), 
(1152, 'en', 'upload', 'Delete file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-6.jpg', '', 2, 1443410238), 
(1153, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg', '', 2, 1443410249), 
(1154, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-2.jpg', '', 2, 1443410249), 
(1155, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-3.jpg', '', 2, 1443410250), 
(1156, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-4.jpg', '', 2, 1443410250), 
(1157, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-5.jpg', '', 2, 1443410251), 
(1158, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-6.jpg', '', 2, 1443410251), 
(1159, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-7.jpg', '', 2, 1443410252), 
(1160, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-8.jpg', '', 2, 1443410253), 
(1161, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-9.jpg', '', 2, 1443410253), 
(1162, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-10.jpg', '', 2, 1443410254), 
(1163, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-11.jpg', '', 2, 1443410254), 
(1164, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-12.jpg', '', 2, 1443410255), 
(1165, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-13.jpg', '', 2, 1443410255), 
(1166, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-14.jpg', '', 2, 1443410256), 
(1167, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-15.jpg', '', 2, 1443410256), 
(1168, 'en', 'upload', 'Upload file', 'uploads/supplies/galley-stores/ship-supply-cabin-and-galley-store-16.jpg', '', 2, 1443410257), 
(1169, 'en', 'supplies', 'Edit article', 'Galley Stores', '', 2, 1443410505), 
(1170, 'en', 'upload', 'Delete file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-2.jpg', '', 2, 1443411637), 
(1171, 'en', 'upload', 'Upload file', 'uploads/supplies/deck-stores/ship-supply-deck-stores-2.jpg', '', 2, 1443411645), 
(1172, 'en', 'supplies', 'Edit article', 'Deck Stores', '', 2, 1443411650), 
(1173, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-13.jpg', '', 2, 1443413280), 
(1174, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-14.jpg', '', 2, 1443413280), 
(1175, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-15.jpg', '', 2, 1443413280), 
(1176, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg', '', 2, 1443413280), 
(1177, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg', '', 2, 1443413280), 
(1178, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg', '', 2, 1443413280), 
(1179, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg', '', 2, 1443413280), 
(1180, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', '', 2, 1443413280), 
(1181, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg', '', 2, 1443413280), 
(1182, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg', '', 2, 1443413280), 
(1183, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg', '', 2, 1443413280), 
(1184, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg', '', 2, 1443413280), 
(1185, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg', '', 2, 1443413280), 
(1186, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', '', 2, 1443413280), 
(1187, 'en', 'upload', 'Delete file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg', '', 2, 1443413280), 
(1188, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', '', 2, 1443413286), 
(1189, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg', '', 2, 1443413287), 
(1190, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg', '', 2, 1443413288), 
(1191, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg', '', 2, 1443413288), 
(1192, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg', '', 2, 1443413289), 
(1193, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg', '', 2, 1443413289), 
(1194, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg', '', 2, 1443413290), 
(1195, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg', '', 2, 1443413291), 
(1196, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg', '', 2, 1443413291), 
(1197, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg', '', 2, 1443413292), 
(1198, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg', '', 2, 1443413292), 
(1199, 'en', 'upload', 'Upload file', 'uploads/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', '', 2, 1443413293), 
(1200, 'en', 'supplies', 'Edit article', 'Marine Paints &amp; Chemicals', '', 2, 1443413312), 
(1201, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-20.jpg', '', 2, 1443415283), 
(1202, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-21.jpg', '', 2, 1443415283), 
(1203, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-22.jpg', '', 2, 1443415283), 
(1204, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-23.jpg', '', 2, 1443415283), 
(1205, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-19.jpg', '', 2, 1443415283), 
(1206, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-18.jpg', '', 2, 1443415283), 
(1207, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-15.jpg', '', 2, 1443415283), 
(1208, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-16.jpg', '', 2, 1443415283), 
(1209, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-14.jpg', '', 2, 1443415283), 
(1210, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-11.jpg', '', 2, 1443415283), 
(1211, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-12.jpg', '', 2, 1443415283), 
(1212, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-13.jpg', '', 2, 1443415283), 
(1213, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-9.jpg', '', 2, 1443415283), 
(1214, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-10.jpg', '', 2, 1443415283), 
(1215, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-5.jpg', '', 2, 1443415283), 
(1216, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-6.jpg', '', 2, 1443415283), 
(1217, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-7.jpg', '', 2, 1443415283), 
(1218, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-8.jpg', '', 2, 1443415283), 
(1219, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-3.jpg', '', 2, 1443415283), 
(1220, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-4.jpg', '', 2, 1443415283), 
(1221, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-1.jpg', '', 2, 1443415283), 
(1222, 'en', 'upload', 'Delete file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-2.jpg', '', 2, 1443415283), 
(1223, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-1.jpg', '', 2, 1443415290), 
(1224, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-2.jpg', '', 2, 1443415291), 
(1225, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-3.jpg', '', 2, 1443415292), 
(1226, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-4.jpg', '', 2, 1443415292), 
(1227, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-5.jpg', '', 2, 1443415293), 
(1228, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-6.jpg', '', 2, 1443415293), 
(1229, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-7.jpg', '', 2, 1443415294), 
(1230, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-8.jpg', '', 2, 1443415294), 
(1231, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-9.jpg', '', 2, 1443415295), 
(1232, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-10.jpg', '', 2, 1443415295), 
(1233, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-11.jpg', '', 2, 1443415296), 
(1234, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-12.jpg', '', 2, 1443415296), 
(1235, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-13.jpg', '', 2, 1443415297), 
(1236, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-14.jpg', '', 2, 1443415297), 
(1237, 'en', 'upload', 'Upload file', 'uploads/supplies/safety-stores/ship-supply-safety-equipment-15.jpg', '', 2, 1443415298), 
(1238, 'en', 'supplies', 'Edit article', 'Safety Stores &amp; Anti-Piracy Items', '', 2, 1443415315), 
(1239, 'en', 'login', '[web24] Login', ' Client IP:14.169.176.36', '', 0, 1443422653), 
(1240, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-23.jpg', '', 2, 1443422804), 
(1241, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-24.jpg', '', 2, 1443422804), 
(1242, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-18.jpg', '', 2, 1443422804), 
(1243, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-19.jpg', '', 2, 1443422804), 
(1244, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-20.jpg', '', 2, 1443422804), 
(1245, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-21.jpg', '', 2, 1443422804), 
(1246, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-22.jpg', '', 2, 1443422804), 
(1247, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', '', 2, 1443422804), 
(1248, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-14.jpg', '', 2, 1443422804), 
(1249, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-15.jpg', '', 2, 1443422804), 
(1250, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-16.jpg', '', 2, 1443422804), 
(1251, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-17.jpg', '', 2, 1443422804), 
(1252, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443422804), 
(1253, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443422804), 
(1254, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443422804), 
(1255, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443422804), 
(1256, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443422804), 
(1257, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443422804), 
(1258, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443422804), 
(1259, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443422804), 
(1260, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443422804), 
(1261, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443422804), 
(1262, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443422804), 
(1263, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443422804), 
(1264, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443422811), 
(1265, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443422812), 
(1266, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443422812), 
(1267, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443422813), 
(1268, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443422814), 
(1269, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443422814), 
(1270, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443422815), 
(1271, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443422815), 
(1272, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443422816), 
(1273, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443422816), 
(1274, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443422817), 
(1275, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443422817), 
(1276, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1443422825), 
(1277, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443422927), 
(1278, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443422931), 
(1279, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1443422941), 
(1280, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443423024), 
(1281, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443423029), 
(1282, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1443423034), 
(1283, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443423238), 
(1284, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443423238), 
(1285, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443423238), 
(1286, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443423238), 
(1287, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443423238), 
(1288, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443423238), 
(1289, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443423238), 
(1290, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443423238), 
(1291, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443423238), 
(1292, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443423238), 
(1293, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443423238), 
(1294, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443423238), 
(1295, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443423244), 
(1296, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443423244), 
(1297, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443423245), 
(1298, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443423245), 
(1299, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443423246), 
(1300, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443423246), 
(1301, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443423247), 
(1302, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443423248), 
(1303, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443423248), 
(1304, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443423249), 
(1305, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443423249), 
(1306, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443423250), 
(1307, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', '', 2, 1443423251), 
(1308, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1443423263), 
(1309, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg', '', 2, 1443425121), 
(1310, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-16.jpg', '', 2, 1443425121), 
(1311, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-17.jpg', '', 2, 1443425121), 
(1312, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-18.jpg', '', 2, 1443425121), 
(1313, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-13.jpg', '', 2, 1443425121), 
(1314, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-14.jpg', '', 2, 1443425121), 
(1315, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-15.jpg', '', 2, 1443425121), 
(1316, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-10.jpg', '', 2, 1443425121), 
(1317, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-11.jpg', '', 2, 1443425121), 
(1318, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-12.jpg', '', 2, 1443425121), 
(1319, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-8.jpg', '', 2, 1443425121), 
(1320, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-9.jpg', '', 2, 1443425121), 
(1321, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-5.jpg', '', 2, 1443425121), 
(1322, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-6.jpg', '', 2, 1443425121), 
(1323, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-7.jpg', '', 2, 1443425121), 
(1324, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-2.jpg', '', 2, 1443425121), 
(1325, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-3.jpg', '', 2, 1443425121), 
(1326, 'en', 'upload', 'Delete file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-4.jpg', '', 2, 1443425121), 
(1327, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-1.jpg', '', 2, 1443425128), 
(1328, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-2.jpg', '', 2, 1443425129), 
(1329, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-3.jpg', '', 2, 1443425129), 
(1330, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-4.jpg', '', 2, 1443425130), 
(1331, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-5.jpg', '', 2, 1443425130), 
(1332, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-6.jpg', '', 2, 1443425131), 
(1333, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-7.jpg', '', 2, 1443425131), 
(1334, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-8.jpg', '', 2, 1443425132), 
(1335, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-9.jpg', '', 2, 1443425132), 
(1336, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-10.jpg', '', 2, 1443425133), 
(1337, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-11.jpg', '', 2, 1443425133), 
(1338, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-12.jpg', '', 2, 1443425134), 
(1339, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-13.jpg', '', 2, 1443425134), 
(1340, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-14.jpg', '', 2, 1443425135), 
(1341, 'en', 'upload', 'Upload file', 'uploads/supplies/engine-stores/ship-supply-engineer-store-15.jpg', '', 2, 1443425136), 
(1342, 'en', 'supplies', 'Edit article', 'Engine Stores', '', 2, 1443425149), 
(1343, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443426784), 
(1344, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', '', 2, 1443426784), 
(1345, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443426784), 
(1346, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443426784), 
(1347, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443426784), 
(1348, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443426784), 
(1349, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443426784), 
(1350, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443426784), 
(1351, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443426784), 
(1352, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443426784), 
(1353, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443426784), 
(1354, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443426784), 
(1355, 'en', 'upload', 'Delete file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443426784), 
(1356, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', '', 2, 1443426791), 
(1357, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', '', 2, 1443426792), 
(1358, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', '', 2, 1443426794), 
(1359, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', '', 2, 1443426795), 
(1360, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', '', 2, 1443426795), 
(1361, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', '', 2, 1443426796), 
(1362, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', '', 2, 1443426796), 
(1363, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', '', 2, 1443426797), 
(1364, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', '', 2, 1443426797), 
(1365, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', '', 2, 1443426798), 
(1366, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', '', 2, 1443426798), 
(1367, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', '', 2, 1443426799), 
(1368, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', '', 2, 1443426800), 
(1369, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-14.jpg', '', 2, 1443426800), 
(1370, 'en', 'upload', 'Upload file', 'uploads/supplies/electrical-stores/ship-supply-electrical-stores-15.jpg', '', 2, 1443426801), 
(1371, 'en', 'supplies', 'Edit article', 'Electrical Stores', '', 2, 1443426817), 
(1372, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443437088), 
(1373, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1443437111), 
(1374, 'en', 'themes', 'Edit block', 'Name : global html', '', 2, 1443437124), 
(1375, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443490377), 
(1376, 'en', 'about', 'Edit', 'ID: 1', '', 2, 1443490456), 
(1377, 'en', 'upload', 'Upload file', 'uploads/vietnam-ship-supply-logo.png', '', 2, 1443495857), 
(1378, 'en', 'upload', 'Delete file', 'uploads/vietnam-ship-supply-logo.png', '', 2, 1443496991), 
(1379, 'en', 'upload', 'Upload file', 'uploads/vietnam-ship-supply-logo.png', '', 2, 1443496995), 
(1380, 'en', 'upload', 'Delete file', 'uploads/vietnam-ship-supply-logo.png', '', 2, 1443497468), 
(1381, 'en', 'upload', 'Upload file', 'uploads/vietnam-ship-supply-logo.png', '', 2, 1443497497), 
(1382, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443514465), 
(1383, 'en', 'themes', 'Edit block', 'Name : Copyright', '', 2, 1443514490), 
(1384, 'en', 'login', '[admin] Login', ' Client IP:14.169.161.67', '', 0, 1443515912), 
(1385, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443516098), 
(1386, 'en', 'webtools', 'System cleanup', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1443516314), 
(1387, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-1.jpg', '', 2, 1443519079), 
(1388, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-2.jpg', '', 2, 1443519080), 
(1389, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-3.jpg', '', 2, 1443519081), 
(1390, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-4.jpg', '', 2, 1443519083), 
(1391, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-5.jpg', '', 2, 1443519084), 
(1392, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-6.jpg', '', 2, 1443519084), 
(1393, 'en', 'slider', 'Edit categories', 'banner-1', '', 2, 1443519093), 
(1394, 'en', 'slider', 'Edit categories', 'banner-2', '', 2, 1443519108), 
(1395, 'en', 'slider', 'Edit categories', 'banner-3', '', 2, 1443519127), 
(1396, 'en', 'slider', 'Edit categories', 'banner-4', '', 2, 1443519144), 
(1397, 'en', 'slider', 'Edit categories', 'banner-5', '', 2, 1443519155), 
(1398, 'en', 'slider', 'Edit categories', 'banner-6', '', 2, 1443519167), 
(1399, 'en', 'slider', 'Delete article', 'banner-7', '', 2, 1443519174), 
(1400, 'en', 'login', '[admin] Leave Administration', ' Client IP:14.169.161.67', '', 0, 1443519467), 
(1401, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443520896), 
(1402, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-6.jpg', '', 2, 1443520944), 
(1403, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-5.jpg', '', 2, 1443520944), 
(1404, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-4.jpg', '', 2, 1443520944), 
(1405, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-3.jpg', '', 2, 1443520944), 
(1406, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-2.jpg', '', 2, 1443520944), 
(1407, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-1.jpg', '', 2, 1443520944), 
(1408, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/ship-supply-banner-4.jpg', '', 2, 1443520944), 
(1409, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/ship-supply-banner-1.jpg', '', 2, 1443520944), 
(1410, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/ship-supply-banner-2.jpg', '', 2, 1443520944), 
(1411, 'en', 'upload', 'Delete file', 'uploads/slider/2015_09/ship-supply-banner-3.jpg', '', 2, 1443520944), 
(1412, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-1.jpg', '', 2, 1443520955), 
(1413, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-2.jpg', '', 2, 1443520957), 
(1414, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-3.jpg', '', 2, 1443520958), 
(1415, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-4.jpg', '', 2, 1443520961), 
(1416, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-5.jpg', '', 2, 1443520962), 
(1417, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-6.jpg', '', 2, 1443520963), 
(1418, 'en', 'upload', 'Upload file', 'uploads/slider/2015_09/vietnam-ship-supply-banner-7.jpg', '', 2, 1443520964), 
(1419, 'en', 'slider', 'Edit categories', 'Banner-7', '', 2, 1443520978), 
(1420, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443577268), 
(1421, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 2, 1443577377), 
(1422, 'en', 'login', '[web24] Leave Administration', ' Client IP:14.169.161.67', '', 0, 1443582843), 
(1423, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443585232), 
(1424, 'en', 'themes', 'Edit block', 'Name : global html', '', 2, 1443585315), 
(1425, 'en', 'themes', 'Edit block', 'Name : global html', '', 2, 1443585515), 
(1426, 'en', 'login', '[web24] Leave Administration', ' Client IP:14.169.161.67', '', 0, 1443585622), 
(1427, 'en', 'login', '[admin] Login', ' Client IP:14.169.161.67', '', 0, 1443585639), 
(1428, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443759031), 
(1429, 'en', 'login', '[web24] Login', ' Client IP:14.169.161.67', '', 0, 1443772220), 
(1430, 'en', 'login', '[shipsupply] Login', ' Client IP:14.169.235.91', '', 0, 1444121077), 
(1431, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444201148), 
(1432, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444264679), 
(1433, 'en', 'supplies', 'Edit article', 'Bridge Stores', '', 3, 1444264758), 
(1434, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 3, 1444265085), 
(1435, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1444265210), 
(1436, 'en', 'themes', 'Edit block', 'Name : Social icon', '', 3, 1444265390), 
(1437, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.182.186', '', 0, 1444265517), 
(1438, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444291046), 
(1439, 'en', 'themes', 'Edit block', 'Name : Managing Director', '', 3, 1444291143), 
(1440, 'en', 'themes', 'Edit block', 'Name : Deputy Manager', '', 3, 1444291184), 
(1441, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1444291215), 
(1442, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1444291219), 
(1443, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1444291222), 
(1444, 'en', 'themes', 'Edit block', 'Name : Technical Manager', '', 3, 1444291249), 
(1445, 'en', 'themes', 'Edit block', 'Name : Chief Account', '', 3, 1444291276), 
(1446, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.182.186', '', 0, 1444291345), 
(1447, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444372542), 
(1448, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.182.186', '', 0, 1444372958), 
(1449, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444446745), 
(1450, 'en', 'slider', 'Delete article', 'Banner-7', '', 3, 1444446944), 
(1451, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.182.186', '', 0, 1444446954), 
(1452, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.182.186', '', 0, 1444447022), 
(1453, 'en', 'upload', 'Upload file', 'uploads/slider/2015_10/hinh-1.jpg', '', 3, 1444447713), 
(1454, 'en', 'upload', 'Upload file', 'uploads/slider/2015_10/hinh3.jpg', '', 3, 1444448248), 
(1455, 'en', 'upload', 'Upload file', 'uploads/slider/2015_10/hinh-3.jpg', '', 3, 1444448902), 
(1456, 'en', 'slider', 'Edit categories', 'banner 02', '', 3, 1444448918), 
(1457, 'en', 'slider', 'Delete article', 'banner 02', '', 3, 1444448948), 
(1458, 'en', 'slider', 'Delete article', 'banner 01', '', 3, 1444448956), 
(1459, 'en', 'login', '[admin] Login', ' Client IP:14.169.235.91', '', 0, 1445835281), 
(1460, 'en', 'login', '[admin] Login', ' Client IP:14.169.245.41', '', 0, 1445841787), 
(1461, 'en', 'supplies', 'Add a new article', 'tyyt', '', 1, 1445845445), 
(1462, 'en', 'supplies', 'Delete article', 'tyyt', '', 1, 1445845455), 
(1463, 'en', 'login', '[shipsupply] Login', ' Client IP:116.109.254.65', '', 0, 1457160110), 
(1464, 'en', 'themes', 'Edit block', 'Name : Social icon', '', 3, 1457160690), 
(1465, 'en', 'themes', 'Add block', 'Name : linkedin', '', 3, 1457161051), 
(1466, 'en', 'themes', 'Add block', 'Name : linkedin', '', 3, 1457161175), 
(1467, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.109.254.65', '', 0, 1457161226), 
(1468, 'en', 'login', '[shipsupply] Login', ' Client IP:116.109.254.65', '', 0, 1457161252), 
(1469, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.109.254.65', '', 0, 1457162354), 
(1470, 'en', 'login', '[shipsupply] Login', ' Client IP:116.109.254.65', '', 0, 1457750120), 
(1471, 'en', 'upload', 'Upload file', 'uploads/supplies/1.jpg', '', 3, 1457750714), 
(1472, 'en', 'upload', 'Upload file', 'uploads/about/1.jpg', '', 3, 1457750761), 
(1473, 'en', 'upload', 'Delete file', 'uploads/about/70105290-126322sm.jpg', '', 3, 1457750792), 
(1474, 'en', 'upload', 'Delete file', 'uploads/about/blue-ocean-about-1.jpg', '', 3, 1457750804), 
(1475, 'en', 'upload', 'Delete file', 'uploads/about/blue-ocean-about-4.jpg', '', 3, 1457750812), 
(1476, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1457750845), 
(1477, 'en', 'upload', 'Upload file', 'uploads/supplies/2.jpg', '', 3, 1457751134), 
(1478, 'en', 'upload', 'Upload file', 'uploads/supplies/2016_03/3.jpg', '', 3, 1457751785), 
(1479, 'en', 'supplies', 'Edit article', 'Provision supply', '', 3, 1457751871), 
(1480, 'en', 'supplies', 'Edit article', 'Supplier', '', 3, 1457754642), 
(1481, 'en', 'supplies', 'Edit article', 'Supplier', '', 3, 1457754790), 
(1482, 'en', 'supplies', 'Edit article', 'Supply Provision', '', 3, 1457755035), 
(1483, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.109.254.65', '', 0, 1457755677), 
(1484, 'en', 'login', '[web24] Login', ' Client IP:14.169.172.216', '', 0, 1464149970), 
(1485, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.45.1', '', 0, 1478750554), 
(1486, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.45.1', '', 0, 1478751349), 
(1487, 'en', 'login', '[shipsupply] Login', ' Client IP:116.102.45.1', '', 0, 1478751440), 
(1488, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 3, 1478751800), 
(1489, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1478751844), 
(1490, 'en', 'themes', 'Edit block', 'Name : Managing Director', '', 3, 1478751865), 
(1491, 'en', 'themes', 'Edit block', 'Name : Deputy Manager', '', 3, 1478751894), 
(1492, 'en', 'themes', 'Edit block', 'Name : Technical Manager', '', 3, 1478751921), 
(1493, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:116.102.45.1', '', 0, 1478751938), 
(1494, 'en', 'login', '[shipsupply] Login', ' Client IP:183.81.14.16', '', 0, 1496196470), 
(1495, 'en', 'upload', 'Upload file', 'uploads/about/0001.jpg', '', 3, 1496196546), 
(1496, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1496196565), 
(1497, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:183.81.14.16', '', 0, 1496197747), 
(1498, 'en', 'login', '[shipsupply] Login', ' Client IP:183.81.14.16', '', 0, 1496197867), 
(1499, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:183.81.14.16', '', 0, 1496198104), 
(1500, 'en', 'login', '[shipsupply] Login', ' Client IP:183.81.13.213', '', 0, 1496624794), 
(1501, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1496624891), 
(1502, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:183.81.13.213', '', 0, 1496625508), 
(1503, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.35.233', '', 0, 1501552315), 
(1504, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 3, 1501552407), 
(1505, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1501552460), 
(1506, 'en', 'themes', 'Edit block', 'Name : Managing Director', '', 3, 1501552501), 
(1507, 'en', 'themes', 'Edit block', 'Name : Deputy Manager', '', 3, 1501552529), 
(1508, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1501552587), 
(1509, 'en', 'themes', 'Edit block', 'Name : Chief Account', '', 3, 1501552628), 
(1510, 'en', 'themes', 'Edit block', 'Name : Technical Manager', '', 3, 1501552657), 
(1511, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.35.233', '', 0, 1501552673), 
(1512, 'en', 'login', '[shipsupply] Login', ' Client IP:1.55.50.189', '', 0, 1524192855), 
(1513, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1524192942), 
(1514, 'en', 'themes', 'Edit block', 'Name : Chief Account', '', 3, 1524193190), 
(1515, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 3, 1524193268), 
(1516, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.55.50.189', '', 0, 1524193324), 
(1517, 'en', 'login', '[admin] Login', ' Client IP:14.186.56.49', '', 0, 1528382771), 
(1518, 'en', 'login', '[shipsupply] Login', ' Client IP:131.111.194.10', '', 0, 1564819671), 
(1519, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1564821388), 
(1520, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1564821503), 
(1521, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 3, 1564821665), 
(1522, 'en', 'supplies', 'Edit article', 'Cabin Store', '', 3, 1564821924), 
(1523, 'en', 'supplies', 'Edit article', 'Bridge Store', '', 3, 1564822145), 
(1524, 'en', 'supplies', 'Edit article', 'Galley Store', '', 3, 1564822359), 
(1525, 'en', 'supplies', 'Edit article', 'Deck Stores', '', 3, 1564822498), 
(1526, 'en', 'supplies', 'Edit article', 'Deck Store', '', 3, 1564822525), 
(1527, 'en', 'supplies', 'Edit article', 'Paints &amp; Chemicals Store', '', 3, 1564822620), 
(1528, 'en', 'supplies', 'Edit article', 'Safety &amp; Anti-Piracy Store', '', 3, 1564822797), 
(1529, 'en', 'supplies', 'Edit article', 'Safety &amp; Anti-Piracy Store', '', 3, 1564822845), 
(1530, 'en', 'supplies', 'Edit article', 'Electrics Store', '', 3, 1564822923), 
(1531, 'en', 'supplies', 'Edit article', 'Engine Store', '', 3, 1564823028), 
(1532, 'en', 'port-we-serv', 'Edit', 'ID: 1', '', 3, 1564823284), 
(1533, 'en', 'login', '[shipsupply] Login', ' Client IP:131.111.194.10', '', 0, 1564823994), 
(1534, 'en', 'about', 'Edit', 'ID: 1', '', 3, 1564825048), 
(1535, 'en', 'login', '[shipsupply] Login', ' Client IP:131.111.194.10', '', 0, 1564866740), 
(1536, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.193.23', '', 0, 1565742966), 
(1537, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1565743275), 
(1538, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 3, 1565743324), 
(1539, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.193.23', '', 0, 1565743398), 
(1540, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.193.23', '', 0, 1565743498), 
(1541, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1565743553), 
(1542, 'en', 'themes', 'Edit block', 'Name : Managing Director', '', 3, 1565743588), 
(1543, 'en', 'themes', 'Edit block', 'Name : Deputy Manager', '', 3, 1565743611), 
(1544, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1565743631), 
(1545, 'en', 'themes', 'Edit block', 'Name : Technical Manager', '', 3, 1565743653), 
(1546, 'en', 'themes', 'Edit block', 'Name : Chief Account', '', 3, 1565743695), 
(1547, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 3, 1565743731), 
(1548, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.193.23', '', 0, 1565743748), 
(1549, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.193.23', '', 0, 1565929097), 
(1550, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 3, 1565929219), 
(1551, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.193.23', '', 0, 1565929275), 
(1552, 'en', 'login', '[vietnam] Login Fail', ' Client IP:113.173.77.3', '', 0, 1587519810), 
(1553, 'en', 'login', '[Vietnamship] Login Fail', ' Client IP:113.173.77.3', '', 0, 1587519839), 
(1554, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.163.217', '', 0, 1587520438), 
(1555, 'en', 'themes', 'Edit block', 'Name : Social icon', '', 3, 1587520606), 
(1556, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.163.217', '', 0, 1587520618), 
(1557, 'en', 'login', '[shipsupply] Login', ' Client IP:1.52.163.217', '', 0, 1587521140), 
(1558, 'en', 'themes', 'Edit block', 'Name : Contact Header', '', 3, 1587521176), 
(1559, 'en', 'themes', 'Edit block', 'Name : VIETNAM SHIP SUPPLY CO., LTD', '', 3, 1587521224), 
(1560, 'en', 'themes', 'Edit block', 'Name : global html', '', 3, 1587521277), 
(1561, 'en', 'themes', 'Edit block', 'Name : Managing Director', '', 3, 1587521319), 
(1562, 'en', 'themes', 'Edit block', 'Name : Deputy Manager', '', 3, 1587521351), 
(1563, 'en', 'themes', 'Edit block', 'Name : Purchasing Manager', '', 3, 1587521366), 
(1564, 'en', 'themes', 'Edit block', 'Name : Technical Manager', '', 3, 1587521395), 
(1565, 'en', 'themes', 'Edit block', 'Name : Chief Account', '', 3, 1587521429), 
(1566, 'en', 'login', '[shipsupply] Leave Administration', ' Client IP:1.52.163.217', '', 0, 1587521441), 
(1567, 'en', 'login', '[admin] Login', ' Client IP:14.186.21.80', '', 0, 1594378996);


-- ---------------------------------------


--
-- Table structure for table `nv4_notification`
--

DROP TABLE IF EXISTS `nv4_notification`;
CREATE TABLE `nv4_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3) NOT NULL,
  `module` varchar(50) NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=212  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_notification`
--

INSERT INTO `nv4_notification` VALUES
(211, 0, 0, 1, 'en', 'contact', 211, 'contact_new', 'a:1:{s:5:\"title\";s:10:\"Best Offer\";}', 1596625329, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_plugin`
--

DROP TABLE IF EXISTS `nv4_plugin`;
CREATE TABLE `nv4_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50) NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_sessions`
--

DROP TABLE IF EXISTS `nv4_sessions`;
CREATE TABLE `nv4_sessions` (
  `session_id` varchar(50) DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100) NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_sessions`
--

INSERT INTO `nv4_sessions` VALUES
('421jfnmelm47lnkjnql74appo5', 0, 'guest', 1596706209);


-- ---------------------------------------


--
-- Table structure for table `nv4_setup`
--

DROP TABLE IF EXISTS `nv4_setup`;
CREATE TABLE `nv4_setup` (
  `lang` char(2) NOT NULL,
  `module` varchar(50) NOT NULL,
  `tables` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_extensions`
--

DROP TABLE IF EXISTS `nv4_setup_extensions`;
CREATE TABLE `nv4_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT 'other',
  `title` varchar(55) NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50) NOT NULL DEFAULT '',
  `table_prefix` varchar(55) NOT NULL DEFAULT '',
  `version` varchar(50) NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text NOT NULL,
  `note` varchar(255) DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_extensions`
--

INSERT INTO `nv4_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '', 1441004505, '', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'supplies', 0, 0, 'news', 'supplies', '', 1441323651, '', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 0, 'users', 'users', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'default', 0, 0, 'default', 'default', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(0, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.21 1436199600', 1439973638, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'home', 0, 0, 'home', 'home', '3.4.01 1371254400', 1439977333, 'Phan Tan Dung (phantandung92@gmail.com)', ''), 
(0, 'module', 'slider', 0, 1, 'slider', 'slider', '4.1.00 1439987542', 1439987542, 'Pa Software Solutions (contact@vinanat.vn)', ''), 
(0, 'module', 'support', 0, 1, 'support', 'support', '4.0 1416416400', 1440001503, 'Pa Software Solutions ( contact@vinanat.vn)', ''), 
(0, 'module', 'port-we-serv', 0, 0, 'page', 'port_we_serv', '', 1442638839, '', '');


-- ---------------------------------------


--
-- Table structure for table `nv4_setup_language`
--

DROP TABLE IF EXISTS `nv4_setup_language`;
CREATE TABLE `nv4_setup_language` (
  `lang` char(2) NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_setup_language`
--

INSERT INTO `nv4_setup_language` VALUES
('en', 1);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_dir`
--

DROP TABLE IF EXISTS `nv4_upload_dir`;
CREATE TABLE `nv4_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(255) DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=89  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_dir`
--

INSERT INTO `nv4_upload_dir` VALUES
(0, '', 0, 3, 100, 150, 90), 
(1, 'uploads', 1439973854, 0, 0, 0, 0), 
(23, 'uploads/about', 1441004577, 0, 0, 0, 0), 
(3, 'uploads/banners', 0, 0, 0, 0, 0), 
(4, 'uploads/contact', 0, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 0, 0, 0, 0, 0), 
(6, 'uploads/menu', 0, 0, 0, 0, 0), 
(7, 'uploads/news', 1443497470, 0, 0, 0, 0), 
(8, 'uploads/news/source', 0, 0, 0, 0, 0), 
(9, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(10, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(11, 'uploads/page', 1443497481, 0, 0, 0, 0), 
(12, 'uploads/siteterms', 0, 0, 0, 0, 0), 
(13, 'uploads/users', 0, 0, 0, 0, 0), 
(34, 'uploads/supplies/topics', 0, 0, 0, 0, 0), 
(31, 'uploads/supplies', 1442552758, 0, 0, 0, 0), 
(32, 'uploads/supplies/source', 0, 0, 0, 0, 0), 
(18, 'uploads/slider', 0, 0, 0, 0, 0), 
(19, 'uploads/slider/2015_08', 1439987641, 0, 0, 0, 0), 
(33, 'uploads/supplies/temp_pic', 0, 0, 0, 0, 0), 
(21, 'uploads/news/2015_08', 1440755420, 0, 0, 0, 0), 
(35, 'uploads/supplies/2015_09', 1441323973, 0, 0, 0, 0), 
(25, 'uploads/news/2015_09', 1441075348, 0, 0, 0, 0), 
(36, 'uploads/slider/2015_09', 1442024713, 0, 0, 0, 0), 
(38, 'uploads/port-we-serv', 1442902113, 0, 0, 0, 0), 
(39, 'uploads/supplies/provision', 1442894879, 0, 0, 0, 0), 
(40, 'uploads/supplies/bridge', 1442895395, 0, 0, 0, 0), 
(41, 'uploads/supplies/cabin-stores', 1442898240, 0, 0, 0, 0), 
(42, 'uploads/supplies/galley-stores', 1442898608, 0, 0, 0, 0), 
(43, 'uploads/supplies/marine-paints-chemicals', 1442899008, 0, 0, 0, 0), 
(44, 'uploads/supplies/electrical-stores', 1442904122, 0, 0, 0, 0), 
(45, 'uploads/supplies/safety-stores', 1442904634, 0, 0, 0, 0), 
(46, 'uploads/supplies/engine-stores', 1442905357, 0, 0, 0, 0), 
(47, 'uploads/supplies/deck-stores', 1442909017, 0, 0, 0, 0), 
(48, 'uploads/news/2015_10', 0, 0, 0, 0, 0), 
(49, 'uploads/supplies/2015_10', 1445845411, 0, 0, 0, 0), 
(50, 'uploads/slider/2015_10', 1444447478, 0, 0, 0, 0), 
(51, 'uploads/supplies/oils-lubricants', 0, 0, 0, 0, 0), 
(52, 'uploads/supplies/rubber-packing', 0, 0, 0, 0, 0), 
(53, 'uploads/supplies/electrical-store', 0, 0, 0, 0, 0), 
(54, 'uploads/supplies/charts-publications', 0, 0, 0, 0, 0), 
(55, 'uploads/supplies/valve', 0, 0, 0, 0, 0), 
(56, 'uploads/supplies/jis-air-pipe-vent-heads', 0, 0, 0, 0, 0), 
(57, 'uploads/supplies/pipe-valve', 0, 0, 0, 0, 0), 
(58, 'uploads/supplies/pipe', 0, 0, 0, 0, 0), 
(59, 'uploads/supplies/ship-repair', 0, 0, 0, 0, 0), 
(60, 'uploads/supplies/engineer-store', 0, 0, 0, 0, 0), 
(61, 'uploads/supplies/safety-equipment', 0, 0, 0, 0, 0), 
(62, 'uploads/supplies/ship-supply', 0, 0, 0, 0, 0), 
(63, 'uploads/supplies/paints-chemicals', 0, 0, 0, 0, 0), 
(64, 'uploads/supplies/cabin-and-galley-store', 0, 0, 0, 0, 0), 
(65, 'uploads/our-business', 0, 0, 0, 0, 0), 
(66, 'uploads/our-business/oils-lubricants', 0, 0, 0, 0, 0), 
(67, 'uploads/our-business/rubber-packing', 0, 0, 0, 0, 0), 
(68, 'uploads/our-business/electrical-store', 0, 0, 0, 0, 0), 
(69, 'uploads/our-business/charts-publications', 0, 0, 0, 0, 0), 
(70, 'uploads/our-business/source', 0, 0, 0, 0, 0), 
(71, 'uploads/our-business/valve', 0, 0, 0, 0, 0), 
(72, 'uploads/our-business/jis-air-pipe-vent-heads', 0, 0, 0, 0, 0), 
(73, 'uploads/our-business/pipe-valve', 0, 0, 0, 0, 0), 
(74, 'uploads/our-business/2015_09', 0, 0, 0, 0, 0), 
(75, 'uploads/our-business/pipe', 0, 0, 0, 0, 0), 
(76, 'uploads/our-business/temp_pic', 0, 0, 0, 0, 0), 
(77, 'uploads/our-business/ship-repair', 0, 0, 0, 0, 0), 
(78, 'uploads/our-business/engineer-store', 0, 0, 0, 0, 0), 
(79, 'uploads/our-business/safety-equipment', 0, 0, 0, 0, 0), 
(80, 'uploads/our-business/topics', 0, 0, 0, 0, 0), 
(81, 'uploads/our-business/ship-supply', 0, 0, 0, 0, 0), 
(82, 'uploads/our-business/paints-chemicals', 0, 0, 0, 0, 0), 
(83, 'uploads/our-business/cabin-and-galley-store', 0, 0, 0, 0, 0), 
(84, 'uploads/supplies/2016_03', 1457750443, 0, 0, 0, 0), 
(85, 'uploads/supplies/2016_05', 0, 0, 0, 0, 0), 
(86, 'uploads/slider/2017_06', 1496625146, 0, 0, 0, 0), 
(87, 'uploads/supplies/2019_08', 0, 0, 0, 0, 0), 
(88, 'uploads/news/2019_08', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `nv4_upload_file`
--

DROP TABLE IF EXISTS `nv4_upload_file`;
CREATE TABLE `nv4_upload_file` (
  `name` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL DEFAULT '',
  `type` varchar(5) NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255) NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50) NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alt` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_upload_file`
--

INSERT INTO `nv4_upload_file` VALUES
('ship-supply.png', 'png', 'image', 21252, 'assets/ship-supply.png', 80, 28, '256|89', 2, 1443241486, 1, 'ship-supply.png', 'ship supply'), 
('blue-ocean...jpg', 'jpg', 'image', 388284, 'assets/slider/2015_08/blue-ocean-banner-1.jpg', 80, 29, '1359|480', 2, 1440925076, 19, 'blue-ocean-banner-1.jpg', 'blue ocean banner 1'), 
('blue-ocean...jpg', 'jpg', 'image', 230924, 'assets/slider/2015_08/blue-ocean-banner-2.jpg', 80, 29, '1359|480', 2, 1440927719, 19, 'blue-ocean-banner-2.jpg', 'blue ocean banner 2'), 
('blue-ocean...jpg', 'jpg', 'image', 281662, 'assets/slider/2015_08/blue-ocean-banner-3.jpg', 80, 29, '1359|480', 2, 1440929349, 19, 'blue-ocean-banner-3.jpg', 'blue ocean banner 3'), 
('blue-ocean...jpg', 'jpg', 'image', 307576, 'assets/slider/2015_08/blue-ocean-banner-4.jpg', 80, 29, '1359|480', 2, 1440945002, 19, 'blue-ocean-banner-4.jpg', 'blue ocean banner 4'), 
('blue-ocean...jpg', 'jpg', 'image', 257993, 'assets/slider/2015_08/blue-ocean-banner-5.jpg', 80, 29, '1359|480', 2, 1440945003, 19, 'blue-ocean-banner-5.jpg', 'blue ocean banner 5'), 
('blue-ocean...jpg', 'jpg', 'image', 241328, 'assets/slider/2015_08/blue-ocean-banner-6.jpg', 80, 29, '1359|480', 2, 1440945482, 19, 'blue-ocean-banner-6.jpg', 'blue ocean banner 6'), 
('blue-ocean...jpg', 'jpg', 'image', 213899, 'assets/slider/2015_08/blue-ocean-banner-7.jpg', 80, 29, '1359|480', 2, 1440945004, 19, 'blue-ocean-banner-7.jpg', 'blue ocean banner 7'), 
('images-3.jpg', 'jpg', 'image', 11442, 'assets/supplies/2015_09/images-3.jpg', 80, 48, '290|174', 1, 1441334308, 35, 'images-3.jpg', 'images &#40;3&#41;'), 
('leisure_1.jpg', 'jpg', 'image', 21218, 'assets/supplies/2015_09/leisure_1.jpg', 80, 48, '500|300', 1, 1441334308, 35, 'leisure_1.jpg', 'leisure'), 
('ship.jpg', 'jpg', 'image', 32821, 'assets/supplies/2015_09/ship.jpg', 80, 48, '500|300', 1, 1441334309, 35, 'ship.jpg', 'ship'), 
('_85358853_...jpg', 'jpg', 'image', 36218, 'assets/news/2015_09/_85358853_85358852.jpg', 80, 46, '660|371', 1, 1441335302, 25, '_85358853_85358852.jpg', '85358853 85358852'), 
('blue-ocean...jpg', 'jpg', 'image', 20389, 'assets/slider/2015_08/blue-ocean-logo-3.jpg', 80, 54, '120|80', 2, 1440951042, 19, 'blue-ocean-logo-3.jpg', 'blue ocean logo 3'), 
('blue-ocean...jpg', 'jpg', 'image', 26766, 'assets/slider/2015_08/blue-ocean-logo-1.jpg', 80, 54, '120|80', 2, 1440951042, 19, 'blue-ocean-logo-1.jpg', 'blue ocean logo 1'), 
('blue-ocean...jpg', 'jpg', 'image', 25363, 'assets/slider/2015_08/blue-ocean-logo-2.jpg', 80, 54, '120|80', 2, 1440951042, 19, 'blue-ocean-logo-2.jpg', 'blue ocean logo 2'), 
('blue-ocean...jpg', 'jpg', 'image', 21996, 'assets/slider/2015_08/blue-ocean-logo-4.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-4.jpg', 'blue ocean logo 4'), 
('paper-ship...jpg', 'jpg', 'image', 53499, 'assets/news/2015_09/paper-ships-300x199.jpg', 80, 54, '300|199', 2, 1441209977, 25, 'paper-ships-300x199.jpg', 'paper ships 300x199'), 
('viking-pic...jpg', 'jpg', 'image', 59166, 'assets/news/2015_09/viking-pic-300x199.jpg', 80, 54, '300|199', 2, 1441209803, 25, 'viking-pic-300x199.jpg', 'VIKING PIC 300x199'), 
('viking-300...jpg', 'jpg', 'image', 38225, 'assets/news/2015_09/viking-300x200.jpg', 80, 54, '300|200', 2, 1441209920, 25, 'viking-300x200.jpg', 'VIKING 300x200'), 
('1-14115439...jpg', 'jpg', 'image', 177078, 'assets/news/2015_08/1-141154394130-1.jpg', 80, 50, '404|252', 1, 1440755442, 21, '1-141154394130-1.jpg', '1 141154394130 &#40;1&#41;'), 
('1-14115439...jpg', 'jpg', 'image', 177078, 'assets/news/2015_08/1-141154394130.jpg', 80, 50, '404|252', 1, 1440755442, 21, '1-141154394130.jpg', '1 141154394130'), 
('3-14115439...jpg', 'jpg', 'image', 130061, 'assets/news/2015_08/3-141154394152.jpg', 80, 62, '311|241', 1, 1440755443, 21, '3-141154394152.jpg', '3 141154394152'), 
('4-14115439...jpg', 'jpg', 'image', 118309, 'assets/news/2015_08/4-141154394153.jpg', 80, 77, '259|249', 1, 1440755443, 21, '4-141154394153.jpg', '4 141154394153'), 
('5-14115439...jpg', 'jpg', 'image', 174194, 'assets/news/2015_08/5-141154394144-1.jpg', 71, 80, '324|365', 1, 1440755443, 21, '5-141154394144-1.jpg', '5 141154394144 &#40;1&#41;'), 
('5-14115439...jpg', 'jpg', 'image', 174194, 'assets/news/2015_08/5-141154394144.jpg', 71, 80, '324|365', 1, 1440755444, 21, '5-141154394144.jpg', '5 141154394144'), 
('6-14115440817.jpg', 'jpg', 'image', 174107, 'assets/news/2015_08/6-14115440817.jpg', 80, 56, '400|278', 1, 1440755444, 21, '6-14115440817.jpg', '6 14115440817'), 
('blue-ocean...jpg', 'jpg', 'image', 20813, 'assets/slider/2015_08/blue-ocean-logo-5.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-5.jpg', 'blue ocean logo 5'), 
('blue-ocean...jpg', 'jpg', 'image', 20434, 'assets/slider/2015_08/blue-ocean-logo-6.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-6.jpg', 'blue ocean logo 6'), 
('blue-ocean...jpg', 'jpg', 'image', 22220, 'assets/slider/2015_08/blue-ocean-logo-7.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-7.jpg', 'blue ocean logo 7'), 
('blue-ocean...jpg', 'jpg', 'image', 19032, 'assets/slider/2015_08/blue-ocean-logo-8.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-8.jpg', 'blue ocean logo 8'), 
('blue-ocean...jpg', 'jpg', 'image', 23839, 'assets/slider/2015_08/blue-ocean-logo-9.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-9.jpg', 'blue ocean logo 9'), 
('blue-ocean...jpg', 'jpg', 'image', 20752, 'assets/slider/2015_08/blue-ocean-logo-10.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-10.jpg', 'blue ocean logo 10'), 
('blue-ocean...jpg', 'jpg', 'image', 27378, 'assets/slider/2015_08/blue-ocean-logo-11.jpg', 80, 54, '120|80', 2, 1440951043, 19, 'blue-ocean-logo-11.jpg', 'blue ocean logo 11'), 
('blue-ocean...jpg', 'jpg', 'image', 18709, 'assets/slider/2015_08/blue-ocean-logo-12.jpg', 80, 54, '120|80', 2, 1440951044, 19, 'blue-ocean-logo-12.jpg', 'blue ocean logo 12'), 
('blue-ocean...jpg', 'jpg', 'image', 19533, 'assets/slider/2015_08/blue-ocean-logo-13.jpg', 80, 54, '120|80', 2, 1440954062, 19, 'blue-ocean-logo-13.jpg', 'blue ocean logo 13'), 
('blue-ocean...jpg', 'jpg', 'image', 18967, 'assets/slider/2015_08/blue-ocean-logo-14.jpg', 80, 54, '120|80', 2, 1440954062, 19, 'blue-ocean-logo-14.jpg', 'blue ocean logo 14'), 
('blue-ocean...jpg', 'jpg', 'image', 18605, 'assets/slider/2015_08/blue-ocean-logo-15.jpg', 80, 54, '120|80', 2, 1440954062, 19, 'blue-ocean-logo-15.jpg', 'blue ocean logo 15'), 
('blue-ocean...jpg', 'jpg', 'image', 18891, 'assets/slider/2015_08/blue-ocean-logo-16.jpg', 80, 54, '120|80', 2, 1440954063, 19, 'blue-ocean-logo-16.jpg', 'blue ocean logo 16'), 
('blue-ocean...jpg', 'jpg', 'image', 18947, 'assets/slider/2015_08/blue-ocean-logo-17.jpg', 80, 54, '120|80', 2, 1440954063, 19, 'blue-ocean-logo-17.jpg', 'blue ocean logo 17'), 
('blue-ocean...jpg', 'jpg', 'image', 20040, 'assets/slider/2015_08/blue-ocean-logo-18.jpg', 80, 54, '120|80', 2, 1440954063, 19, 'blue-ocean-logo-18.jpg', 'blue ocean logo 18'), 
('blue-ocean...jpg', 'jpg', 'image', 19136, 'assets/slider/2015_08/blue-ocean-logo-19.jpg', 80, 54, '120|80', 2, 1440954063, 19, 'blue-ocean-logo-19.jpg', 'blue ocean logo 19'), 
('blue-ocean...jpg', 'jpg', 'image', 23519, 'assets/slider/2015_08/blue-ocean-logo-20.jpg', 80, 54, '120|80', 2, 1440954063, 19, 'blue-ocean-logo-20.jpg', 'blue ocean logo 20'), 
('blue-ocean...jpg', 'jpg', 'image', 20851, 'assets/slider/2015_08/blue-ocean-logo-21.jpg', 80, 54, '120|80', 2, 1440954176, 19, 'blue-ocean-logo-21.jpg', 'blue ocean logo 21'), 
('blue-ocean...jpg', 'jpg', 'image', 17249, 'assets/slider/2015_08/blue-ocean-logo-22.jpg', 80, 54, '120|80', 2, 1440954189, 19, 'blue-ocean-logo-22.jpg', 'blue ocean logo 22'), 
('blue-ocean...jpg', 'jpg', 'image', 17842, 'assets/slider/2015_08/blue-ocean-logo-23.jpg', 80, 54, '120|80', 2, 1440954189, 19, 'blue-ocean-logo-23.jpg', 'blue ocean logo 23'), 
('blue-ocean...jpg', 'jpg', 'image', 25364, 'assets/slider/2015_08/blue-ocean-logo-24.jpg', 80, 54, '120|80', 2, 1440954189, 19, 'blue-ocean-logo-24.jpg', 'blue ocean logo 24'), 
('blue-ocean...jpg', 'jpg', 'image', 20287, 'assets/slider/2015_08/blue-ocean-logo-25.jpg', 80, 54, '120|80', 2, 1440954189, 19, 'blue-ocean-logo-25.jpg', 'blue ocean logo 25'), 
('moi.jpg', 'jpg', 'image', 9068, 'assets/supplies/2015_09/moi.jpg', 80, 54, '275|183', 1, 1441334224, 35, 'moi.jpg', 'moi'), 
('leisure.jpg', 'jpg', 'image', 21218, 'assets/supplies/2015_09/leisure.jpg', 80, 48, '500|300', 1, 1441334224, 35, 'leisure.jpg', 'leisure'), 
('1-14115439...jpg', 'jpg', 'image', 55643, 'assets/supplies/2015_09/1-141154394130-1.jpg', 80, 48, '500|300', 1, 1441334222, 35, '1-141154394130-1.jpg', '1 141154394130 &#40;1&#41;'), 
('500x300_s...jpeg', 'jpeg', 'image', 39272, 'assets/supplies/2015_09/500x300_spirit.jpeg', 80, 48, '500|300', 1, 1441334223, 35, '500x300_spirit.jpeg', '500x300 spirit'), 
('anh.jpg', 'jpg', 'image', 72703, 'assets/supplies/2015_09/anh.jpg', 80, 48, '500|300', 1, 1441334223, 35, 'anh.jpg', 'anh'), 
('images.jpg', 'jpg', 'image', 8965, 'assets/supplies/2015_09/images.jpg', 80, 48, '290|174', 1, 1441334223, 35, 'images.jpg', 'images'), 
('call60.png', 'png', 'image', 625, 'assets/call60.png', 32, 32, '32|32', 2, 1441191297, 1, 'call60.png', 'call60'), 
('email103.png', 'png', 'image', 647, 'assets/email103.png', 32, 32, '32|32', 2, 1441191297, 1, 'email103.png', 'email103'), 
('home173.png', 'png', 'image', 906, 'assets/home173.png', 32, 32, '32|32', 2, 1441191298, 1, 'home173.png', 'home173'), 
('iphone26.png', 'png', 'image', 334, 'assets/iphone26.png', 32, 32, '32|32', 2, 1441191298, 1, 'iphone26.png', 'iphone26'), 
('paper6.png', 'png', 'image', 326, 'assets/paper6.png', 32, 32, '32|32', 2, 1441191298, 1, 'paper6.png', 'paper6'), 
('pin66.png', 'png', 'image', 915, 'assets/pin66.png', 32, 32, '32|32', 2, 1441191298, 1, 'pin66.png', 'pin66'), 
('web58.png', 'png', 'image', 920, 'assets/web58.png', 32, 32, '32|32', 2, 1441192273, 1, 'web58.png', 'web58'), 
('2-14137853315.jpg', 'jpg', 'image', 368723, 'assets/supplies/2015_09/2-14137853315.jpg', 80, 60, '1500|1125', 1, 1441592930, 35, '2-14137853315.jpg', '2 14137853315'), 
('vietnam-sh...jpg', 'jpg', 'image', 132932, 'assets/slider/2015_09/vietnam-ship-supply-banner-3.jpg', 80, 22, '1500|403', 2, 1443520960, 36, 'vietnam-ship-supply-banner-3.jpg', 'vietnam ship supply banner 3'), 
('vietnam-sh...jpg', 'jpg', 'image', 147026, 'assets/slider/2015_09/vietnam-ship-supply-banner-1.jpg', 80, 22, '1500|403', 2, 1443520956, 36, 'vietnam-ship-supply-banner-1.jpg', 'vietnam ship supply banner 1'), 
('vietnam-sh...jpg', 'jpg', 'image', 179280, 'assets/slider/2015_09/vietnam-ship-supply-banner-2.jpg', 80, 22, '1500|403', 2, 1443520958, 36, 'vietnam-ship-supply-banner-2.jpg', 'vietnam ship supply banner 2'), 
('0001.jpg', 'jpg', 'image', 149367, 'assets/about/0001.jpg', 57, 80, '1061|1500', 3, 1496196547, 23, '0001.jpg', '0001'), 
('blue-ocean...jpg', 'jpg', 'image', 130493, 'assets/about/blue-ocean-about-2.jpg', 80, 54, '600|400', 2, 1442194862, 23, 'blue-ocean-about-2.jpg', 'blue ocean about 2'), 
('blue-ocean...jpg', 'jpg', 'image', 97230, 'assets/about/blue-ocean-about-3.jpg', 80, 54, '600|400', 2, 1442194863, 23, 'blue-ocean-about-3.jpg', 'blue ocean about 3'), 
('2.jpg', 'jpg', 'image', 216447, 'assets/supplies/2.jpg', 60, 80, '840|1120', 3, 1457751134, 31, '2.jpg', '2'), 
('3.jpg', 'jpg', 'image', 50937, 'assets/supplies/2016_03/3.jpg', 60, 80, '360|480', 3, 1457751785, 84, '3.jpg', '3'), 
('untitled-1.png', 'png', 'image', 156027, 'assets/supplies/untitled-1.png', 80, 80, '298|297', 2, 1442200274, 31, 'untitled-1.png', 'untitled 1'), 
('untitlessdd-1.png', 'png', 'image', 116264, 'assets/supplies/untitlessdd-1.png', 80, 79, '299|294', 2, 1442200274, 31, 'untitlessdd-1.png', 'untitlessdd 1'), 
('untitled-31.png', 'png', 'image', 113616, 'assets/supplies/untitled-31.png', 80, 80, '297|296', 2, 1442200274, 31, 'untitled-31.png', 'untitled 31'), 
('ship_supply.png', 'png', 'image', 85043, 'assets/supplies/ship_supply.png', 80, 80, '248|248', 2, 1442200274, 31, 'ship_supply.png', 'ship supply'), 
('ship_repair.png', 'png', 'image', 110489, 'assets/supplies/ship_repair.png', 80, 80, '248|248', 2, 1442200274, 31, 'ship_repair.png', 'ship repair'), 
('ship_service.png', 'png', 'image', 112019, 'assets/supplies/ship_service.png', 80, 80, '248|248', 2, 1442200274, 31, 'ship_service.png', 'ship service'), 
('ship-suppl...jpg', 'jpg', 'image', 96537, 'assets/supplies/2015_09/ship-supply-general-repairs.jpg', 80, 54, '600|400', 2, 1442632681, 35, 'ship-supply-general-repairs.jpg', 'ship supply general repairs'), 
('ship-suppl...jpg', 'jpg', 'image', 96322, 'assets/supplies/2015_09/ship-supply-other-services.jpg', 80, 54, '600|400', 2, 1442632682, 35, 'ship-supply-other-services.jpg', 'ship supply other services'), 
('ship-suppl...jpg', 'jpg', 'image', 85575, 'assets/supplies/bridge/ship-supply-charts-publications-10.jpg', 80, 60, '400|300', 2, 1443405016, 40, 'ship-supply-charts-publications-10.jpg', 'ship supply charts publications 10'), 
('ship-suppl...jpg', 'jpg', 'image', 103548, 'assets/supplies/bridge/ship-supply-charts-publications-9.jpg', 80, 54, '406|270', 2, 1443405015, 40, 'ship-supply-charts-publications-9.jpg', 'ship supply charts publications 9'), 
('ship-suppl...jpg', 'jpg', 'image', 118102, 'assets/supplies/provision/ship-supply-provision-13.jpg', 80, 54, '406|270', 2, 1443239764, 39, 'ship-supply-provision-13.jpg', 'ship supply provision 13'), 
('ship-suppl...jpg', 'jpg', 'image', 126470, 'assets/supplies/provision/ship-supply-provision-1.jpg', 80, 60, '400|300', 2, 1443239750, 39, 'ship-supply-provision-1.jpg', 'ship supply provision 1'), 
('ship-suppl...jpg', 'jpg', 'image', 123465, 'assets/supplies/provision/ship-supply-provision-2.jpg', 80, 54, '406|270', 2, 1443239751, 39, 'ship-supply-provision-2.jpg', 'ship supply provision 2'), 
('ship-suppl...jpg', 'jpg', 'image', 111723, 'assets/supplies/provision/ship-supply-provision-3.jpg', 80, 54, '406|270', 2, 1443239752, 39, 'ship-supply-provision-3.jpg', 'ship supply provision 3'), 
('ship-suppl...jpg', 'jpg', 'image', 87953, 'assets/supplies/provision/ship-supply-provision-4.jpg', 80, 54, '406|270', 2, 1443239754, 39, 'ship-supply-provision-4.jpg', 'ship supply provision 4'), 
('ship-suppl...jpg', 'jpg', 'image', 126095, 'assets/supplies/provision/ship-supply-provision-5.jpg', 80, 54, '406|270', 2, 1443239755, 39, 'ship-supply-provision-5.jpg', 'ship supply provision 5'), 
('ship-suppl...jpg', 'jpg', 'image', 136966, 'assets/supplies/provision/ship-supply-provision-6.jpg', 80, 54, '406|270', 2, 1443239756, 39, 'ship-supply-provision-6.jpg', 'ship supply provision 6'), 
('ship-suppl...jpg', 'jpg', 'image', 125712, 'assets/supplies/provision/ship-supply-provision-7.jpg', 80, 54, '406|270', 2, 1443239758, 39, 'ship-supply-provision-7.jpg', 'ship supply provision 7'), 
('ship-suppl...jpg', 'jpg', 'image', 146892, 'assets/supplies/provision/ship-supply-provision-8.jpg', 80, 54, '406|270', 2, 1443239759, 39, 'ship-supply-provision-8.jpg', 'ship supply provision 8'), 
('ship-suppl...jpg', 'jpg', 'image', 141779, 'assets/supplies/provision/ship-supply-provision-9.jpg', 80, 54, '406|270', 2, 1443239760, 39, 'ship-supply-provision-9.jpg', 'ship supply provision 9'), 
('ship-suppl...jpg', 'jpg', 'image', 139409, 'assets/supplies/provision/ship-supply-provision-10.jpg', 80, 54, '406|270', 2, 1443239762, 39, 'ship-supply-provision-10.jpg', 'ship supply provision 10'), 
('ship-suppl...jpg', 'jpg', 'image', 126597, 'assets/supplies/provision/ship-supply-provision-11.jpg', 80, 54, '406|270', 2, 1443239762, 39, 'ship-supply-provision-11.jpg', 'ship supply provision 11'), 
('ship-suppl...jpg', 'jpg', 'image', 108142, 'assets/supplies/provision/ship-supply-provision-12.jpg', 80, 54, '406|270', 2, 1443239763, 39, 'ship-supply-provision-12.jpg', 'ship supply provision 12'), 
('ship-suppl...jpg', 'jpg', 'image', 84118, 'assets/supplies/bridge/ship-supply-charts-publications-8.jpg', 80, 54, '406|270', 2, 1443405015, 40, 'ship-supply-charts-publications-8.jpg', 'ship supply charts publications 8'), 
('ship-suppl...jpg', 'jpg', 'image', 97377, 'assets/supplies/bridge/ship-supply-charts-publications-1.jpg', 80, 54, '406|270', 2, 1443405010, 40, 'ship-supply-charts-publications-1.jpg', 'ship supply charts publications 1'), 
('ship-suppl...jpg', 'jpg', 'image', 88255, 'assets/supplies/bridge/ship-supply-charts-publications-2.jpg', 80, 54, '406|270', 2, 1443405011, 40, 'ship-supply-charts-publications-2.jpg', 'ship supply charts publications 2'), 
('ship-suppl...jpg', 'jpg', 'image', 96907, 'assets/supplies/bridge/ship-supply-charts-publications-3.jpg', 80, 54, '406|270', 2, 1443405012, 40, 'ship-supply-charts-publications-3.jpg', 'ship supply charts publications 3'), 
('ship-suppl...jpg', 'jpg', 'image', 81466, 'assets/supplies/bridge/ship-supply-charts-publications-4.jpg', 80, 54, '406|270', 2, 1443405012, 40, 'ship-supply-charts-publications-4.jpg', 'ship supply charts publications 4'), 
('ship-suppl...jpg', 'jpg', 'image', 83976, 'assets/supplies/bridge/ship-supply-charts-publications-5.jpg', 80, 54, '406|270', 2, 1443405013, 40, 'ship-supply-charts-publications-5.jpg', 'ship supply charts publications 5'), 
('ship-suppl...jpg', 'jpg', 'image', 90224, 'assets/supplies/bridge/ship-supply-charts-publications-6.jpg', 80, 54, '406|270', 2, 1443405014, 40, 'ship-supply-charts-publications-6.jpg', 'ship supply charts publications 6'), 
('ship-suppl...jpg', 'jpg', 'image', 97838, 'assets/supplies/bridge/ship-supply-charts-publications-7.jpg', 80, 54, '406|270', 2, 1443405014, 40, 'ship-supply-charts-publications-7.jpg', 'ship supply charts publications 7'), 
('ship-suppl...jpg', 'jpg', 'image', 87228, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-1.jpg', 80, 60, '400|300', 2, 1442898251, 41, 'ship-supply-cabin-stores-1.jpg', 'ship supply cabin stores 1'), 
('ship-suppl...jpg', 'jpg', 'image', 74942, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-2.jpg', 80, 54, '406|270', 2, 1442898251, 41, 'ship-supply-cabin-stores-2.jpg', 'ship supply cabin stores 2'), 
('ship-suppl...jpg', 'jpg', 'image', 72068, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-3.jpg', 80, 54, '406|270', 2, 1442898252, 41, 'ship-supply-cabin-stores-3.jpg', 'ship supply cabin stores 3'), 
('ship-suppl...jpg', 'jpg', 'image', 86780, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-4.jpg', 80, 54, '406|270', 2, 1442898252, 41, 'ship-supply-cabin-stores-4.jpg', 'ship supply cabin stores 4'), 
('ship-suppl...jpg', 'jpg', 'image', 96920, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-5.jpg', 80, 54, '406|270', 2, 1442898253, 41, 'ship-supply-cabin-stores-5.jpg', 'ship supply cabin stores 5'), 
('ship-suppl...jpg', 'jpg', 'image', 56467, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-6.jpg', 80, 54, '406|270', 2, 1442898253, 41, 'ship-supply-cabin-stores-6.jpg', 'ship supply cabin stores 6'), 
('ship-suppl...jpg', 'jpg', 'image', 103738, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-7.jpg', 80, 54, '406|270', 2, 1442898254, 41, 'ship-supply-cabin-stores-7.jpg', 'ship supply cabin stores 7'), 
('ship-suppl...jpg', 'jpg', 'image', 101894, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-8.jpg', 80, 54, '406|270', 2, 1442898254, 41, 'ship-supply-cabin-stores-8.jpg', 'ship supply cabin stores 8'), 
('ship-suppl...jpg', 'jpg', 'image', 97133, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-9.jpg', 80, 54, '406|270', 2, 1442898255, 41, 'ship-supply-cabin-stores-9.jpg', 'ship supply cabin stores 9'), 
('ship-suppl...jpg', 'jpg', 'image', 86056, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-10.jpg', 80, 54, '406|270', 2, 1442898256, 41, 'ship-supply-cabin-stores-10.jpg', 'ship supply cabin stores 10'), 
('ship-suppl...jpg', 'jpg', 'image', 60093, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-11.jpg', 80, 54, '406|270', 2, 1442898256, 41, 'ship-supply-cabin-stores-11.jpg', 'ship supply cabin stores 11'), 
('ship-suppl...jpg', 'jpg', 'image', 47826, 'assets/supplies/cabin-stores/ship-supply-cabin-stores-12.jpg', 80, 54, '406|270', 2, 1442898256, 41, 'ship-supply-cabin-stores-12.jpg', 'ship supply cabin stores 12'), 
('ship-suppl...jpg', 'jpg', 'image', 87683, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-10.jpg', 80, 54, '406|270', 2, 1443410254, 42, 'ship-supply-cabin-and-galley-store-10.jpg', 'ship supply cabin and galley store 10'), 
('ship-suppl...jpg', 'jpg', 'image', 59554, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-9.jpg', 80, 54, '406|270', 2, 1443410253, 42, 'ship-supply-cabin-and-galley-store-9.jpg', 'ship supply cabin and galley store 9'), 
('ship-suppl...jpg', 'jpg', 'image', 71953, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-8.jpg', 80, 54, '406|270', 2, 1443410253, 42, 'ship-supply-cabin-and-galley-store-8.jpg', 'ship supply cabin and galley store 8'), 
('ship-suppl...jpg', 'jpg', 'image', 76008, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-7.jpg', 80, 54, '406|270', 2, 1443410252, 42, 'ship-supply-cabin-and-galley-store-7.jpg', 'ship supply cabin and galley store 7'), 
('ship-suppl...jpg', 'jpg', 'image', 76758, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-6.jpg', 80, 54, '406|270', 2, 1443410252, 42, 'ship-supply-cabin-and-galley-store-6.jpg', 'ship supply cabin and galley store 6'), 
('ship-suppl...jpg', 'jpg', 'image', 93847, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-1.jpg', 80, 60, '400|300', 2, 1443410249, 42, 'ship-supply-cabin-and-galley-store-1.jpg', 'ship supply cabin and galley store 1'), 
('ship-suppl...jpg', 'jpg', 'image', 83976, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-2.jpg', 80, 54, '406|270', 2, 1443410250, 42, 'ship-supply-cabin-and-galley-store-2.jpg', 'ship supply cabin and galley store 2'), 
('ship-suppl...jpg', 'jpg', 'image', 80067, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-3.jpg', 80, 54, '406|270', 2, 1443410250, 42, 'ship-supply-cabin-and-galley-store-3.jpg', 'ship supply cabin and galley store 3'), 
('ship-suppl...jpg', 'jpg', 'image', 58879, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-4.jpg', 80, 54, '406|270', 2, 1443410251, 42, 'ship-supply-cabin-and-galley-store-4.jpg', 'ship supply cabin and galley store 4'), 
('ship-suppl...jpg', 'jpg', 'image', 69085, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-5.jpg', 80, 54, '406|270', 2, 1443410251, 42, 'ship-supply-cabin-and-galley-store-5.jpg', 'ship supply cabin and galley store 5'), 
('ship-suppl...jpg', 'jpg', 'image', 56800, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-1.jpg', 80, 60, '400|300', 2, 1443413287, 43, 'ship-supply-paints-chemicals-1.jpg', 'ship supply paints chemicals 1'), 
('ship-suppl...jpg', 'jpg', 'image', 105377, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-2.jpg', 80, 54, '406|270', 2, 1443413287, 43, 'ship-supply-paints-chemicals-2.jpg', 'ship supply paints chemicals 2'), 
('ship-suppl...jpg', 'jpg', 'image', 145138, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-3.jpg', 80, 54, '406|270', 2, 1443413288, 43, 'ship-supply-paints-chemicals-3.jpg', 'ship supply paints chemicals 3'), 
('ship-suppl...jpg', 'jpg', 'image', 80789, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-4.jpg', 80, 54, '406|270', 2, 1443413288, 43, 'ship-supply-paints-chemicals-4.jpg', 'ship supply paints chemicals 4'), 
('ship-suppl...jpg', 'jpg', 'image', 85759, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-5.jpg', 80, 54, '406|270', 2, 1443413289, 43, 'ship-supply-paints-chemicals-5.jpg', 'ship supply paints chemicals 5'), 
('ship-suppl...jpg', 'jpg', 'image', 113790, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-6.jpg', 80, 54, '406|270', 2, 1443413290, 43, 'ship-supply-paints-chemicals-6.jpg', 'ship supply paints chemicals 6'), 
('ship-suppl...jpg', 'jpg', 'image', 132245, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-7.jpg', 80, 54, '406|270', 2, 1443413290, 43, 'ship-supply-paints-chemicals-7.jpg', 'ship supply paints chemicals 7'), 
('ship-suppl...jpg', 'jpg', 'image', 90289, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-8.jpg', 80, 54, '406|270', 2, 1443413291, 43, 'ship-supply-paints-chemicals-8.jpg', 'ship supply paints chemicals 8'), 
('ship-suppl...jpg', 'jpg', 'image', 93097, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-9.jpg', 80, 54, '406|270', 2, 1443413291, 43, 'ship-supply-paints-chemicals-9.jpg', 'ship supply paints chemicals 9'), 
('ship-suppl...jpg', 'jpg', 'image', 76225, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-10.jpg', 80, 54, '406|270', 2, 1443413292, 43, 'ship-supply-paints-chemicals-10.jpg', 'ship supply paints chemicals 10'), 
('ship-suppl...jpg', 'jpg', 'image', 82119, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-11.jpg', 80, 54, '406|270', 2, 1443413292, 43, 'ship-supply-paints-chemicals-11.jpg', 'ship supply paints chemicals 11'), 
('ship-suppl...jpg', 'jpg', 'image', 90212, 'assets/supplies/marine-paints-chemicals/ship-supply-paints-chemicals-12.jpg', 80, 54, '406|270', 2, 1443413293, 43, 'ship-supply-paints-chemicals-12.jpg', 'ship supply paints chemicals 12'), 
('ship-suppl...jpg', 'jpg', 'image', 194362, 'assets/port-we-serv/ship-supply-port-we-serv.jpg', 54, 80, '656|973', 2, 1442902121, 38, 'ship-supply-port-we-serv.jpg', 'ship supply port we serv'), 
('hinh3.jpg', 'jpg', 'image', 264583, 'assets/slider/2015_10/hinh3.jpg', 80, 60, '1120|840', 3, 1444448249, 50, 'hinh3.jpg', 'hinh3'), 
('hinh-3.jpg', 'jpg', 'image', 203050, 'assets/slider/2015_10/hinh-3.jpg', 80, 60, '1200|900', 3, 1444448902, 50, 'hinh-3.jpg', 'hinh 3'), 
('hinh-1.jpg', 'jpg', 'image', 354400, 'assets/slider/2015_10/hinh-1.jpg', 80, 60, '1280|960', 3, 1444447714, 50, 'hinh-1.jpg', 'hinh 1'), 
('vietnam-sh...jpg', 'jpg', 'image', 136102, 'assets/slider/2015_09/vietnam-ship-supply-banner-7.jpg', 80, 22, '1500|403', 2, 1443520966, 36, 'vietnam-ship-supply-banner-7.jpg', 'vietnam ship supply banner 7'), 
('vietnam-sh...jpg', 'jpg', 'image', 121529, 'assets/slider/2015_09/vietnam-ship-supply-banner-6.jpg', 80, 22, '1500|403', 2, 1443520964, 36, 'vietnam-ship-supply-banner-6.jpg', 'vietnam ship supply banner 6'), 
('ship-suppl...jpg', 'jpg', 'image', 79907, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-1.jpg', 80, 60, '400|300', 2, 1443426792, 44, 'ship-supply-electrical-stores-1.jpg', 'ship supply electrical stores 1'), 
('ship-suppl...jpg', 'jpg', 'image', 63090, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-2.jpg', 80, 54, '406|270', 2, 1443426792, 44, 'ship-supply-electrical-stores-2.jpg', 'ship supply electrical stores 2'), 
('ship-suppl...jpg', 'jpg', 'image', 74147, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-3.jpg', 80, 54, '406|270', 2, 1443426794, 44, 'ship-supply-electrical-stores-3.jpg', 'ship supply electrical stores 3'), 
('ship-suppl...jpg', 'jpg', 'image', 64264, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-4.jpg', 80, 54, '406|270', 2, 1443426795, 44, 'ship-supply-electrical-stores-4.jpg', 'ship supply electrical stores 4'), 
('ship-suppl...jpg', 'jpg', 'image', 53292, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-5.jpg', 80, 54, '406|270', 2, 1443426795, 44, 'ship-supply-electrical-stores-5.jpg', 'ship supply electrical stores 5'), 
('ship-suppl...jpg', 'jpg', 'image', 101790, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-6.jpg', 80, 54, '406|270', 2, 1443426796, 44, 'ship-supply-electrical-stores-6.jpg', 'ship supply electrical stores 6'), 
('ship-suppl...jpg', 'jpg', 'image', 80305, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-7.jpg', 80, 54, '406|270', 2, 1443426797, 44, 'ship-supply-electrical-stores-7.jpg', 'ship supply electrical stores 7'), 
('ship-suppl...jpg', 'jpg', 'image', 75602, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-8.jpg', 80, 54, '406|270', 2, 1443426797, 44, 'ship-supply-electrical-stores-8.jpg', 'ship supply electrical stores 8'), 
('ship-suppl...jpg', 'jpg', 'image', 68165, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-9.jpg', 80, 54, '406|270', 2, 1443426798, 44, 'ship-supply-electrical-stores-9.jpg', 'ship supply electrical stores 9'), 
('ship-suppl...jpg', 'jpg', 'image', 76568, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-10.jpg', 80, 54, '406|270', 2, 1443426798, 44, 'ship-supply-electrical-stores-10.jpg', 'ship supply electrical stores 10'), 
('ship-suppl...jpg', 'jpg', 'image', 96551, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-11.jpg', 80, 54, '406|270', 2, 1443426799, 44, 'ship-supply-electrical-stores-11.jpg', 'ship supply electrical stores 11'), 
('ship-suppl...jpg', 'jpg', 'image', 95400, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-12.jpg', 80, 54, '406|270', 2, 1443426799, 44, 'ship-supply-electrical-stores-12.jpg', 'ship supply electrical stores 12'), 
('ship-suppl...jpg', 'jpg', 'image', 113619, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-13.jpg', 80, 54, '406|270', 2, 1443426800, 44, 'ship-supply-electrical-stores-13.jpg', 'ship supply electrical stores 13'), 
('ship-suppl...jpg', 'jpg', 'image', 50469, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-14.jpg', 80, 54, '406|270', 2, 1443426801, 44, 'ship-supply-electrical-stores-14.jpg', 'ship supply electrical stores 14'), 
('ship-suppl...jpg', 'jpg', 'image', 86531, 'assets/supplies/electrical-stores/ship-supply-electrical-stores-15.jpg', 80, 54, '406|270', 2, 1443426801, 44, 'ship-supply-electrical-stores-15.jpg', 'ship supply electrical stores 15'), 
('nukeviet-job.jpg', 'jpg', 'image', 23576, 'assets/news/nukeviet-job.jpg', 80, 60, '400|300', 2, 1441314276, 7, 'nukeviet-job.jpg', 'nukeviet job'), 
('nangly.jpg', 'jpg', 'image', 34802, 'assets/news/nangly.jpg', 80, 53, '500|332', 2, 1441314276, 7, 'nangly.jpg', 'nangly'), 
('webnhanh-vn.jpg', 'jpg', 'image', 38259, 'assets/news/webnhanh-vn.jpg', 80, 58, '400|281', 2, 1441314276, 7, 'webnhanh-vn.jpg', 'webnhanh vn'), 
('hoptac.jpg', 'jpg', 'image', 12871, 'assets/news/hoptac.jpg', 80, 66, '382|314', 2, 1441314276, 7, 'hoptac.jpg', 'hoptac'), 
('nukeviet3.jpg', 'jpg', 'image', 17464, 'assets/news/nukeviet3.jpg', 80, 65, '310|250', 2, 1441314276, 7, 'nukeviet3.jpg', 'nukeviet3'), 
('screenshot.jpg', 'jpg', 'image', 35078, 'assets/news/screenshot.jpg', 80, 64, '400|317', 2, 1441314276, 7, 'screenshot.jpg', 'screenshot'), 
('nukeviet-n...jpg', 'jpg', 'image', 18611, 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 2, 1441314276, 7, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'), 
('product_box.jpg', 'jpg', 'image', 23063, 'assets/news/product_box.jpg', 80, 73, '400|363', 2, 1441314276, 7, 'product_box.jpg', 'product box'), 
('ship-suppl...jpg', 'jpg', 'image', 129966, 'assets/supplies/safety-stores/ship-supply-safety-equipment-1.jpg', 80, 60, '400|300', 2, 1443415291, 45, 'ship-supply-safety-equipment-1.jpg', 'ship supply safety equipment 1'), 
('ship-suppl...jpg', 'jpg', 'image', 87151, 'assets/supplies/safety-stores/ship-supply-safety-equipment-2.jpg', 80, 54, '406|270', 2, 1443415291, 45, 'ship-supply-safety-equipment-2.jpg', 'ship supply safety equipment 2'), 
('ship-suppl...jpg', 'jpg', 'image', 89856, 'assets/supplies/safety-stores/ship-supply-safety-equipment-3.jpg', 80, 54, '406|270', 2, 1443415292, 45, 'ship-supply-safety-equipment-3.jpg', 'ship supply safety equipment 3'), 
('ship-suppl...jpg', 'jpg', 'image', 52784, 'assets/supplies/safety-stores/ship-supply-safety-equipment-4.jpg', 80, 54, '406|270', 2, 1443415292, 45, 'ship-supply-safety-equipment-4.jpg', 'ship supply safety equipment 4'), 
('ship-suppl...jpg', 'jpg', 'image', 93238, 'assets/supplies/safety-stores/ship-supply-safety-equipment-5.jpg', 80, 54, '406|270', 2, 1443415293, 45, 'ship-supply-safety-equipment-5.jpg', 'ship supply safety equipment 5'), 
('ship-suppl...jpg', 'jpg', 'image', 69186, 'assets/supplies/safety-stores/ship-supply-safety-equipment-6.jpg', 80, 54, '406|270', 2, 1443415293, 45, 'ship-supply-safety-equipment-6.jpg', 'ship supply safety equipment 6'), 
('ship-suppl...jpg', 'jpg', 'image', 57219, 'assets/supplies/safety-stores/ship-supply-safety-equipment-7.jpg', 80, 54, '406|270', 2, 1443415294, 45, 'ship-supply-safety-equipment-7.jpg', 'ship supply safety equipment 7'), 
('ship-suppl...jpg', 'jpg', 'image', 71289, 'assets/supplies/safety-stores/ship-supply-safety-equipment-8.jpg', 80, 54, '406|270', 2, 1443415294, 45, 'ship-supply-safety-equipment-8.jpg', 'ship supply safety equipment 8'), 
('ship-suppl...jpg', 'jpg', 'image', 83946, 'assets/supplies/safety-stores/ship-supply-safety-equipment-9.jpg', 80, 54, '406|270', 2, 1443415295, 45, 'ship-supply-safety-equipment-9.jpg', 'ship supply safety equipment 9'), 
('ship-suppl...jpg', 'jpg', 'image', 72421, 'assets/supplies/safety-stores/ship-supply-safety-equipment-10.jpg', 80, 54, '406|270', 2, 1443415295, 45, 'ship-supply-safety-equipment-10.jpg', 'ship supply safety equipment 10'), 
('ship-suppl...jpg', 'jpg', 'image', 77654, 'assets/supplies/safety-stores/ship-supply-safety-equipment-11.jpg', 80, 54, '406|270', 2, 1443415296, 45, 'ship-supply-safety-equipment-11.jpg', 'ship supply safety equipment 11'), 
('ship-suppl...jpg', 'jpg', 'image', 123388, 'assets/supplies/safety-stores/ship-supply-safety-equipment-12.jpg', 80, 54, '406|270', 2, 1443415297, 45, 'ship-supply-safety-equipment-12.jpg', 'ship supply safety equipment 12'), 
('ship-suppl...jpg', 'jpg', 'image', 99356, 'assets/supplies/safety-stores/ship-supply-safety-equipment-13.jpg', 80, 54, '406|270', 2, 1443415297, 45, 'ship-supply-safety-equipment-13.jpg', 'ship supply safety equipment 13'), 
('ship-suppl...jpg', 'jpg', 'image', 62752, 'assets/supplies/safety-stores/ship-supply-safety-equipment-14.jpg', 80, 54, '406|270', 2, 1443415298, 45, 'ship-supply-safety-equipment-14.jpg', 'ship supply safety equipment 14'), 
('ship-suppl...jpg', 'jpg', 'image', 68227, 'assets/supplies/safety-stores/ship-supply-safety-equipment-15.jpg', 80, 54, '406|270', 2, 1443415298, 45, 'ship-supply-safety-equipment-15.jpg', 'ship supply safety equipment 15'), 
('vietnam-sh...jpg', 'jpg', 'image', 141952, 'assets/slider/2015_09/vietnam-ship-supply-banner-4.jpg', 80, 22, '1500|403', 2, 1443520962, 36, 'vietnam-ship-supply-banner-4.jpg', 'vietnam ship supply banner 4'), 
('vietnam-sh...jpg', 'jpg', 'image', 81625, 'assets/slider/2015_09/vietnam-ship-supply-banner-5.jpg', 80, 22, '1500|403', 2, 1443520963, 36, 'vietnam-ship-supply-banner-5.jpg', 'vietnam ship supply banner 5'), 
('vietnam-sh...png', 'png', 'image', 41998, 'assets/vietnam-ship-supply-logo.png', 80, 26, '270|89', 2, 1443497497, 1, 'vietnam-ship-supply-logo.png', 'vietnam ship supply logo'), 
('ship-suppl...jpg', 'jpg', 'image', 119251, 'assets/supplies/engine-stores/ship-supply-engineer-store-1.jpg', 80, 60, '400|300', 2, 1443425128, 46, 'ship-supply-engineer-store-1.jpg', 'ship supply engineer store 1'), 
('ship-suppl...jpg', 'jpg', 'image', 109351, 'assets/supplies/engine-stores/ship-supply-engineer-store-2.jpg', 80, 54, '406|270', 2, 1443425129, 46, 'ship-supply-engineer-store-2.jpg', 'ship supply engineer store 2'), 
('ship-suppl...jpg', 'jpg', 'image', 71142, 'assets/supplies/engine-stores/ship-supply-engineer-store-3.jpg', 80, 54, '406|270', 2, 1443425129, 46, 'ship-supply-engineer-store-3.jpg', 'ship supply engineer store 3'), 
('ship-suppl...jpg', 'jpg', 'image', 100457, 'assets/supplies/engine-stores/ship-supply-engineer-store-4.jpg', 80, 54, '406|270', 2, 1443425130, 46, 'ship-supply-engineer-store-4.jpg', 'ship supply engineer store 4'), 
('ship-suppl...jpg', 'jpg', 'image', 56083, 'assets/supplies/engine-stores/ship-supply-engineer-store-5.jpg', 80, 54, '406|270', 2, 1443425130, 46, 'ship-supply-engineer-store-5.jpg', 'ship supply engineer store 5'), 
('ship-suppl...jpg', 'jpg', 'image', 55414, 'assets/supplies/engine-stores/ship-supply-engineer-store-6.jpg', 80, 54, '406|270', 2, 1443425131, 46, 'ship-supply-engineer-store-6.jpg', 'ship supply engineer store 6'), 
('ship-suppl...jpg', 'jpg', 'image', 78843, 'assets/supplies/engine-stores/ship-supply-engineer-store-7.jpg', 80, 54, '406|270', 2, 1443425131, 46, 'ship-supply-engineer-store-7.jpg', 'ship supply engineer store 7'), 
('ship-suppl...jpg', 'jpg', 'image', 63562, 'assets/supplies/engine-stores/ship-supply-engineer-store-8.jpg', 80, 54, '406|270', 2, 1443425132, 46, 'ship-supply-engineer-store-8.jpg', 'ship supply engineer store 8'), 
('ship-suppl...jpg', 'jpg', 'image', 61679, 'assets/supplies/engine-stores/ship-supply-engineer-store-9.jpg', 80, 54, '406|270', 2, 1443425132, 46, 'ship-supply-engineer-store-9.jpg', 'ship supply engineer store 9'), 
('ship-suppl...jpg', 'jpg', 'image', 63117, 'assets/supplies/engine-stores/ship-supply-engineer-store-10.jpg', 80, 54, '406|270', 2, 1443425133, 46, 'ship-supply-engineer-store-10.jpg', 'ship supply engineer store 10'), 
('ship-suppl...jpg', 'jpg', 'image', 60569, 'assets/supplies/engine-stores/ship-supply-engineer-store-11.jpg', 80, 54, '406|270', 2, 1443425134, 46, 'ship-supply-engineer-store-11.jpg', 'ship supply engineer store 11'), 
('ship-suppl...jpg', 'jpg', 'image', 63073, 'assets/supplies/engine-stores/ship-supply-engineer-store-12.jpg', 80, 54, '406|270', 2, 1443425134, 46, 'ship-supply-engineer-store-12.jpg', 'ship supply engineer store 12'), 
('ship-suppl...jpg', 'jpg', 'image', 91908, 'assets/supplies/engine-stores/ship-supply-engineer-store-13.jpg', 80, 54, '406|270', 2, 1443425135, 46, 'ship-supply-engineer-store-13.jpg', 'ship supply engineer store 13'), 
('ship-suppl...jpg', 'jpg', 'image', 120813, 'assets/supplies/engine-stores/ship-supply-engineer-store-14.jpg', 80, 54, '406|270', 2, 1443425135, 46, 'ship-supply-engineer-store-14.jpg', 'ship supply engineer store 14'), 
('ship-suppl...jpg', 'jpg', 'image', 87679, 'assets/supplies/engine-stores/ship-supply-engineer-store-15.jpg', 80, 54, '406|270', 2, 1443425136, 46, 'ship-supply-engineer-store-15.jpg', 'ship supply engineer store 15'), 
('ship-suppl...jpg', 'jpg', 'image', 95139, 'assets/supplies/deck-stores/ship-supply-deck-stores-2.jpg', 80, 60, '400|300', 2, 1443411645, 47, 'ship-supply-deck-stores-2.jpg', 'ship supply deck stores &#40;2&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 63167, 'assets/supplies/deck-stores/ship-supply-deck-stores-3.jpg', 80, 54, '406|270', 2, 1442909025, 47, 'ship-supply-deck-stores-3.jpg', 'ship supply deck stores &#40;3&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 50679, 'assets/supplies/deck-stores/ship-supply-deck-stores-4.jpg', 80, 54, '406|270', 2, 1442909025, 47, 'ship-supply-deck-stores-4.jpg', 'ship supply deck stores &#40;4&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 38056, 'assets/supplies/deck-stores/ship-supply-deck-stores-5.jpg', 80, 54, '406|270', 2, 1442909025, 47, 'ship-supply-deck-stores-5.jpg', 'ship supply deck stores &#40;5&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 54962, 'assets/supplies/deck-stores/ship-supply-deck-stores-6.jpg', 80, 54, '406|270', 2, 1442909026, 47, 'ship-supply-deck-stores-6.jpg', 'ship supply deck stores &#40;6&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 108436, 'assets/supplies/deck-stores/ship-supply-deck-stores-7.jpg', 80, 54, '406|270', 2, 1442909026, 47, 'ship-supply-deck-stores-7.jpg', 'ship supply deck stores &#40;7&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 104469, 'assets/supplies/deck-stores/ship-supply-deck-stores-8.jpg', 80, 54, '406|270', 2, 1442909026, 47, 'ship-supply-deck-stores-8.jpg', 'ship supply deck stores &#40;8&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 88217, 'assets/supplies/deck-stores/ship-supply-deck-stores-9.jpg', 80, 54, '406|270', 2, 1442909027, 47, 'ship-supply-deck-stores-9.jpg', 'ship supply deck stores &#40;9&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 116305, 'assets/supplies/deck-stores/ship-supply-deck-stores-10.jpg', 80, 54, '406|270', 2, 1442909027, 47, 'ship-supply-deck-stores-10.jpg', 'ship supply deck stores &#40;10&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 83245, 'assets/supplies/deck-stores/ship-supply-deck-stores-11.jpg', 80, 54, '406|270', 2, 1442909027, 47, 'ship-supply-deck-stores-11.jpg', 'ship supply deck stores &#40;11&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 58430, 'assets/supplies/deck-stores/ship-supply-deck-stores-12.jpg', 80, 54, '406|270', 2, 1442909027, 47, 'ship-supply-deck-stores-12.jpg', 'ship supply deck stores &#40;12&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 66179, 'assets/supplies/deck-stores/ship-supply-deck-stores-13.jpg', 80, 54, '406|270', 2, 1442909028, 47, 'ship-supply-deck-stores-13.jpg', 'ship supply deck stores &#40;13&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 106624, 'assets/supplies/deck-stores/ship-supply-deck-stores-14.jpg', 80, 54, '406|270', 2, 1442909028, 47, 'ship-supply-deck-stores-14.jpg', 'ship supply deck stores &#40;14&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 93511, 'assets/supplies/deck-stores/ship-supply-deck-stores-15.jpg', 80, 54, '406|270', 2, 1442909028, 47, 'ship-supply-deck-stores-15.jpg', 'ship supply deck stores &#40;15&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 110670, 'assets/supplies/deck-stores/ship-supply-deck-stores-16.jpg', 80, 54, '406|270', 2, 1442909029, 47, 'ship-supply-deck-stores-16.jpg', 'ship supply deck stores &#40;16&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 70591, 'assets/supplies/deck-stores/ship-supply-deck-stores-17.jpg', 80, 54, '406|270', 2, 1442909029, 47, 'ship-supply-deck-stores-17.jpg', 'ship supply deck stores &#40;17&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 63471, 'assets/supplies/deck-stores/ship-supply-deck-stores-18.jpg', 80, 54, '406|270', 2, 1442909029, 47, 'ship-supply-deck-stores-18.jpg', 'ship supply deck stores &#40;18&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 60994, 'assets/supplies/deck-stores/ship-supply-deck-stores-19.jpg', 80, 54, '406|270', 2, 1442909030, 47, 'ship-supply-deck-stores-19.jpg', 'ship supply deck stores &#40;19&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 82025, 'assets/supplies/deck-stores/ship-supply-deck-stores-20.jpg', 80, 54, '406|270', 2, 1442909030, 47, 'ship-supply-deck-stores-20.jpg', 'ship supply deck stores &#40;20&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 64598, 'assets/supplies/deck-stores/ship-supply-deck-stores-21.jpg', 80, 54, '406|270', 2, 1442909031, 47, 'ship-supply-deck-stores-21.jpg', 'ship supply deck stores &#40;21&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 59734, 'assets/supplies/deck-stores/ship-supply-deck-stores-22.jpg', 80, 60, '400|300', 2, 1442909031, 47, 'ship-supply-deck-stores-22.jpg', 'ship supply deck stores &#40;22&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 76566, 'assets/supplies/deck-stores/ship-supply-deck-stores-23.jpg', 80, 54, '406|270', 2, 1442909031, 47, 'ship-supply-deck-stores-23.jpg', 'ship supply deck stores &#40;23&#41;'), 
('ship-suppl...jpg', 'jpg', 'image', 137740, 'assets/supplies/provision/ship-supply-provision-14.jpg', 80, 54, '406|270', 2, 1443239765, 39, 'ship-supply-provision-14.jpg', 'ship supply provision 14'), 
('ship-suppl...jpg', 'jpg', 'image', 98560, 'assets/supplies/provision/ship-supply-provision-15.jpg', 80, 54, '406|270', 2, 1443239765, 39, 'ship-supply-provision-15.jpg', 'ship supply provision 15'), 
('ship-suppl...jpg', 'jpg', 'image', 77149, 'assets/supplies/provision/ship-supply-provision-16.jpg', 80, 54, '406|270', 2, 1443239766, 39, 'ship-supply-provision-16.jpg', 'ship supply provision 16'), 
('ship-suppl...jpg', 'jpg', 'image', 111867, 'assets/supplies/provision/ship-supply-provision-17.jpg', 80, 54, '406|270', 2, 1443240164, 39, 'ship-supply-provision-17.jpg', 'ship supply provision 17'), 
('ship-suppl...jpg', 'jpg', 'image', 87616, 'assets/supplies/provision/ship-supply-provision-18.jpg', 80, 54, '406|270', 2, 1443240164, 39, 'ship-supply-provision-18.jpg', 'ship supply provision 18'), 
('ship-suppl...jpg', 'jpg', 'image', 72094, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-11.jpg', 80, 54, '406|270', 2, 1443410255, 42, 'ship-supply-cabin-and-galley-store-11.jpg', 'ship supply cabin and galley store 11'), 
('ship-suppl...jpg', 'jpg', 'image', 83893, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-12.jpg', 80, 54, '406|270', 2, 1443410255, 42, 'ship-supply-cabin-and-galley-store-12.jpg', 'ship supply cabin and galley store 12'), 
('ship-suppl...jpg', 'jpg', 'image', 58280, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-13.jpg', 80, 54, '406|270', 2, 1443410256, 42, 'ship-supply-cabin-and-galley-store-13.jpg', 'ship supply cabin and galley store 13'), 
('ship-suppl...jpg', 'jpg', 'image', 49399, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-14.jpg', 80, 54, '406|270', 2, 1443410256, 42, 'ship-supply-cabin-and-galley-store-14.jpg', 'ship supply cabin and galley store 14'), 
('ship-suppl...jpg', 'jpg', 'image', 79413, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-15.jpg', 80, 54, '406|270', 2, 1443410257, 42, 'ship-supply-cabin-and-galley-store-15.jpg', 'ship supply cabin and galley store 15'), 
('ship-suppl...jpg', 'jpg', 'image', 52516, 'assets/supplies/galley-stores/ship-supply-cabin-and-galley-store-16.jpg', 80, 54, '406|270', 2, 1443410257, 42, 'ship-supply-cabin-and-galley-store-16.jpg', 'ship supply cabin and galley store 16'), 
('1.jpg', 'jpg', 'image', 219147, 'assets/supplies/1.jpg', 60, 80, '840|1120', 3, 1457750714, 31, '1.jpg', '1'), 
('1.jpg', 'jpg', 'image', 219147, 'assets/about/1.jpg', 60, 80, '840|1120', 3, 1457750761, 23, '1.jpg', '1');


-- ---------------------------------------


--
-- Table structure for table `nv4_users`
--

DROP TABLE IF EXISTS `nv4_users`;
CREATE TABLE `nv4_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(100) NOT NULL DEFAULT '',
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `gender` char(1) DEFAULT '',
  `photo` varchar(255) DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `passlostkey` varchar(50) DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255) DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40) DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45) DEFAULT '',
  `last_agent` varchar(255) DEFAULT '',
  `last_openid` varchar(255) DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40) DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users`
--

INSERT INTO `nv4_users` VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}RxhFijY9DEpYQTyHPh5L8lKE3/96cmJr', 'trungnghiack@gmail.com', 'admin', '', '', '', 0, '', 1439973726, 'where are you from', 'daklak bmt', '', 0, 1, '', 1, '', 1439973726, '', '', '', 0, 0, ''), 
(2, 'web24', 'a43bdc040a35ab9bad37d8e3d8dd7d39', '{SSHA}w2lJBQBHS70jiSO1pumYV/6QKxgxbUxn', 'hoangnhan@gmail.com', 'hoangnhan', '', '', '', 0, '', 1440747988, 'hoangnhan', 'hoangnhan', '', 0, 1, '', 1, '', 0, '', '', '', 0, 0, ''), 
(3, 'shipsupply', '0aecc071749ba90a7f8fdfdfe57fa515', '{SSHA}OCpY3PzS5IZHSvdDuAjO+2ebZFxWQU5s', 'shipsupply@test.com', 'shipsupply', '', '', '', 0, '', 1442997838, 'meo', 'meo', '', 0, 1, '', 1, '', 0, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `nv4_users_config`
--

DROP TABLE IF EXISTS `nv4_users_config`;
CREATE TABLE `nv4_users_config` (
  `config` varchar(100) NOT NULL,
  `content` text,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_config`
--

INSERT INTO `nv4_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|654321|696969|1234567|12345678|123456789|1234567890|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman', 1439973638), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1439973638), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1439973638), 
('avatar_width', '80', 1439973638), 
('avatar_height', '80', 1439973638), 
('siteterms_en', '<p style=\"text-align:center;\"> <strong>Website usage terms and conditions – sample template</strong></p><p> Welcome to our website. If you continue to browse and use this website you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern [business name]’s relationship with you in relation to this website.<br /> The term ‘[business name]’ or ‘us’ or ‘we’ refers to the owner of the website whose registered office is [address]. Our company registration number is [company registration number and place of registration]. The term ‘you’ refers to the user or viewer of our website.<br /> The use of this website is subject to the following terms of use:<br /> • The content of the pages of this website is for your general information and use only. It is subject to change without notice.<br /> • Neither we nor any third parties provide any warranty or guarantee as to the accuracy, timeliness, performance, completeness or suitability of the information and materials found or offered on this website for any particular purpose. You acknowledge that such information and materials may contain inaccuracies or errors and we expressly exclude liability for any such inaccuracies or errors to the fullest extent permitted by law.<br /> • Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.<br /> • This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.<br /> • All trademarks reproduced in this website, which are not the property of, or licensed to the operator, are acknowledged on the website.<br /> • Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.<br /> • fr0m time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).<br /> • You may not crea-te a link to this website fr0m another website or document without [business name]’s prior written consent.<br /> • Your use of this website and any dispute arising out of such use of the website is subject to the laws of England, Scotland and Wales.</p>', 1274757617);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_field`
--

DROP TABLE IF EXISTS `nv4_users_field`;
CREATE TABLE `nv4_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25) NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect') NOT NULL DEFAULT 'textbox',
  `field_choices` text NOT NULL,
  `sql_choices` text NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback') NOT NULL DEFAULT 'none',
  `match_regex` varchar(250) NOT NULL DEFAULT '',
  `func_callback` varchar(75) NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50) NOT NULL,
  `language` text NOT NULL,
  `default_value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_info`
--

DROP TABLE IF EXISTS `nv4_users_info`;
CREATE TABLE `nv4_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_info`
--

INSERT INTO `nv4_users_info` VALUES
(1), 
(2), 
(3);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_openid`
--

DROP TABLE IF EXISTS `nv4_users_openid`;
CREATE TABLE `nv4_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255) NOT NULL DEFAULT '',
  `opid` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;


-- ---------------------------------------


--
-- Table structure for table `nv4_users_question`
--

DROP TABLE IF EXISTS `nv4_users_question`;
CREATE TABLE `nv4_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `lang` char(2) NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8;

--
-- Dumping data for table `nv4_users_question`
--

INSERT INTO `nv4_users_question` VALUES
(1, 'What is the first name of your favorite uncle?', 'en', 1, 1274841115, 1274841115), 
(2, 'whe-re did you meet your spouse', 'en', 2, 1274841123, 1274841123), 
(3, 'What is your oldest cousin&#039;s name?', 'en', 3, 1274841131, 1274841131), 
(4, 'What is your youngest child&#039;s username?', 'en', 4, 1274841142, 1274841142), 
(5, 'What is your oldest child&#039;s username?', 'en', 5, 1274841150, 1274841150), 
(6, 'What is the first name of your oldest niece?', 'en', 6, 1274841158, 1274841158), 
(7, 'What is the first name of your oldest nephew?', 'en', 7, 1274841167, 1274841167), 
(8, 'What is the first name of your favorite aunt?', 'en', 8, 1274841175, 1274841175), 
(9, 'whe-re did you spend your honeymoon?', 'en', 9, 1274841183, 1274841183);


-- ---------------------------------------


--
-- Table structure for table `nv4_users_reg`
--

DROP TABLE IF EXISTS `nv4_users_reg`;
CREATE TABLE `nv4_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `md5username` char(32) NOT NULL DEFAULT '',
  `password` varchar(80) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `first_name` varchar(255) NOT NULL DEFAULT '',
  `last_name` varchar(255) NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL DEFAULT '',
  `checknum` varchar(50) NOT NULL DEFAULT '',
  `users_info` text,
  `openid_info` text,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;